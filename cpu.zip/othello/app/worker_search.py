"""Worker内だけで共通CPUの探索状態を保持する。"""

from __future__ import annotations

import json
from dataclasses import asdict
from typing import TYPE_CHECKING, Any, cast

from othello.core import Board, Rules
from othello.cpu import MctsConfig, MonteCarloConfig, create_search
from othello.cpu.models import validate_seed

if TYPE_CHECKING:
    from othello.core import Color, GameState
    from othello.cpu import ContinuousSearch, SearchConfig, SearchPhase


def _read(raw: str, expected: str) -> tuple[dict[str, Any], int, int, GameState]:
    data = json.loads(raw)
    if not isinstance(data, dict) or data["type"] != expected:
        raise ValueError("要求の種類が不正です")
    for name in ("game_id", "revision"):
        if type(data[name]) is not int or not 0 <= data[name] < 2**53:
            raise ValueError("要求IDが不正です")
    for name in ("black", "white"):
        if (
            not isinstance(data[name], str)
            or not data[name].isascii()
            or not data[name].isdecimal()
        ):
            raise ValueError("盤面は十進文字列が必要です")
    color = data["to_move"]
    if color not in ("black", "white", None):
        raise ValueError("手番が不正です")
    state = (
        Rules()
        .from_board(Board(int(data["black"]), int(data["white"])), color or "black")
        .state
    )
    if state.to_move != color:
        raise ValueError("盤面と手番が一致しません")
    return data, data["game_id"], data["revision"], state


class WorkerSession:
    """入力復元と探索sliceの駆動だけを担当する。"""

    def __init__(self) -> None:
        self._search: ContinuousSearch | None = None
        self._game_id = 0
        self._revision = 0
        self._state: GameState | None = None

    @property
    def phase(self) -> SearchPhase:
        """JavaScriptが次のtimerを予約するか判断する状態。"""
        return self._search.phase if self._search is not None else "CLOSED"

    def start(self, raw: str) -> None:
        """開始時だけ設定とseedを復元する。"""
        if self._search is not None:
            raise RuntimeError("探索は開始済みです")
        data, game_id, revision, state = _read(raw, "start")
        if data["color"] not in ("black", "white"):
            raise ValueError("CPU色が不正です")
        seed = data["seed"]
        if not isinstance(seed, str) or not seed.isascii() or not seed.isdecimal():
            raise ValueError("seedは十進文字列が必要です")
        seed_value = int(seed)
        validate_seed(seed_value)
        config: SearchConfig
        if data["kind"] == "mcts":
            if "node_limit" in data or "retention_depth" in data:
                raise ValueError("MCTSに保持制限は指定できません")
            config = MctsConfig(seconds=data["seconds"])
        elif data["kind"] == "monte-carlo":
            config = MonteCarloConfig(
                seconds=data["seconds"], retention_depth=data["retention_depth"]
            )
        else:
            raise ValueError("CPU方式が不正です")
        self._search = create_search(
            state, color=cast("Color", data["color"]), seed=seed_value, config=config
        )
        self._game_id, self._revision, self._state = game_id, revision, state

    def update(self, raw: str) -> None:
        """同一通知は無操作、過去通知は破棄して新局面を渡す。"""
        if self._search is None:
            raise RuntimeError("探索が開始されていません")
        data, game_id, revision, state = _read(raw, "update")
        if set(data) != {"type", "game_id", "revision", "black", "white", "to_move"}:
            raise ValueError("更新には局面だけを指定します")
        if game_id != self._game_id:
            raise ValueError("対局IDが一致しません")
        if revision < self._revision:
            return
        if revision == self._revision:
            if state != self._state:
                raise ValueError("同revisionの局面が一致しません")
            return
        self._search.update(state)
        self._revision, self._state = revision, state

    def tick(self) -> str:
        """探索を一度進め、確定した結果だけを返す。"""
        if (
            self._search is None
            or self._state is None
            or self.phase in ("READY", "CLOSED")
        ):
            return ""
        decision = self._search.run_slice(0.01)
        if decision is None:
            return ""
        return json.dumps(
            dict(
                type="decision",
                game_id=self._game_id,
                revision=self._revision,
                black=str(self._state.board.black),
                white=str(self._state.board.white),
                to_move=self._state.to_move,
                **asdict(decision),
            )
        )
