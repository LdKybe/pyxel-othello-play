"""別Pyodideから呼ぶPython探索入口。対局状態を共有しない。"""

import json

from othello.core import Board, Rules
from othello.cpu import MonteCarloStrategy


def choose(raw: str) -> str:
    """通信の盤面コピーを復元し、指定回数を同期的に完走する。"""
    data = json.loads(raw)
    if not isinstance(data, dict):
        raise TypeError("探索要求はobjectが必要です")
    request_id = data["id"]
    if type(request_id) is not int or not 0 < request_id < 2**53:
        raise ValueError("要求IDが不正です")
    if data["to_move"] not in ("black", "white"):
        raise ValueError("手番が不正です")
    for name in ("black", "white", "seed"):
        if (
            not isinstance(data[name], str)
            or not data[name].isascii()
            or not data[name].isdecimal()
        ):
            raise ValueError("盤面とseedは10進文字列が必要です")
    state = (
        Rules()
        .from_board(Board(int(data["black"]), int(data["white"])), data["to_move"])
        .state
    )
    square = MonteCarloStrategy(data["rollouts"]).choose_move(
        state, seed=int(data["seed"])
    )
    return json.dumps({"id": request_id, "square": square})
