"""a1=0、h1=7、a8=56、h8=63の座標変換。

ビット位置はrow * 8 + col。行は下方向へ増え、画面ピクセルとは無関係。
文字座標の解釈を入口に集め、CLIと表示で盤面の向きがずれるのを防ぐ。
"""

from .model import CoordinateError, Square

_SQUARE_COUNT = 64
_COORDINATE_LENGTH = 2


def parse_square(text: str) -> Square:
    """文字で指定されたマスを0〜63の番号に変換する。

    Args:
        text: a1〜h8の座標。前後の空白と英字の大文字・小文字を許容する。

    Returns:
        行番号×8＋列番号で表すマス番号。例: "D3"は19。

    Raises:
        CoordinateError: 文字列でない、またはa1〜h8の形式ではない。
    """
    if not isinstance(text, str):
        raise CoordinateError("Coordinate must be a string")
    value = text.strip().lower()
    if (
        len(value) != _COORDINATE_LENGTH
        or value[0] not in "abcdefgh"
        or value[1] not in "12345678"
    ):
        raise CoordinateError("Coordinate must be a1 through h8")
    return (ord(value[1]) - ord("1")) * 8 + ord(value[0]) - ord("a")


def format_square(square: Square) -> str:
    """マス番号を小文字の座標表記に変換する。

    Args:
        square: 0〜63の整数。boolは受け付けない。

    Returns:
        a1〜h8の2文字。

    Raises:
        CoordinateError: 整数でない、または範囲外。
    """
    if type(square) is not int or not 0 <= square < _SQUARE_COUNT:
        raise CoordinateError("Square must be an integer in [0, 64)")
    return chr(ord("a") + square % 8) + str(square // 8 + 1)
