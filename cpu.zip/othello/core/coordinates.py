"""a1=0、h1=7、a8=56、h8=63の座標変換。

ビット位置はrow * 8 + col。行は下方向へ増え、画面ピクセルとは無関係。
文字座標の解釈を入口に集め、CLIと表示で盤面の向きがずれるのを防ぐ。
"""

from .model import CoordinateError, Square

_SQUARE_COUNT = 64
_COORDINATE_LENGTH = 2


def parse_square(text: str) -> Square:
    """前後の空白とASCII英字の大小を正規化する。"""
    if not isinstance(text, str):
        raise CoordinateError("Coordinate must be a string")
    value = text.strip().lower()
    if (
        len(value) != _COORDINATE_LENGTH
        or value[0] not in "abcdefgh"
        or value[1] not in "12345678"
    ):
        raise CoordinateError("Coordinate must be a1 through h8")
    return (ord(value[1]) - ord("1")) * 8 + ord(value[0]) - ord("a")


def format_square(square: Square) -> str:
    """0..63を小文字座標へ戻す。boolを整数座標として受け入れない。"""
    if type(square) is not int or not 0 <= square < _SQUARE_COUNT:
        raise CoordinateError("Square must be an integer in [0, 64)")
    return chr(ord("a") + square % 8) + str(square // 8 + 1)
