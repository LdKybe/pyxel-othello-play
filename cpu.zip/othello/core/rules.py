"""履歴を持たず、新しい局面と出来事を返す対局サービス。

盤面の整数演算はbitboardに任せ、着手の検証と手番の進行をここへ集約する。
入力は書き換えないため、呼び出し側が履歴や探索の分岐を自由に保持できる。
"""

from .bitboard import flips, legal_mask
from .model import (
    Board,
    Color,
    GameEnded,
    GameOverError,
    GameState,
    IllegalMoveError,
    MovePlayed,
    Outcome,
    Square,
    Transition,
    TurnPassed,
)

_SQUARE_COUNT = 64


class Rules:
    """状態を保持しない、公開対局ルール。"""

    __slots__ = ()

    def initial(self) -> GameState:
        """黒番の標準初期局面を返す。"""
        return GameState(Board((1 << 28) | (1 << 35), (1 << 27) | (1 << 36)), "black")

    def legal_moves(self, state: GameState) -> tuple[Square, ...]:
        """現在の手番の合法手を座標の昇順で返す。"""
        if state.to_move is None:
            return ()
        remaining = legal_mask(state.board, state.to_move)
        squares = []
        # 最下位ビットから取り出して、内部の方向走査順によらず昇順にする。
        while remaining:
            bit = remaining & -remaining
            squares.append(bit.bit_length() - 1)
            remaining ^= bit
        return tuple(squares)

    def apply_move(self, state: GameState, square: Square) -> Transition:
        # 終局を先に拒否し、入力マスが不正でもGameOverErrorを優先する。
        """合法な着手を適用し、自動パスと終局を含む遷移を返す。

        Args:
            state: Rulesで正規化した入力局面。
            square: 着手先の座標（a1=0、h8=63）。

        Returns:
            入力を書き換えずに生成した局面とイベント列。

        Raises:
            GameOverError: 入力局面が終局済み。
            IllegalMoveError: 座標が不正、または反転できる石がない。
        """
        if state.to_move is None:
            raise GameOverError("The game has ended")
        if type(square) is not int or not 0 <= square < _SQUARE_COUNT:
            raise IllegalMoveError("Square must be an integer in [0, 64)")
        flipped = flips(state.board, state.to_move, square)
        if not flipped:
            raise IllegalMoveError("Move must capture at least one opposing disc")
        move = 1 << square
        next_color: Color
        if state.to_move == "black":
            board = Board(
                state.board.black | move | flipped, state.board.white ^ flipped
            )
            next_color = "white"
        else:
            board = Board(
                state.board.black ^ flipped, state.board.white | move | flipped
            )
            next_color = "black"
        normalized = self.from_board(board, next_color)
        return Transition(
            normalized.state,
            (MovePlayed(state.to_move, square, flipped), *normalized.events),
        )

    def counts(self, board: Board) -> tuple[int, int]:
        """盤上の黒石数と白石数をこの順で返す。"""
        return board.black.bit_count(), board.white.bit_count()

    def from_board(self, board: Board, to_move: Color) -> Transition:
        """指定局面と着手後の両方で、同じパス・終局判定を使う。"""
        if legal_mask(board, to_move):
            return Transition(GameState(board, to_move), ())
        other: Color = "white" if to_move == "black" else "black"
        if legal_mask(board, other):
            return Transition(GameState(board, other), (TurnPassed(to_move),))
        # 両色が打てなければ直ちに終局。実際には行われないパスを付けない。
        return Transition(
            GameState(board, None), (GameEnded(self._final_outcome(board)),)
        )

    def outcome(self, state: GameState) -> Outcome | None:
        """終局なら勝敗を返し、進行中ならNoneを返す。"""
        if state.to_move is not None:
            return None
        return self._final_outcome(state.board)

    def _final_outcome(self, board: Board) -> Outcome:
        black, white = self.counts(board)
        winner: Color | None = None
        if black > white:
            winner = "black"
        elif white > black:
            winner = "white"
        # 終局で空きが残っていても、勝者へ加算せず盤上の石だけを数える。
        return Outcome(black, white, winner)
