"""合法手を一度計算して局面へ保持し、着手と正規化を一箇所で確定する。"""

from dataclasses import dataclass
from typing import assert_never

from .bitboard import flips, legal_mask
from .model import (
    Board,
    Color,
    Finished,
    FinishedPosition,
    IllegalMoveError,
    LegalMoves,
    MovePlayed,
    Outcome,
    Passed,
    PlayingPosition,
    Position,
    Square,
    Transition,
)


@dataclass(frozen=True, slots=True)
class _PlayingPosition(PlayingPosition):
    _board: Board
    _to_move: Color
    _legal_moves: LegalMoves

    @property
    def board(self) -> Board:
        return self._board

    @property
    def to_move(self) -> Color:
        return self._to_move

    @property
    def legal_moves(self) -> LegalMoves:
        return self._legal_moves


@dataclass(frozen=True, slots=True)
class _FinishedPosition(FinishedPosition):
    _board: Board
    _outcome: Outcome

    @property
    def board(self) -> Board:
        return self._board

    @property
    def outcome(self) -> Outcome:
        return self._outcome


def _moves(board: Board, color: Color) -> LegalMoves | None:
    remaining = legal_mask(board, color)
    if not remaining:
        return None
    first = remaining & -remaining
    remaining ^= first
    following = []
    while remaining:
        bit = remaining & -remaining
        following.append(bit.bit_length() - 1)
        remaining ^= bit
    return (first.bit_length() - 1, *following)


def _outcome(board: Board) -> Outcome:
    black, white = board.black.bit_count(), board.white.bit_count()
    winner: Color | None = None
    if black > white:
        winner = "black"
    elif white > black:
        winner = "white"
    return Outcome(black, white, winner)


class Rules:
    """履歴を持たず、整合した局面と着手の遷移を生成する。

    Boardは構築時に盤面の値域・重複を検証済み。ここでは手番の合法手と
    終局を判定する。生成した局面を各利用側で再検証する必要はない。
    """

    __slots__ = ()

    @staticmethod
    def initial() -> PlayingPosition:
        """標準初期配置・黒手番と、その合法手を返す。"""
        board = Board((1 << 28) | (1 << 35), (1 << 27) | (1 << 36))
        moves = _moves(board, "black")
        if moves is None:
            raise RuntimeError("Initial board must have legal moves")
        return _PlayingPosition(_board=board, _to_move="black", _legal_moves=moves)

    @staticmethod
    def restore(board: Board, next_player: Color) -> Position:
        """盤面と次の手番から、パス・終局を正規化した局面を復元する。

        手番に手がなければ相手へ移り、両者に手がなければ終局する。
        復元は実着手ではないのでイベントを返さない。

        Raises:
            ValueError: next_playerがblack・white以外。
        """
        moves = _moves(board, next_player)
        if moves is not None:
            return _PlayingPosition(
                _board=board, _to_move=next_player, _legal_moves=moves
            )
        other: Color = "white" if next_player == "black" else "black"
        moves = _moves(board, other)
        if moves is not None:
            return _PlayingPosition(_board=board, _to_move=other, _legal_moves=moves)
        return _FinishedPosition(_board=board, _outcome=_outcome(board))

    @staticmethod
    def play(position: PlayingPosition, square: Square) -> Transition:
        """対局中の局面へ合法手を適用し、着手・パス・終局を順に返す。

        元の値は変更しない。終局型はこの操作の引数にならない。

        Raises:
            IllegalMoveError: squareが整数の合法手ではない。
        """
        if type(square) is not int or square not in position.legal_moves:
            raise IllegalMoveError("Square must be a legal integer move")
        flipped = flips(position.board, position.to_move, square)
        move = 1 << square
        next_color: Color
        if position.to_move == "black":
            board = Board(
                position.board.black | move | flipped, position.board.white ^ flipped
            )
            next_color = "white"
        else:
            board = Board(
                position.board.black ^ flipped, position.board.white | move | flipped
            )
            next_color = "black"
        after = Rules.restore(board, next_color)
        played = MovePlayed(position.to_move, square, flipped)
        match after:
            case PlayingPosition(to_move=color):
                events = (
                    (played,) if color == next_color else (played, Passed(next_color))
                )
                return Transition(position=after, events=events)
            case FinishedPosition(outcome=outcome):
                return Transition(position=after, events=(played, Finished(outcome)))
            case _:
                assert_never(after)

    @staticmethod
    def counts(board: Board) -> tuple[int, int]:
        """盤上の黒石数・白石数を返す。空きマスは加算しない。"""
        return board.black.bit_count(), board.white.bit_count()
