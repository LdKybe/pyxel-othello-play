"""表示・入力に依存しないオセロの公開入口。"""

from .coordinates import format_square, parse_square
from .model import (
    Board,
    Color,
    CoordinateError,
    Finished,
    FinishedPosition,
    GameEvent,
    GameOverError,
    IllegalMoveError,
    InvalidBoardError,
    LegalMoves,
    MovePlayed,
    Outcome,
    Passed,
    PlayingPosition,
    Position,
    Square,
    Transition,
)
from .rules import Rules

__all__ = [
    "Board",
    "Color",
    "CoordinateError",
    "Finished",
    "FinishedPosition",
    "GameEvent",
    "GameOverError",
    "IllegalMoveError",
    "InvalidBoardError",
    "LegalMoves",
    "MovePlayed",
    "Outcome",
    "Passed",
    "PlayingPosition",
    "Position",
    "Rules",
    "Square",
    "Transition",
    "format_square",
    "parse_square",
]
