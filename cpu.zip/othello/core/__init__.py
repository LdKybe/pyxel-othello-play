"""表示・入力に依存しないオセロの公開入口。"""

from .coordinates import format_square, parse_square
from .model import (
    Board,
    Color,
    CoordinateError,
    GameEnded,
    GameEvent,
    GameOverError,
    GameState,
    IllegalMoveError,
    InvalidBoardError,
    MovePlayed,
    Outcome,
    Square,
    Transition,
    TurnPassed,
)
from .rules import Rules

__all__ = [
    "Board",
    "Color",
    "CoordinateError",
    "GameEnded",
    "GameEvent",
    "GameOverError",
    "GameState",
    "IllegalMoveError",
    "InvalidBoardError",
    "MovePlayed",
    "Outcome",
    "Rules",
    "Square",
    "Transition",
    "TurnPassed",
    "format_square",
    "parse_square",
]
