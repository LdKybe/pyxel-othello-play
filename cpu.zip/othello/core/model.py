"""盤面と遷移の値契約。

同じ局面をCPU探索などで共有できるよう、作成済みの値を書き換えず、更新後の値を別に作る。
手番の合法性や終局判定はRulesの責任であり、値型からルールへ逆依存しない。
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Literal, TypeAlias

Color = Literal["black", "white"]
Square = int


class InvalidBoardError(ValueError):
    """盤面の型、範囲または占有の不変条件に違反している。"""


class CoordinateError(ValueError):
    """座標の表現または範囲が正しくない。"""


class IllegalMoveError(ValueError):
    """進行中の局面に対する着手が合法でない。"""


class GameOverError(ValueError):
    """終局後の着手である。"""


@dataclass(frozen=True, slots=True)
class Board:
    """8×8盤の黒石と白石の配置を保持する、変更不可の値。

    各整数のビットが1なら、そのマスに石がある。ビット番号はa1=0、h1=7、
    a8=56、h8=63で、行ごとに左から右へ増える。手番はPlayingPositionが保持する。

    Attributes:
        black: 黒石の配置を表す64ビットの非負整数。
        white: 白石の配置を表す64ビットの非負整数。黒石と同じビットは立てられない。

    Raises:
        InvalidBoardError: 整数以外（boolを含む）、64ビットの範囲外、
            または黒白の重複がある。
    """

    black: int
    white: int

    def __post_init__(self) -> None:
        # boolもintの派生型なのでisinstanceでは除けない。任意精度整数の
        # 上位ビットも拒否し、全ての計算が同じ64マスを扱うことを保証する。
        for value in (self.black, self.white):
            if type(value) is not int or not 0 <= value < 2**64:
                raise InvalidBoardError("Bitboards must be integers in [0, 2**64)")
        if self.black & self.white:
            raise InvalidBoardError("Black and white must not overlap")


@dataclass(frozen=True, slots=True)
class Outcome:
    """終局時の石数と勝者。

    Attributes:
        black_count: 盤上に残った黒石の数。空きマスは加算しない。
        white_count: 盤上に残った白石の数。
        winner: 石数が多い色。Noneは同数による引き分け。
    """

    black_count: int
    white_count: int
    winner: Color | None


LegalMoves: TypeAlias = tuple[Square, *tuple[Square, ...]]


class PlayingPosition(ABC):
    """Rulesだけが生成する、合法手を持つ読み取り専用の局面。

    実体はcore内のfrozen値。合法手の計算と構築をRulesに集約し、
    呼出し側から未検証のキャッシュを受け取るコンストラクターを公開しない。
    """

    __slots__ = ()

    @property
    @abstractmethod
    def board(self) -> Board:
        """現在の石の配置。"""

    @property
    @abstractmethod
    def to_move(self) -> Color:
        """少なくとも一つ合法手を持つ手番。"""

    @property
    @abstractmethod
    def legal_moves(self) -> LegalMoves:
        """構築時に求めた、昇順かつ非空の合法手。再計算しない。"""


class FinishedPosition(ABC):
    """両者に合法手がないことをRulesが確定した読み取り専用の局面。"""

    __slots__ = ()

    @property
    @abstractmethod
    def board(self) -> Board:
        """終局時の石の配置。"""

    @property
    @abstractmethod
    def outcome(self) -> Outcome:
        """この盤面から算出した終局結果。"""


Position: TypeAlias = PlayingPosition | FinishedPosition


@dataclass(frozen=True, slots=True)
class MovePlayed:
    """受理された1手と、その着手で反転した石を表すイベント。

    Attributes:
        color: 着手した色。
        square: 置いたマスの番号（a1=0〜h8=63）。
        flipped: 反転した相手石のビット集合。新しく置いた石は含まない。
    """

    color: Color
    square: Square
    flipped: int


@dataclass(frozen=True, slots=True)
class Passed:
    """合法手がなく、相手へ手番を渡したことを表すイベント。

    Attributes:
        color: 打てずにパスした色。
    """

    color: Color


@dataclass(frozen=True, slots=True)
class Finished:
    """両者に合法手がなくなり、終局したことを表すイベント。

    Attributes:
        outcome: 終局時の石数と勝敗。
    """

    outcome: Outcome


GameEvent = MovePlayed | Passed | Finished


@dataclass(frozen=True, slots=True)
class Transition:
    """ルールを適用した後の局面と、その操作で起きた出来事。

    元の局面は変更しない。play()のイベントは着手から始まり、
    必要に応じてパスまたは終局が続く。復元はイベントを発生させない。

    Attributes:
        position: 自動パスと終局判定を済ませた、新しい局面。
        events: 着手・パス・終局のイベントを発生順に並べたタプル。着手を先頭に持つ。
    """

    position: Position
    events: tuple[GameEvent, ...]
