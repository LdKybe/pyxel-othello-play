"""盤面と遷移の値契約。

同じ局面をCPU探索などで共有できるよう、値を凍結して更新を新規生成にする。
手番の合法性や終局判定はRulesの責任であり、値型からルールへ逆依存しない。
"""

from dataclasses import dataclass
from typing import Literal

Color = Literal["black", "white"]
Square = int


class InvalidBoardError(ValueError):
    """盤面の型、範囲または占有の不変条件に違反している。"""


class CoordinateError(ValueError):
    """座標の表現または範囲が正しくない。"""


class IllegalMoveError(ValueError):
    """進行中の局面に対する着手が合法でない。"""


class GameOverError(ValueError):
    """終局後の着手である。"""


@dataclass(frozen=True, slots=True)
class Board:
    """黒白の非重複な64ビット盤面を保持する。"""

    black: int
    white: int

    def __post_init__(self) -> None:
        # boolもintの派生型なのでisinstanceでは除けない。任意精度整数の
        # 上位ビットも拒否し、全ての計算が同じ64マスを扱うことを保証する。
        for value in (self.black, self.white):
            if type(value) is not int or not 0 <= value < 2**64:
                raise InvalidBoardError("Bitboards must be integers in [0, 2**64)")
        if self.black & self.white:
            raise InvalidBoardError("Black and white must not overlap")


@dataclass(frozen=True, slots=True)
class GameState:
    """Rules経由で生成する。None手番は両者に合法手がない終局だけを表す。"""

    board: Board
    to_move: Color | None


@dataclass(frozen=True, slots=True)
class Outcome:
    """終局時だけ返す結果。winner=Noneは未決着でなく引き分け。"""

    black_count: int
    white_count: int
    winner: Color | None


@dataclass(frozen=True, slots=True)
class MovePlayed:
    """受理した着手と反転した石のビット集合。"""

    color: Color
    square: Square
    flipped: int


@dataclass(frozen=True, slots=True)
class TurnPassed:
    """合法手がなく手番を渡した色。"""

    color: Color


@dataclass(frozen=True, slots=True)
class GameEnded:
    """両者が着手できなくなった対局の結果。"""

    outcome: Outcome


GameEvent = MovePlayed | TurnPassed | GameEnded


@dataclass(frozen=True, slots=True)
class Transition:
    """操作後の不変局面と発生順のイベント列。"""

    state: GameState
    events: tuple[GameEvent, ...]
