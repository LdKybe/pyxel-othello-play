"""整数だけを使う合法手と反転の計算。

a1が最下位ビット。左右への移動では元のa列/h列を除かないと隣の行へ
回り込む。Pythonの整数は任意精度なので左シフトと反転を64ビットに制限する。
"""

from .model import Board, Color, Square

_SQUARE_COUNT = 64

_FULL = (1 << 64) - 1
_NOT_A = _FULL ^ 0x0101010101010101
_NOT_H = _FULL ^ 0x8080808080808080
# (ビット移動量, 移動元に許す列)。斜めも移動元で左右端を落とす。
_DIRECTIONS = (
    (-9, _NOT_A),
    (-8, _FULL),
    (-7, _NOT_H),
    (-1, _NOT_A),
    (1, _NOT_H),
    (7, _NOT_A),
    (8, _FULL),
    (9, _NOT_H),
)


def _shift(bits: int, offset: int, source_mask: int) -> int:
    bits &= source_mask
    return ((bits << offset) & _FULL) if offset > 0 else bits >> -offset


def _stones(board: Board, color: Color) -> tuple[int, int]:
    if color == "black":
        return board.black, board.white
    if color == "white":
        return board.white, board.black
    raise ValueError("Color must be black or white")


def legal_mask(board: Board, color: Color) -> int:
    """指定色が着手できるマスをビット集合で返す。

    Args:
        board: 黒白の石の配置。
        color: 合法手を調べる色。

    Returns:
        合法手の位置だけを1にした64ビット整数。合法手がなければ0。

    Raises:
        ValueError: 色がblack・white以外。
    """
    own, opponent = _stones(board, color)
    empty = ~(own | opponent) & _FULL
    legal = 0
    for offset, source_mask in _DIRECTIONS:
        ray = _shift(own, offset, source_mask) & opponent
        # 8マスの直線で両端を挟むと相手石は最大6個。先頭+5回で十分。
        for _ in range(5):
            ray |= _shift(ray, offset, source_mask) & opponent
        legal |= _shift(ray, offset, source_mask) & empty
    return legal


def flips(board: Board, color: Color, square: Square) -> int:
    """指定マスへの着手で反転する相手石を調べる。

    Args:
        board: 着手前の石の配置。
        color: 着手する色。
        square: 着手先のマス番号（0〜63）。

    Returns:
        反転する石のビット集合。占有済みのマスや反転のない手では0。

    Raises:
        ValueError: 色またはマス番号の型・範囲が不正。
    """
    own, opponent = _stones(board, color)
    if type(square) is not int or not 0 <= square < _SQUARE_COUNT:
        raise ValueError("Square must be an integer in [0, 64)")
    move = 1 << square
    if move & (own | opponent):
        return 0
    flipped = 0
    for offset, source_mask in _DIRECTIONS:
        cursor = _shift(move, offset, source_mask)
        captured = 0
        while cursor & opponent:
            captured |= cursor
            cursor = _shift(cursor, offset, source_mask)
        if cursor & own:
            flipped |= captured
    return flipped
