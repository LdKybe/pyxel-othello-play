"""保存済み推論モデルの形式検証と読込み。"""

from __future__ import annotations

import base64
import binascii
import hashlib
import json
import re
from typing import TYPE_CHECKING, TypeAlias

from .model import FORMAT_VERSION, FrozenValueModel, ModelTrainingInfo
from .patterns import PATTERN_SET_ID, PATTERNS, STAGE_COUNT, WEIGHT_BYTES

_MAX_MODEL_BYTES = 80 * 1024 * 1024
_BASE64_LENGTH = 4 * ((WEIGHT_BYTES + 2) // 3)
_MAX_SEED_DIGITS = len(str(2**256 - 1))
_TOP_LEVEL_KEYS = frozenset(
    {
        "format_version",
        "pattern_set_id",
        "patterns",
        "symmetry",
        "stages",
        "perspective",
        "target",
        "dtype",
        "weights",
        "training",
        "model_id",
    }
)
_TRAINING_KEYS = frozenset(
    {"games", "alpha", "epsilon", "seed", "algorithm", "implementation_version"}
)
_DECIMAL = re.compile(r"[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?\Z")
_UNSIGNED_DECIMAL = re.compile(r"[0-9]+\Z")
_LOWER_SHA256 = re.compile(r"[0-9a-f]{64}\Z")

if TYPE_CHECKING:
    from collections.abc import Mapping
    from pathlib import Path

_JsonValue: TypeAlias = (
    bool | int | float | str | list["_JsonValue"] | dict[str, "_JsonValue"] | None
)


class ModelFormatError(ValueError):
    """モデル内容が対応する形式に合わない。"""


def _reject_constant(value: str) -> None:
    raise ModelFormatError(f"JSON non-finite value is not supported: {value}")


def _unique_object(pairs: list[tuple[str, _JsonValue]]) -> dict[str, _JsonValue]:
    result: dict[str, _JsonValue] = {}
    for key, value in pairs:
        if key in result:
            raise ModelFormatError(f"Duplicate JSON key: {key}")
        result[key] = value
    return result


def _json_bytes(value: _JsonValue) -> bytes:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    ).encode("utf-8")


def _canonical_model_id(fields: Mapping[str, _JsonValue]) -> str:
    """大きなweightsを分割し、通常の正準JSONと同じSHA256を返す。"""
    digest = hashlib.sha256()
    digest.update(b"{")
    for index, key in enumerate(sorted(fields)):
        if index:
            digest.update(b",")
        digest.update(_json_bytes(key))
        digest.update(b":")
        value = fields[key]
        if key == "weights":
            if type(value) is not str:
                raise ModelFormatError("weights must be a base64 string")
            digest.update(b'"')
            for offset in range(0, len(value), 64 * 1024):
                digest.update(value[offset : offset + 64 * 1024].encode("ascii"))
            digest.update(b'"')
        else:
            digest.update(_json_bytes(value))
    digest.update(b"}")
    return digest.hexdigest()


def _fields(
    value: _JsonValue, required: frozenset[str], label: str
) -> dict[str, _JsonValue]:
    if type(value) is not dict:
        raise ModelFormatError(f"{label} must be an object")
    fields = value
    if fields.keys() != required:
        missing = sorted(required - fields.keys())
        unknown = sorted(fields.keys() - required)
        raise ModelFormatError(
            f"{label} fields invalid: missing={missing}, unknown={unknown}"
        )
    return fields


def _fixed(value: _JsonValue, expected: _JsonValue, label: str) -> None:
    if type(value) is not type(expected) or value != expected:
        raise ModelFormatError(f"Unsupported {label}")


def _patterns(value: _JsonValue) -> None:
    if type(value) is not list or len(value) != len(PATTERNS):
        raise ModelFormatError("Invalid patterns definition")
    for stored, known in zip(value, PATTERNS, strict=True):
        if (
            type(stored) is not list
            or len(stored) != len(known.base)
            or any(type(square) is not int for square in stored)
            or tuple(stored) != known.base
        ):
            raise ModelFormatError("Invalid patterns definition")


def _decimal(value: _JsonValue, label: str) -> float:
    if type(value) is not str or _DECIMAL.fullmatch(value) is None:
        raise ModelFormatError(f"training {label} must be a decimal string")
    return float(value)


def _text(value: _JsonValue, label: str) -> str:
    if type(value) is not str:
        raise ModelFormatError(f"training {label} must be a string")
    return value


def _training(value: _JsonValue) -> ModelTrainingInfo:
    fields = _fields(value, _TRAINING_KEYS, "training")
    games = fields["games"]
    if type(games) is not int:
        raise ModelFormatError("training games must be an integer")
    seed_text = fields["seed"]
    if type(seed_text) is not str or _UNSIGNED_DECIMAL.fullmatch(seed_text) is None:
        raise ModelFormatError("training seed must be a decimal string in range")
    significant_seed = seed_text.lstrip("0") or "0"
    if len(significant_seed) > _MAX_SEED_DIGITS:
        raise ModelFormatError("training seed must be a decimal string in range")
    try:
        return ModelTrainingInfo(
            games=games,
            alpha=_decimal(fields["alpha"], "alpha"),
            epsilon=_decimal(fields["epsilon"], "epsilon"),
            seed=int(significant_seed),
            algorithm=_text(fields["algorithm"], "algorithm"),
            implementation_version=_text(
                fields["implementation_version"], "implementation_version"
            ),
        )
    except (OverflowError, TypeError, ValueError) as error:
        raise ModelFormatError(f"Invalid training metadata: {error}") from error


def load_model(path: Path) -> FrozenValueModel:
    """保存モデルをファイルから読み込む。I/O例外はそのまま伝える。"""
    with path.open("rb") as stream:
        data = stream.read(_MAX_MODEL_BYTES + 1)
    return load_model_bytes(data)


def _parse_json(data: bytes) -> _JsonValue:
    """UTF-8とJSON構文を検査し、重複キーを拒否する。"""
    try:
        parsed: _JsonValue = json.loads(
            data.decode("utf-8"),
            object_pairs_hook=_unique_object,
            parse_constant=_reject_constant,
        )
    except ModelFormatError:
        raise
    except UnicodeDecodeError as error:
        raise ModelFormatError("Model must be UTF-8") from error
    except (json.JSONDecodeError, RecursionError, ValueError) as error:
        raise ModelFormatError(f"Invalid JSON: {error}") from error
    else:
        return parsed


def _metadata(fields: dict[str, _JsonValue]) -> ModelTrainingInfo:
    """固定形式と学習条件を検査する。"""
    _fixed(fields["format_version"], FORMAT_VERSION, "format_version")
    _fixed(fields["pattern_set_id"], PATTERN_SET_ID, "pattern_set_id")
    _patterns(fields["patterns"])
    _fixed(fields["symmetry"], "d4-unique-placement-stabilizer-packed-v1", "symmetry")
    _fixed(fields["stages"], STAGE_COUNT, "stages")
    _fixed(fields["perspective"], "black", "perspective")
    _fixed(fields["target"], "terminal-disc-difference", "target")
    _fixed(fields["dtype"], "float64-le", "dtype")
    return _training(fields["training"])


def _weight_bytes(encoded: _JsonValue) -> bytes:
    """base64の厳格な復号と長さの検査を行う。"""
    if type(encoded) is not str:
        raise ModelFormatError("weights must be a base64 string")
    if len(encoded) != _BASE64_LENGTH:
        raise ModelFormatError("Invalid weight byte length")
    try:
        weights = base64.b64decode(encoded, validate=True)
    except (ValueError, binascii.Error) as error:
        raise ModelFormatError("Invalid weights base64") from error
    if len(weights) != WEIGHT_BYTES:
        raise ModelFormatError("Invalid weight byte length")
    return weights


def load_model_bytes(data: bytes) -> FrozenValueModel:
    """形式v2のUTF-8 JSONを検証して不変モデルを返す。"""
    if type(data) is not bytes:
        raise ModelFormatError("Model input must be bytes")
    if len(data) > _MAX_MODEL_BYTES:
        raise ModelFormatError("Model exceeds 80 MiB input limit")
    fields = _fields(_parse_json(data), _TOP_LEVEL_KEYS, "model")
    training = _metadata(fields)
    model_id = fields["model_id"]
    if type(model_id) is not str or _LOWER_SHA256.fullmatch(model_id) is None:
        raise ModelFormatError("Invalid model_id")
    weights = _weight_bytes(fields["weights"])
    try:
        expected_id = _canonical_model_id(
            {key: value for key, value in fields.items() if key != "model_id"}
        )
    except (UnicodeError, ValueError, TypeError) as error:
        raise ModelFormatError(f"Invalid canonical model content: {error}") from error
    if model_id != expected_id:
        raise ModelFormatError("model_id does not match model content")
    try:
        return FrozenValueModel(model_id=model_id, weights=weights, training=training)
    except (TypeError, ValueError) as error:
        raise ModelFormatError(f"Invalid weight values: {error}") from error
