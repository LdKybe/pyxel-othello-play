"""不変の盤面期待値と学習・推論で共有する純粋評価計算。"""

from __future__ import annotations

from dataclasses import dataclass
from math import fsum, isfinite
from struct import iter_unpack, unpack_from
from typing import TYPE_CHECKING

from othello.core import FinishedPosition, PlayingPosition

from .patterns import PATTERN_SET_ID, WEIGHT_BYTES, pattern_indices

if TYPE_CHECKING:
    from collections.abc import Callable, Iterable

    from othello.core import Color, Position

MAX_WEIGHT = 1024.0
FORMAT_VERSION = 2
MODEL_ID_LENGTH = 64
ALGORITHM_ID = "td0-normalized-v1"


@dataclass(frozen=True, slots=True)
class ModelTrainingInfo:
    """モデル本体に含む、保存地点までの学習条件。"""

    games: int
    alpha: float
    epsilon: float
    seed: int
    algorithm: str
    implementation_version: str

    def __post_init__(self) -> None:
        """保存可能な条件のみを不変値として受け入れる。"""
        if type(self.games) is not int or self.games < 0:
            raise ValueError("Training games must be a nonnegative integer")
        if (
            type(self.alpha) is not float
            or not isfinite(self.alpha)
            or not 0 < self.alpha <= 1
        ):
            raise ValueError("Training alpha must be finite in (0, 1]")
        if (
            type(self.epsilon) is not float
            or not isfinite(self.epsilon)
            or not 0 <= self.epsilon <= 1
        ):
            raise ValueError("Training epsilon must be finite in [0, 1]")
        if type(self.seed) is not int or not 0 <= self.seed < 2**256:
            raise ValueError("Training seed must be an integer in [0, 2**256)")
        if self.algorithm != ALGORITHM_ID:
            raise ValueError("Unknown training algorithm")
        if (
            type(self.implementation_version) is not str
            or not self.implementation_version
        ):
            raise ValueError("Training implementation version must be nonempty")


def evaluate_with_weights(
    state: Position, perspective: Color, weight_at: Callable[[int], float]
) -> float:
    """学習表と凍結表が共有する、石単位の評価計算。"""
    if perspective not in ("black", "white"):
        raise ValueError("Perspective must be black or white")
    raw = raw_black_value_with_weights(state, weight_at)
    value = raw if isinstance(state, FinishedPosition) else max(-64.0, min(64.0, raw))
    return value if perspective == "black" else -value


def sum_pattern_weights(
    indices: Iterable[int], weight_at: Callable[[int], float]
) -> float:
    """参照の重複を保ち、順序に依存しない安定和を返す。"""
    return fsum(sorted(weight_at(index) for index in indices))


def raw_black_value_with_weights(
    state: Position, weight_at: Callable[[int], float]
) -> float:
    """学習時のclip前評価を返す。"""
    if isinstance(state, FinishedPosition):
        return float(state.outcome.black_count - state.outcome.white_count)
    if not isinstance(state, PlayingPosition):
        raise TypeError("State must be a core position")
    board = state.board
    stage = board.black.bit_count() + board.white.bit_count() - 4
    return sum_pattern_weights(
        pattern_indices(board.black, board.white, stage), weight_at
    )


@dataclass(frozen=True, slots=True)
class FrozenValueModel:
    """float64-leの不変表に基づく、黒基準の石数差推定。"""

    model_id: str
    weights: bytes
    training: ModelTrainingInfo
    format_version: int = FORMAT_VERSION
    pattern_set_id: str = PATTERN_SET_ID

    def __post_init__(self) -> None:
        """不変表の形式・長さ・有限性・上限を確認する。"""
        if type(self.training) is not ModelTrainingInfo:
            raise TypeError("Training metadata must be an immutable value")
        if (
            type(self.model_id) is not str
            or len(self.model_id) != MODEL_ID_LENGTH
            or any(char not in "0123456789abcdef" for char in self.model_id)
        ):
            raise ValueError("Model ID must be lowercase SHA256 hex")
        if (
            type(self.format_version) is not int
            or self.format_version != FORMAT_VERSION
        ):
            raise ValueError("Unsupported model format version")
        if self.pattern_set_id != PATTERN_SET_ID:
            raise ValueError("Unsupported pattern set")
        if type(self.weights) is not bytes:
            raise TypeError("Weights must be immutable bytes")
        if len(self.weights) != WEIGHT_BYTES:
            raise ValueError("Invalid weight byte length")
        for (weight,) in iter_unpack("<d", self.weights):
            if not isfinite(weight) or abs(weight) > MAX_WEIGHT:
                raise ValueError("Weights must be finite and within ±1024")

    def evaluate(self, state: Position, perspective: Color) -> float:
        """同じ局面と色には同じ有限の石数差推定を返す。"""
        return evaluate_with_weights(
            state,
            perspective,
            lambda index: unpack_from("<d", self.weights, index * 8)[0],
        )
