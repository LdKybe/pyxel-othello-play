"""固定N-tuple形状と対称性で共有する重み索引。"""

from __future__ import annotations

from dataclasses import dataclass
from struct import pack_into, unpack_from

PATTERN_SET_ID = "edax-shapes-12-d4-packed-v1"
STAGE_COUNT = 60
_ROTATIONS = 4
_BASES = (
    (0, 1, 8, 9, 2, 16, 10, 17, 18),
    (32, 24, 16, 8, 0, 9, 1, 2, 3, 4),
    (9, 0, 1, 2, 3, 4, 5, 6, 7, 14),
    (0, 2, 3, 10, 11, 12, 13, 4, 5, 7),
    (8, 9, 10, 11, 12, 13, 14, 15),
    (16, 17, 18, 19, 20, 21, 22, 23),
    (24, 25, 26, 27, 28, 29, 30, 31),
    (0, 9, 18, 27, 36, 45, 54, 63),
    (1, 10, 19, 28, 37, 46, 55),
    (2, 11, 20, 29, 38, 47),
    (3, 12, 21, 30, 39),
    (3, 10, 17, 24),
)


@dataclass(frozen=True, slots=True)
class Pattern:
    """一系統の配置と圧縮済み索引表。"""

    base: tuple[int, ...]
    placements: tuple[tuple[int, ...], ...]
    packed_count: int
    packed_lookup: bytes


def _transform(square: int, orientation: int) -> int:
    """I,R,R²,R³,F,RF,R²F,R³Fの順でマスを変換する。"""
    row, col = divmod(square, 8)
    if orientation >= _ROTATIONS:
        col = 7 - col
    for _ in range(orientation % _ROTATIONS):
        row, col = col, 7 - row
    return row * 8 + col


def _build_pattern(base: tuple[int, ...]) -> Pattern:
    """重複配置の除去と自己対称による表圧縮を独立して行う。"""
    placements: list[tuple[int, ...]] = []
    seen_placements: set[frozenset[int]] = set()
    position = {square: index for index, square in enumerate(base)}
    powers = tuple(3**index for index in range(len(base)))
    symmetry_powers: list[tuple[int, ...]] = []
    for orientation in range(8):
        transformed = tuple(_transform(square, orientation) for square in base)
        key = frozenset(transformed)
        if key not in seen_placements:
            seen_placements.add(key)
            placements.append(transformed)
        if key == frozenset(base):
            symmetry_powers.append(
                tuple(powers[position[square]] for square in transformed)
            )

    raw_count = 3 ** len(base)
    canonical_by_raw: list[int] = []
    for raw in range(raw_count):
        remainder = raw
        digits: list[int] = []
        for _ in base:
            remainder, digit = divmod(remainder, 3)
            digits.append(digit)
        canonical_by_raw.append(
            min(
                sum(
                    digit * power for digit, power in zip(digits, symmetry, strict=True)
                )
                for symmetry in symmetry_powers
            )
        )
    rank_by_canonical = {
        canonical: rank for rank, canonical in enumerate(sorted(set(canonical_by_raw)))
    }
    lookup = bytearray(raw_count * 4)
    for raw, canonical in enumerate(canonical_by_raw):
        pack_into("<I", lookup, raw * 4, rank_by_canonical[canonical])
    return Pattern(base, tuple(placements), len(rank_by_canonical), bytes(lookup))


PATTERNS = tuple(_build_pattern(base) for base in _BASES)
PATTERN_OFFSETS = tuple(
    sum(pattern.packed_count for pattern in PATTERNS[:index])
    for index in range(len(PATTERNS))
)
WEIGHTS_PER_STAGE = sum(pattern.packed_count for pattern in PATTERNS)
WEIGHT_COUNT = STAGE_COUNT * WEIGHTS_PER_STAGE
WEIGHT_BYTES = WEIGHT_COUNT * 8
_PLACEMENT_TERMS = tuple(
    tuple(
        tuple((square, 3**power) for power, square in enumerate(placement))
        for placement in pattern.placements
    )
    for pattern in PATTERNS
)


def pattern_indices(black: int, white: int, stage: int) -> tuple[int, ...]:
    """局面の全配置が参照する平坦重み索引を順序どおりに返す。"""
    if type(stage) is not int or not 0 <= stage < STAGE_COUNT:
        raise ValueError("Stage must be an integer in [0, 60)")
    stage_offset = stage * WEIGHTS_PER_STAGE
    indices: list[int] = []
    digits = tuple(
        ((black >> square) & 1) + 2 * ((white >> square) & 1) for square in range(64)
    )
    for pattern, pattern_offset, placements in zip(
        PATTERNS, PATTERN_OFFSETS, _PLACEMENT_TERMS, strict=True
    ):
        for placement in placements:
            raw = 0
            for square, power in placement:
                raw += digits[square] * power
            packed = unpack_from("<I", pattern.packed_lookup, raw * 4)[0]
            indices.append(stage_offset + pattern_offset + packed)
    return tuple(indices)
