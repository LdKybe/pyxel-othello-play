"""両方式の設定と外部へ渡す不変な評価値。"""

from dataclasses import dataclass
from typing import Literal, TypeAlias

from othello.core import Color, Square


@dataclass(frozen=True, slots=True)
class MonteCarloConfig:
    """追加思考秒数と統計を保持する実着手数。"""

    seconds: float = 3.0
    retention_depth: int = 6

    def __post_init__(self) -> None:
        if type(self.seconds) not in (int, float) or not 0 < self.seconds < float(
            "inf"
        ):
            raise ValueError("seconds must be a finite positive number")
        if type(self.retention_depth) is not int or self.retention_depth <= 0:
            raise ValueError("retention_depth must be a positive integer")


CpuKind: TypeAlias = Literal["monte-carlo", "mcts"]


@dataclass(frozen=True, slots=True)
class MctsConfig:
    """MCTSの自手番に追加する思考秒数。保持量の上限は持たない。"""

    seconds: float = 3.0

    def __post_init__(self) -> None:
        if type(self.seconds) not in (int, float) or not 0 < self.seconds < float(
            "inf"
        ):
            raise ValueError("seconds must be a finite positive number")


SearchConfig: TypeAlias = MonteCarloConfig | MctsConfig


@dataclass(frozen=True, slots=True)
class CandidateEvaluation:
    """自手番開始時の引継ぎ数と、その後の追加数を含む候補評価。"""

    square: Square
    visits: int
    wins: int
    draws: int
    inherited_visits: int
    added_visits: int
    win_rate: float | None


@dataclass(frozen=True, slots=True)
class SearchDecision:
    """CPU色の視点による全合法候補と選択手。"""

    square: Square
    color: Color
    candidates: tuple[CandidateEvaluation, ...]
    kind: CpuKind = "monte-carlo"


def validate_seed(seed: int) -> None:
    """Validate an externally supplied 256-bit random seed.

    Args:
        seed: Explicit seed used for one CPU in one game.

    Raises:
        ValueError: The seed is not an integer in the supported range.
    """
    if type(seed) is not int or not 0 <= seed < 2**256:
        raise ValueError("seed must be an integer in [0, 2**256)")


@dataclass(frozen=True, slots=True)
class PositionMoveKey:
    """ハッシュ衝突でも混同しない、完全な盤面・手番・候補手。"""

    black: int
    white: int
    to_move: Color
    square: Square
