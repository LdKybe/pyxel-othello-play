"""CPUが公開する確定設定と、短い計算単位の結果。"""

from dataclasses import dataclass

from othello.core import Square

from .input import CpuOption


@dataclass(frozen=True, slots=True, kw_only=True)
class ResourceIdentity:
    """検証済み資源の内容識別。取得先やモデル本体は保持しない。"""

    role: str
    content_id: str
    format_version: int


@dataclass(frozen=True, slots=True, kw_only=True)
class Reproducibility:
    """準備時に確定する再現条件。毎局の派生seedは含めない。"""

    seed_policy_id: str
    random_source_id: str
    runtime_id: str
    realtime_nondeterministic: bool


@dataclass(frozen=True, slots=True, kw_only=True)
class CpuInfo:
    """検証済みConfigからproviderが構築する設定の記録。

    effective_optionsは名前順、resourcesはrole順に正規化する。
    方式の計算は内部Configを使い、この記録を入力へ戻さない。
    """

    kind: str
    implementation_version: str
    effective_options: tuple[CpuOption, ...]
    resources: tuple[ResourceIdentity, ...]
    reproducibility: Reproducibility
    evaluation_unit: str


@dataclass(frozen=True, slots=True, kw_only=True)
class CpuDecision:
    """選択した合法手。要求との対応付けは実行側が担当する。"""

    square: Square


@dataclass(frozen=True, slots=True)
class ContinueWork:
    """観測更新がなくても、次の短い計算単位へ進める。"""


@dataclass(frozen=True, slots=True)
class AwaitObservation:
    """現在の計算を止め、観測または着手要求を待つ。"""
