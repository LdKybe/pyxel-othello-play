"""方式が検証する入力値。重複・未知項目を準備前に失わない。"""

from dataclasses import dataclass
from typing import TypeAlias


@dataclass(frozen=True, slots=True, kw_only=True)
class BoolOption:
    """真偽値の設定入力。"""

    value: bool


@dataclass(frozen=True, slots=True, kw_only=True)
class IntOption:
    """整数の設定入力。"""

    value: int


@dataclass(frozen=True, slots=True, kw_only=True)
class FloatOption:
    """小数の設定入力。値域は方式の準備処理が検証する。"""

    value: float


@dataclass(frozen=True, slots=True, kw_only=True)
class TextOption:
    """文字列の設定入力。"""

    value: str


@dataclass(frozen=True, slots=True, kw_only=True)
class NoneOption:
    """値なしを明示する設定入力。"""

    value: None = None


OptionValue: TypeAlias = BoolOption | IntOption | FloatOption | TextOption | NoneOption


@dataclass(frozen=True, slots=True, kw_only=True)
class CpuOption:
    """方式内で意味を解釈する名前付き設定。"""

    name: str
    value: OptionValue


@dataclass(frozen=True, slots=True, kw_only=True)
class FileResource:
    """準備時に開くファイルの参照。構築時には読み込まない。"""

    path: str


@dataclass(frozen=True, slots=True, kw_only=True)
class PackageResource:
    """準備時に解決するパッケージ資源の参照。"""

    package: str
    name: str


@dataclass(frozen=True, slots=True, kw_only=True)
class CpuResource:
    """方式が解釈する資源の役割と取得先。"""

    role: str
    source: FileResource | PackageResource


@dataclass(frozen=True, slots=True, kw_only=True)
class CpuRequest:
    """未検証の準備要求。項目の順序と重複を保持する。"""

    kind: str
    options: tuple[CpuOption, ...] = ()
    resources: tuple[CpuResource, ...] = ()
