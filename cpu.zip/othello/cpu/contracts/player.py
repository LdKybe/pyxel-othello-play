"""CPUの一対局の寿命と操作。実行環境・方式内部へ依存しない。"""

from dataclasses import dataclass
from typing import Protocol

from othello.core import Color, PlayingPosition, Position, Square
from othello.match.identity import GameId, PlayerId, Revision

from .result import AwaitObservation, ContinueWork, CpuDecision, CpuInfo


@dataclass(frozen=True, slots=True)
class Initial:
    """開始時の観測。"""


@dataclass(frozen=True, slots=True, kw_only=True)
class Accepted:
    """実対局で受理した直近の着手。パスは局面から分かる。"""

    square: Square


@dataclass(frozen=True, slots=True, kw_only=True)
class CpuObservation:
    """順序検証済みの実局面。探索中の仮想着手は含まない。"""

    game_id: GameId
    revision: Revision
    position: Position
    cause: Initial | Accepted


@dataclass(frozen=True, slots=True, kw_only=True)
class CpuContext:
    """一局で固定する担当・seed派生条件と初期観測。"""

    base_seed: int
    game_index: int
    game_id: GameId
    player_id: PlayerId
    color: Color
    initial_observation: CpuObservation


@dataclass(frozen=True, slots=True, kw_only=True)
class CpuThinkRequest:
    """指定revisionについて、追加思考を開始する要求。"""

    revision: Revision


class CpuPlayer(Protocol):
    """一局の探索記憶・乱数・計算予算を所有する振る舞い。"""

    def observe(self, observation: CpuObservation) -> None:
        """実行側が順序を検証した観測を受け取る。"""
        ...

    def request_move(self, request: CpuThinkRequest) -> None:
        """受信時点から自身のConfigに従う追加思考を開始する。"""
        ...

    def step(self) -> ContinueWork | AwaitObservation | CpuDecision:
        """短い単位だけ計算する。相手手番でも呼び出される。"""
        ...

    def close(self) -> None:
        """探索資源を解放する。繰り返し呼び出せる。"""
        ...


class PreparedCpu(Protocol):
    """検証済みConfigと準備資源を所有する。一局ごとに準備する。"""

    @property
    def info(self) -> CpuInfo:
        """準備時に確定した有効設定と再現条件。"""
        ...

    def start(self, context: CpuContext) -> CpuPlayer:
        """この局だけの探索状態を開始する。"""
        ...

    def close(self) -> None:
        """playerの終了後に準備資源を解放する。繰り返し呼び出せる。"""
        ...


class SyncStrategy(Protocol):
    """対局中の局面と明示seedから合法手を同期選択する。"""

    def choose_move(self, position: PlayingPosition, seed: int) -> Square:
        """渡された有効seedを再派生せず、着手先を返す。"""
        ...
