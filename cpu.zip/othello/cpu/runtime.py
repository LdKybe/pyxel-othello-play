"""両方式の継続探索・実行接続と通信値。"""

from dataclasses import dataclass
from typing import Literal, Protocol, TypeAlias

from othello.core import Color, GameState

from .models import SearchConfig, SearchDecision


@dataclass(frozen=True, slots=True)
class Start:
    """一対局の探索開始。"""

    game_id: int
    revision: int
    state: GameState
    color: Color
    seed: int
    config: SearchConfig


@dataclass(frozen=True, slots=True)
class Update:
    """受理済みの実着手後の局面通知。"""

    game_id: int
    revision: int
    state: GameState


@dataclass(frozen=True, slots=True)
class DecisionEvent:
    """実局面との照合に必要な識別子を伴う確定評価。"""

    game_id: int
    revision: int
    state: GameState
    decision: SearchDecision


@dataclass(frozen=True, slots=True)
class FailureEvent:
    """子で探索を継続できなくなった障害。"""

    game_id: int
    revision: int
    message: str


class SearchBackend(Protocol):
    """一対局一CPUの継続探索を動かす実行環境の契約。"""

    def start(  # noqa: PLR0913 - 承認済みの継続探索接続契約。
        self,
        game_id: int,
        revision: int,
        state: GameState,
        *,
        color: Color,
        seed: int,
        config: SearchConfig,
    ) -> None:
        """開始時だけ設定・色・シードを渡す。"""
        ...

    def update(self, game_id: int, revision: int, state: GameState) -> None:
        """実局面をFIFOで通知する。"""
        ...

    def poll(self) -> DecisionEvent | None:
        """現局面に一致する結果を一度だけ返す。"""
        ...

    def close(self) -> None:
        """活動中・待機中の資源を解放する。冪等。"""
        ...


MonteCarloBackend = SearchBackend
SearchPhase: TypeAlias = Literal["PONDERING", "THINKING", "READY", "CLOSED"]


class ContinuousSearch(Protocol):
    """実行基盤から独立した、一対局一CPUの探索契約。"""

    @property
    def phase(self) -> SearchPhase:
        """現在の探索状態。"""
        ...

    @property
    def completed_trials(self) -> int:
        """この対局の完了試行数。"""
        ...

    def update(self, state: GameState) -> None:
        """実局面を通知する。"""
        ...

    def run_slice(self, max_seconds: float = 0.01) -> SearchDecision | None:
        """限られた時間だけ探索し、期限到達後は確定結果を返す。"""
        ...

    def close(self) -> None:
        """探索の資源を解放する。冪等。"""
        ...
