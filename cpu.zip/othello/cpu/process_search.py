"""明示spawnの子に一対局の方式別探索を保持する。"""

from __future__ import annotations

import multiprocessing
from contextlib import suppress
from typing import TYPE_CHECKING, cast

from .factory import create_search
from .models import CpuKind, MctsConfig, SearchConfig, validate_seed
from .runtime import ContinuousSearch, DecisionEvent, FailureEvent, Start, Update

if TYPE_CHECKING:
    from multiprocessing.connection import Connection
    from multiprocessing.process import BaseProcess

    from othello.core import Color, GameState


def _is_new(current: Start | Update, command: Update) -> bool:
    if command.game_id != current.game_id:
        raise ValueError("game_id mismatch")
    if command.revision < current.revision:
        return False
    if command.revision == current.revision:
        if command.state != current.state:
            raise ValueError("same revision with different state")
        return False
    return True


class _Worker:
    """子だけが探索と最後に受理した通知を所有する。"""

    def __init__(self) -> None:
        self.search: ContinuousSearch | None = None
        self.current: Start | Update | None = None

    def accept(self, command: object) -> None:
        if isinstance(command, Start):
            if self.search is not None:
                raise RuntimeError("Search already started")
            self.current = command
            self.search = create_search(
                command.state,
                color=command.color,
                seed=command.seed,
                config=command.config,
            )
        elif (
            isinstance(command, Update)
            and self.search is not None
            and self.current is not None
        ):
            if _is_new(self.current, command):
                self.search.update(command.state)
                self.current = command
        else:
            raise ValueError("Invalid search command")

    def run(self, connection: Connection) -> None:
        while True:
            search = self.search
            if (
                search is None
                or search.phase in ("READY", "CLOSED")
                or connection.poll()
            ):
                self.accept(connection.recv())
                continue
            decision = search.run_slice(0.01)
            current = self.current
            if decision is not None and current is not None:
                connection.send(
                    DecisionEvent(
                        current.game_id, current.revision, current.state, decision
                    )
                )


def _serve(connection: Connection) -> None:
    worker = _Worker()
    try:
        worker.run(connection)
    except EOFError:
        pass
    except Exception as error:  # noqa: BLE001 - 子の例外を親へ伝える境界。
        if worker.current is not None:
            current = worker.current
            with suppress(OSError, EOFError):
                connection.send(
                    FailureEvent(current.game_id, current.revision, str(error))
                )
    finally:
        if worker.search is not None:
            worker.search.close()
        connection.close()


class ProcessSearch:
    """対局ごとに一つの子と専用Pipeを所有する。"""

    def __init__(self) -> None:
        self._process: BaseProcess | None = None
        self._connection: Connection | None = None
        self._current: Start | Update | None = None
        self._closed = False
        self._kind: CpuKind | None = None

    def start(  # noqa: PLR0913 - 両方式の公開接続契約。
        self,
        game_id: int,
        revision: int,
        state: GameState,
        *,
        color: Color,
        seed: int,
        config: SearchConfig,
    ) -> None:
        """子を一度起動し、開始通知を送る。"""
        if self._closed or self._current is not None:
            raise RuntimeError("Search is closed or already started")
        validate_seed(seed)
        self._validate_ids(game_id, revision)
        command = Start(game_id, revision, state, color, seed, config)
        self._kind = "mcts" if isinstance(config, MctsConfig) else "monte-carlo"
        context = multiprocessing.get_context("spawn")
        parent, child = context.Pipe()
        process = context.Process(target=_serve, args=(child,), daemon=True)
        self._process, self._connection = process, cast("Connection", parent)
        try:
            process.start()
            self._current = command
            self._send(command)
        except BaseException:
            self.close()
            raise
        finally:
            child.close()

    def _send(self, command: Start | Update) -> None:
        try:
            cast("Connection", self._connection).send(command)
        except (OSError, EOFError) as error:
            self.close()
            raise RuntimeError("Search command delivery failed") from error

    @staticmethod
    def _validate_ids(game_id: int, revision: int) -> None:
        if any(
            type(value) is not int or not 0 <= value < 2**53
            for value in (game_id, revision)
        ):
            raise ValueError("game_id and revision must be nonnegative exact integers")

    def update(self, game_id: int, revision: int, state: GameState) -> None:
        """古い通知を破棄し、同じ番号の異なる局面を拒否する。"""
        if self._closed or self._current is None:
            raise RuntimeError("Search is closed or not started")
        self._validate_ids(game_id, revision)
        command = Update(game_id, revision, state)
        if not _is_new(self._current, command):
            return
        self._send(command)
        self._current = command

    def poll(self) -> DecisionEvent | None:
        """現局面の結果を返し、子の障害では資源を回収して通知する。"""
        try:
            return self._poll()
        except RuntimeError:
            self.close()
            raise

    def _poll(self) -> DecisionEvent | None:
        if self._closed:
            raise RuntimeError("Search is closed")
        if self._current is None:
            return None
        connection = cast("Connection", self._connection)
        process = cast("BaseProcess", self._process)
        try:
            while connection.poll():
                event = connection.recv()
                if isinstance(event, FailureEvent):
                    raise RuntimeError(event.message)  # noqa: TRY004 - 子の探索障害をRuntimeErrorで通知。
                if not isinstance(event, DecisionEvent):
                    raise RuntimeError("Invalid search event")  # noqa: TRY004 - 通信契約の障害。
                current = self._current
                if (event.game_id, event.revision, event.state) == (
                    current.game_id,
                    current.revision,
                    current.state,
                ):
                    if event.decision.kind != self._kind:
                        raise RuntimeError("Search kind mismatch")
                    return event
        except (EOFError, OSError) as error:
            raise RuntimeError("Search connection ended") from error
        if not process.is_alive():
            raise RuntimeError("Search process exited unexpectedly")
        return None

    def close(self) -> None:
        """計算中・待機中とも子と通信路を回収する。"""
        self._closed = True
        process, connection = self._process, self._connection
        self._process = self._connection = self._current = None
        try:
            if process is not None:
                try:
                    if process.pid is not None:
                        if process.is_alive():
                            process.terminate()
                        process.join()
                finally:
                    # join中のCtrl+Cでも子を残さず、回収後に元の割込みを返す。
                    if process.pid is not None and process.is_alive():
                        process.terminate()
                        process.join()
                    process.close()
        finally:
            if connection is not None:
                connection.close()
