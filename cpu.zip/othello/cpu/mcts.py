"""モンテカルロ木探索の段階的な試行。"""

from collections import deque
from collections.abc import Callable
from dataclasses import dataclass, field
from math import log, sqrt
from random import Random
from time import monotonic
from typing import Literal, cast

from othello.core import Color, GameState, Rules, Square

from .models import CandidateEvaluation, MctsConfig, SearchDecision, validate_seed
from .strategy import NoLegalMoveError


@dataclass(slots=True)
class _Node:
    state: GameState
    moves: tuple[Square, ...]
    children: dict[Square, "_Node"] = field(default_factory=dict)
    visits: int = 0
    wins: int = 0
    draws: int = 0


@dataclass(slots=True)
class _Trial:
    state: GameState
    path: list[_Node]
    stage: Literal["select", "expand", "rollout"] = "select"
    pending: Square | None = None


class MctsSearch:
    """CPU色の統計を持つ木と、一つの再開可能な試行を所有する。"""

    def __init__(
        self,
        state: GameState,
        *,
        color: Color,
        seed: int,
        config: MctsConfig,
        clock: Callable[[], float] = monotonic,
    ) -> None:
        validate_seed(seed)
        self._rules = Rules()
        if not self._rules.legal_moves(state):
            raise NoLegalMoveError("No legal move available")
        self._color: Color = color
        self._config = config
        self._clock = clock
        self._rng = Random(seed)  # noqa: S311 - 対局単位の明示seed。
        self._root: _Node | None = self._node(state)
        self._trial: _Trial | None = None
        self._completed_trials = 0
        self._inherited: dict[Square, int] = {}
        self._decision: SearchDecision | None = None
        self._deadline = clock() + config.seconds if state.to_move == color else None

    def _node(self, state: GameState) -> _Node:
        return _Node(state, self._rules.legal_moves(state))

    def _select(self, node: _Node) -> Square:
        for square in node.moves:
            child = node.children.get(square)
            if child is None or child.visits == 0:
                return square

        def score(square: Square) -> float:
            child = node.children[square]
            q = (child.wins + 0.5 * child.draws) / child.visits
            exploitation = q if node.state.to_move == self._color else 1 - q
            return exploitation + sqrt(2) * sqrt(log(node.visits) / child.visits)

        # movesは昇順なので、maxの同率は最小Squareになる。
        return max(node.moves, key=score)

    def _advance(self) -> bool:
        """一選択または一着手を進め、終局に達したかを返す。"""
        if self._trial is None:
            root = self._require_root()
            self._trial = _Trial(root.state, [root])
        trial = self._trial
        if trial.state.to_move is None:
            return True
        if trial.stage == "select":
            node = trial.path[-1]
            square = self._select(node)
            child = node.children.get(square)
            if child is None:
                trial.pending = square
                trial.stage = "expand"
            else:
                trial.path.append(child)
                trial.state = child.state
                if child.visits == 0:
                    trial.stage = "rollout"
        elif trial.stage == "expand":
            # 選択と着手を分け、どちらの前後でも呼出し元が時計を確認できる。
            pending = cast("Square", trial.pending)
            state = self._rules.apply_move(trial.state, pending).state
            child = self._node(state)
            trial.path[-1].children[pending] = child
            trial.path.append(child)
            trial.state = state
            trial.pending = None
            trial.stage = "rollout"
        else:
            square = self._rng.choice(self._rules.legal_moves(trial.state))
            trial.state = self._rules.apply_move(trial.state, square).state
        return trial.state.to_move is None

    @property
    def completed_trials(self) -> int:
        """この対局で集計した終局試行数を返す。"""
        return self._completed_trials

    def _backup(self) -> None:
        trial = self._trial
        if trial is None or trial.state.to_move is not None:
            return
        outcome = self._rules.outcome(trial.state)
        if outcome is None:
            return
        for node in trial.path:
            node.visits += 1
            node.wins += outcome.winner == self._color
            node.draws += outcome.winner is None
        self._completed_trials += 1
        self._trial = None

    def _decision_snapshot(self) -> SearchDecision:
        candidates = []
        root = self._require_root()
        for square in root.moves:
            child = root.children.get(square)
            visits = child.visits if child is not None else 0
            wins = child.wins if child is not None else 0
            draws = child.draws if child is not None else 0
            inherited = self._inherited.get(square, 0)
            candidates.append(
                CandidateEvaluation(
                    square,
                    visits,
                    wins,
                    draws,
                    inherited,
                    visits - inherited,
                    (wins + 0.5 * draws) / visits if visits else None,
                )
            )
        best = candidates[0]
        for row in candidates[1:]:
            if row.visits > best.visits or (
                row.visits == best.visits
                and (2 * row.wins + row.draws) * best.visits
                > (2 * best.wins + best.draws) * row.visits
            ):
                best = row
        return SearchDecision(best.square, self._color, tuple(candidates), "mcts")

    @property
    def phase(self) -> Literal["PONDERING", "THINKING", "READY", "CLOSED"]:
        """実行側へ探索の状態を返す。"""
        if self._root is None:
            return "CLOSED"
        if self._decision is not None:
            return "READY"
        return "THINKING" if self._deadline is not None else "PONDERING"

    def _expired(self) -> bool:
        return self._deadline is not None and self._clock() >= self._deadline

    def _adopt_root(self, root: _Node) -> None:
        if root.state == self._require_root().state:
            return
        self._trial = None
        self._decision = None
        self._root = root
        self._inherited = {
            square: child.visits for square, child in root.children.items()
        }
        # rootの移行と統計抽出が済んでから、追加思考の時間を計る。
        self._deadline = (
            self._clock() + self._config.seconds
            if root.state.to_move == self._color
            else None
        )

    def run_slice(self, max_seconds: float = 0.01) -> SearchDecision | None:
        """選択または着手ごとに時計を確認して探索を再開する。

        Args:
            max_seconds: 呼出し元へ制御を返すまでの有限の正秒数。

        Returns:
            自手番の期限に達した場合だけ、不変の着手結果。

        Raises:
            ValueError: スライス時間が有限の正数ではない。
            RuntimeError: 探索が終了済み。
        """
        self._require_root()
        if type(max_seconds) not in (int, float) or not 0 < max_seconds < float("inf"):
            raise ValueError("max_seconds must be a finite positive number")
        if self._decision is not None:
            return self._decision
        end = self._clock() + max_seconds
        while not self._expired() and self._clock() < end:
            terminal = self._advance()
            if self._expired():
                break
            if terminal:
                self._backup()
        if self._expired():
            self._trial = None
            self._decision = self._decision_snapshot()
        return self._decision

    def _require_root(self) -> _Node:
        if self._root is None:
            raise RuntimeError("Search is closed")
        return self._root

    def _find_root(self, state: GameState) -> _Node | None:
        root = self._require_root()
        queue = deque(root.children[square] for square in sorted(root.children))
        while queue:
            node = queue.popleft()
            if node.state == state:
                return node
            queue.extend(node.children[square] for square in sorted(node.children))
        return None

    def update(self, state: GameState) -> None:
        """一致する部分木と乱数を保持し、実局面へ起点を移す。

        Args:
            state: コアルールで正規化した実局面。

        Raises:
            RuntimeError: 探索が終了済み。
            NoLegalMoveError: 非終局なのに合法手がない。
        """
        if state == self._require_root().state:
            return
        if state.to_move is None:
            self.close()
            return
        if not self._rules.legal_moves(state):
            raise NoLegalMoveError("No legal move available")
        retained = self._find_root(state)
        # 検索のキューは戻り時に解放済み。旧木を外してから期限を開始する。
        self._adopt_root(retained if retained is not None else self._node(state))

    def close(self) -> None:
        """木・未完了試行・結果を解放する。繰返し終了してもよい。"""
        self._trial = None
        self._root = None
        self._decision = None
        self._inherited.clear()
        self._deadline = None
        self._completed_trials = 0


class MctsStrategy:
    """一時的な継続探索で着手を選ぶ同期CPU。"""

    def __init__(self, *, seconds: float = 3.0) -> None:
        self._config = MctsConfig(seconds)

    def choose_move(self, state: GameState, *, seed: int) -> Square:
        """期限まで探索し、すべての終了経路で探索を閉じる。

        Args:
            state: 正規化された実局面。
            seed: 0以上2**256未満の整数。

        Returns:
            最多完了訪問による合法手。

        Raises:
            ValueError: seedが不正。
            NoLegalMoveError: 合法手がない。
        """
        search = MctsSearch(
            state, color=cast("Color", state.to_move), seed=seed, config=self._config
        )
        try:
            while True:
                decision = search.run_slice()
                if decision is not None:
                    return decision.square
        finally:
            search.close()
