"""方式設定に対応する継続探索を作る。"""

from collections.abc import Callable
from time import monotonic

from othello.core import Color, GameState

from .mcts import MctsSearch
from .models import MctsConfig, SearchConfig
from .monte_carlo import MonteCarloSearch
from .runtime import ContinuousSearch


def create_search(
    state: GameState,
    *,
    color: Color,
    seed: int,
    config: SearchConfig,
    clock: Callable[[], float] = monotonic,
) -> ContinuousSearch:
    """設定型から探索方式を選び、単一の探索を作る。

    Args:
        state: 正規化した実局面。
        color: CPU担当色。
        seed: 対局・プレイヤー単位の明示seed。
        config: 方式に対応する設定。
        clock: 単調時計。

    Returns:
        方式に対応する継続探索。

    Raises:
        ValueError: seedが範囲外。
        NoLegalMoveError: 合法手がない。
    """
    if isinstance(config, MctsConfig):
        return MctsSearch(state, color=color, seed=seed, config=config, clock=clock)
    return MonteCarloSearch(state, color=color, seed=seed, config=config, clock=clock)
