"""単純モンテカルロ専用の、担当色を固定した完了試行の集計。"""

from collections import OrderedDict
from dataclasses import dataclass
from typing import cast

from othello.core import Color, GameState, Outcome, Rules

from .models import CandidateEvaluation, PositionMoveKey


@dataclass(slots=True)
class _Counts:
    visits: int = 0
    wins: int = 0
    draws: int = 0
    updated_at: int = 0


class StatisticsStore:
    """局面と候補手を完全一致で識別し、外へは不変な結果だけ返す。"""

    def __init__(self, *, color: Color, limit: int = 20_000) -> None:
        if type(limit) is not int or limit <= 0:
            raise ValueError("limit must be a positive integer")
        self._color = color
        self._limit = limit
        self._sequence = 0
        self._entries: OrderedDict[PositionMoveKey, _Counts] = OrderedDict()
        self._protected: dict[PositionMoveKey, _Counts] = {}
        self._baseline: dict[PositionMoveKey, int] = {}

    def __len__(self) -> int:
        return len(self._entries) + len(self._protected)

    def clear(self) -> None:
        """Discard all statistics and inherited counts at game termination."""
        self._entries.clear()
        self._protected.clear()
        self._baseline.clear()
        self._sequence = 0

    @staticmethod
    def _keys(state: GameState) -> tuple[PositionMoveKey, ...]:
        return tuple(
            PositionMoveKey(
                state.board.black,
                state.board.white,
                cast("Color", state.to_move),
                square,
            )
            for square in Rules().legal_moves(state)
        )

    def _trim(self) -> None:
        while len(self) > self._limit:
            self._entries.popitem(last=False)

    def promote(self, state: GameState) -> tuple[CandidateEvaluation, ...]:
        """Protect a new root before demoting previous root candidates.

        Args:
            state: Actual normalized position, never a predicted move.

        Returns:
            Candidates with their inherited counts fixed for this turn.

        Raises:
            ValueError: The configured limit cannot hold all current candidates.
        """
        keys = self._keys(state)
        if len(keys) > self._limit:
            raise ValueError("limit cannot hold current legal candidates")
        promoted = {}
        for key in keys:
            counts = self._protected.pop(key, None)
            if counts is None:
                counts = self._entries.pop(key, _Counts())
            promoted[key] = counts
        # 先に新候補を取り出し、旧候補の退避による上限整理から守る。
        self._entries.update(self._protected)
        # 保護中の更新も含む順序へ戻す。退避そのものを更新とは扱わない。
        self._entries = OrderedDict(
            sorted(self._entries.items(), key=lambda pair: pair[1].updated_at)
        )
        self._protected = promoted
        self._baseline = {key: counts.visits for key, counts in promoted.items()}
        self._trim()
        return self.snapshot(state)

    def record(self, trace: tuple[PositionMoveKey, ...], outcome: Outcome) -> None:
        """Record one completed trial once for each retained position/move.

        Args:
            trace: Retained pre-move positions. No incomplete trial is accepted.
            outcome: Terminal outcome, evaluated from this CPU's assigned color.
        """
        for key in dict.fromkeys(trace):
            counts = self._protected.get(key)
            if counts is None:
                counts = self._entries.setdefault(key, _Counts())
                self._entries.move_to_end(key)
            self._sequence += 1
            counts.updated_at = self._sequence
            counts.visits += 1
            counts.wins += int(outcome.winner == self._color)
            counts.draws += int(outcome.winner is None)
            self._trim()

    def snapshot(self, state: GameState) -> tuple[CandidateEvaluation, ...]:
        """Return immutable evaluations for all legal candidates.

        Args:
            state: Normalized position to inspect.

        Returns:
            Position-ordered candidates; unknown candidates have no win rate.
        """
        result = []
        for key in self._keys(state):
            counts = self._protected.get(key)
            if counts is None:
                counts = self._entries.get(key, _Counts())
            inherited = self._baseline.get(key, 0)
            result.append(
                CandidateEvaluation(
                    key.square,
                    counts.visits,
                    counts.wins,
                    counts.draws,
                    inherited,
                    counts.visits - inherited,
                    (counts.wins + counts.draws / 2) / counts.visits
                    if counts.visits
                    else None,
                )
            )
        return tuple(result)
