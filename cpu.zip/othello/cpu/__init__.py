"""表示に依存しない同期・分割CPUの公開契約。"""

from .monte_carlo import MonteCarloStrategy
from .strategy import CpuStrategy, NoLegalMoveError

__all__ = ["CpuStrategy", "MonteCarloStrategy", "NoLegalMoveError"]
