"""CPU方式の公開入口はcatalogとcontracts。方式実装は各players内に閉じる。"""
