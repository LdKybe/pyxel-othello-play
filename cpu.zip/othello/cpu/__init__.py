"""表示に依存しないCPUと両方式の継続探索の公開契約。"""

from typing import TYPE_CHECKING

from .factory import create_search
from .mcts import MctsSearch, MctsStrategy
from .models import (
    CandidateEvaluation,
    CpuKind,
    MctsConfig,
    MonteCarloConfig,
    SearchConfig,
    SearchDecision,
)
from .monte_carlo import MonteCarloSearch, MonteCarloStrategy
from .runtime import (
    ContinuousSearch,
    DecisionEvent,
    MonteCarloBackend,
    SearchBackend,
    SearchPhase,
)
from .strategy import CpuStrategy, NoLegalMoveError

if TYPE_CHECKING:
    from .process_search import ProcessSearch


__all__ = [
    "CandidateEvaluation",
    "ContinuousSearch",
    "CpuKind",
    "CpuStrategy",
    "DecisionEvent",
    "MctsConfig",
    "MctsSearch",
    "MctsStrategy",
    "MonteCarloBackend",
    "MonteCarloConfig",
    "MonteCarloSearch",
    "MonteCarloStrategy",
    "NoLegalMoveError",
    "ProcessSearch",
    "SearchBackend",
    "SearchConfig",
    "SearchDecision",
    "SearchPhase",
    "create_search",
]


def __getattr__(name: str) -> object:
    if name == "ProcessSearch":
        # ブラウザではmultiprocessingを読み込まない。
        from .process_search import ProcessSearch  # noqa: PLC0415

        return ProcessSearch
    raise AttributeError(name)
