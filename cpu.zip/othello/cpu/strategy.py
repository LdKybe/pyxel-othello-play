"""差し替え可能な同期CPUの型契約。"""

from typing import Protocol

from othello.core import GameState, Square


class NoLegalMoveError(ValueError):
    """探索できる合法手がない。"""


class CpuStrategy(Protocol):
    """共通局面とシードから合法手を同期的に選ぶ契約。"""

    def choose_move(self, state: GameState, *, seed: int) -> Square:
        """局面と明示シードを受け取り、合法手を選ぶ。

        時間制御などの再現条件は各思考方式の契約に従う。

        Args:
            state: 合法手のある共通局面。
            seed: 0以上2**256未満の探索用整数シード。

        Returns:
            選択した合法手の座標。

        Raises:
            NoLegalMoveError: 探索できる合法手がない。
            ValueError: シードの型または範囲が不正。
        """
        ...
