"""単純モンテカルロの継続探索と同期着手選択。"""

from collections.abc import Callable
from dataclasses import dataclass, field
from random import Random
from time import monotonic
from typing import Literal, cast

from othello.core import Color, GameState, Outcome, Rules, Square

from .models import MonteCarloConfig, PositionMoveKey, SearchDecision, validate_seed
from .statistics import StatisticsStore
from .strategy import NoLegalMoveError


class MonteCarloStrategy:
    """一時的な継続探索を期限まで進めるヘッドレス入口。"""

    def __init__(self, *, seconds: float = 3.0, retention_depth: int = 6) -> None:
        self._config = MonteCarloConfig(seconds, retention_depth)

    def choose_move(self, state: GameState, *, seed: int) -> Square:
        """期限まで探索して合法手を返し、必ず探索を終了する。

        Args:
            state: 正規化された実局面。
            seed: 0以上2**256未満の整数。

        Returns:
            平均得点が最大の合法手。

        Raises:
            ValueError: シードが不正。
            NoLegalMoveError: 合法手がない。
        """
        search = MonteCarloSearch(
            state, color=cast("Color", state.to_move), seed=seed, config=self._config
        )
        try:
            while True:
                decision = search.run_slice()
                if decision is not None:
                    return decision.square
        finally:
            search.close()


@dataclass(slots=True)
class _Trial:
    state: GameState
    first: Square | None = None
    trace: list[PositionMoveKey] = field(default_factory=list)


class MonteCarloSearch:
    """一対局一CPUの乱数・局面・途中試行・完了統計を所有する。"""

    def __init__(
        self,
        state: GameState,
        *,
        color: Color,
        seed: int,
        config: MonteCarloConfig,
        clock: Callable[[], float] = monotonic,
    ) -> None:
        validate_seed(seed)
        self._rules = Rules()
        if not self._rules.legal_moves(state):
            raise NoLegalMoveError("No legal move available")
        self._root = state
        self._color: Color = color
        self._config = config
        self._clock = clock
        self._rng = Random(seed)  # noqa: S311 - 対局内の明示シードによる試行。
        self._statistics = StatisticsStore(color=color)
        self._statistics.promote(state)
        self._trials: dict[Square | None, _Trial] = {}
        self._candidates = self._rules.legal_moves(state)
        self._cursor = 0
        self._deadline = (clock() + config.seconds) if state.to_move == color else None
        self._ready = False
        self._decision: SearchDecision | None = None
        self._closed = False
        self._completed_trials = 0

    @property
    def phase(self) -> Literal["PONDERING", "THINKING", "READY", "CLOSED"]:
        """Return the lifecycle state for an execution backend."""
        if self._closed:
            return "CLOSED"
        if self._ready:
            return "READY"
        return "THINKING" if self._deadline is not None else "PONDERING"

    @property
    def completed_trials(self) -> int:
        """Return the number of terminal trials accepted in this game."""
        return self._completed_trials

    def _advance(self, trial: _Trial) -> bool:
        state = trial.state
        moves = self._rules.legal_moves(state)
        square = trial.first if trial.first is not None else self._rng.choice(moves)
        trial.first = None
        if len(trial.trace) < self._config.retention_depth:
            trial.trace.append(
                PositionMoveKey(
                    state.board.black,
                    state.board.white,
                    cast("Color", state.to_move),
                    square,
                )
            )
        trial.state = self._rules.apply_move(state, square).state
        if self._expired():
            return False
        if trial.state.to_move is None:
            outcome = cast("Outcome", self._rules.outcome(trial.state))
            self._statistics.record(tuple(trial.trace), outcome)
            self._completed_trials += 1
            return True
        return False

    def run_slice(self, max_seconds: float = 0.01) -> SearchDecision | None:
        """Advance trials until the slice ends or the own-turn deadline arrives.

        Args:
            max_seconds: Positive duration before returning to the caller.

        Returns:
            The retained decision once ready; otherwise None.

        Raises:
            RuntimeError: The search has been closed.
            ValueError: The slice duration is invalid.
        """
        if self._closed:
            raise RuntimeError("Search is closed")
        if type(max_seconds) not in (int, float) or not 0 < max_seconds < float("inf"):
            raise ValueError("max_seconds must be a finite positive number")
        end = self._clock() + max_seconds
        while not self._ready and not self._expired() and self._clock() < end:
            key = self._candidates[self._cursor] if self._deadline is not None else None
            trial = self._trials.get(key)
            if trial is None:
                trial = _Trial(self._root, first=key)
                self._trials[key] = trial
            if self._advance(trial):
                del self._trials[key]
            self._cursor = (self._cursor + 1) % len(self._candidates)
        if self._expired():
            self._ready = True
            self._trials.clear()
        if self._ready and self._decision is None:
            self._decision = self._select()
        return self._decision

    def _select(self) -> SearchDecision:
        candidates = self._statistics.snapshot(self._root)
        rated = [row for row in candidates if row.visits]
        square = candidates[0].square
        if rated:
            best = rated[0]
            for row in rated[1:]:
                # 異なる分母を丸めず比較し、同率なら先の小さい位置を残す。
                if (2 * row.wins + row.draws) * best.visits > (
                    2 * best.wins + best.draws
                ) * row.visits:
                    best = row
            square = best.square
        return SearchDecision(square, self._color, candidates)

    def _expired(self) -> bool:
        return self._deadline is not None and self._clock() >= self._deadline

    def update(self, state: GameState) -> None:
        """実局面へ移り、完了統計と乱数を維持する。

        同じ局面の通知では追加時間も途中試行も変更しない。

        Args:
            state: 自動パスが正規化された実局面。

        Raises:
            RuntimeError: 探索が終了済み。
            NoLegalMoveError: 非終局なのに合法手がない。
        """
        if self._closed:
            raise RuntimeError("Search is closed")
        if state == self._root:
            return
        if state.to_move is None:
            self.close()
            return
        candidates = self._rules.legal_moves(state)
        if not candidates:
            raise NoLegalMoveError("No legal move available")
        self._statistics.promote(state)
        self._root = state
        self._candidates = candidates
        self._trials.clear()
        self._cursor = 0
        self._ready = False
        self._decision = None
        self._deadline = (
            self._clock() + self._config.seconds
            if state.to_move == self._color
            else None
        )

    def close(self) -> None:
        """Discard all pending and completed work; closing twice is harmless."""
        self._closed = True
        self._trials.clear()
        self._statistics.clear()
        self._decision = None
        self._completed_trials = 0
