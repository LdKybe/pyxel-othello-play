"""表示・実対局の履歴を持たない同期・分割モンテカルロ探索。

候補順を固定して乱数の消費順を安定させる。得点は勝ち2・引分1・負け0で、
同じ試行数の累計を比べるため浮動小数の勝率計算は不要。
乱数は探索単位に隔離するが、再現には同じPython実装・版も必要となる。
"""

from collections.abc import Generator
from random import Random
from typing import cast

from othello.core import GameState, Outcome, Rules, Square

from .strategy import NoLegalMoveError


class MonteCarloStrategy:
    """全候補を同じ試行回数で評価するモンテカルロCPU。"""

    def __init__(self, rollouts_per_move: int) -> None:
        if type(rollouts_per_move) is not int or rollouts_per_move <= 0:
            raise ValueError("rollouts_per_move must be a positive integer")
        self._rollouts_per_move = rollouts_per_move

    def choose_move(self, state: GameState, *, seed: int) -> Square:
        """分割探索を終了まで進め、従来と同じ合法手を返す。

        Args:
            state: 正規化された探索局面。
            seed: 0以上2**256未満の整数シード。

        Returns:
            全候補の試行後に選択した手。

        Raises:
            ValueError: シードが不正。
            NoLegalMoveError: 合法手がない。
        """
        search = self.iter_move(state, seed=seed)
        try:
            while True:
                try:
                    next(search)
                except StopIteration as result:
                    return cast("Square", result.value)
        finally:
            search.close()

    def iter_move(
        self, state: GameState, *, seed: int
    ) -> Generator[None, None, Square]:
        """1着手以下で制御を返す、独立した探索を作る。

        Args:
            state: 正規化された探索局面。変更しない。
            seed: 0以上2**256未満の整数シード。

        Returns:
            継続時はNone、完了時はStopIteration.valueに選択手を持つ探索。
            nextを呼ばない間は休止し、closeで計算せず破棄する。

        Raises:
            ValueError: シードが不正。呼出し時に検証する。
            NoLegalMoveError: 合法手がない。呼出し時に検証する。
        """
        if type(seed) is not int or not 0 <= seed < 2**256:
            raise ValueError("seed must be an integer in [0, 2**256)")
        rules = Rules()
        candidates = rules.legal_moves(state)
        if not candidates:
            raise NoLegalMoveError("No legal move available")
        rng = Random(seed)  # noqa: S311 - 対局の再現用乱数であり暗号用途ではない。
        return self._explore(state, rules, candidates, rng)

    def _explore(
        self,
        state: GameState,
        rules: Rules,
        candidates: tuple[Square, ...],
        rng: Random,
    ) -> Generator[None, None, Square]:
        best_move, best_score = candidates[0], -1
        for candidate in candidates:
            score = 0
            for _ in range(self._rollouts_per_move):
                trial = rules.apply_move(state, candidate).state
                yield None
                while trial.to_move is not None:
                    moves = rules.legal_moves(trial)
                    trial = rules.apply_move(
                        trial, moves[rng.randrange(len(moves))]
                    ).state
                    yield None
                # ループ終了時は終局なのでOutcomeが必ず存在する。
                outcome = cast("Outcome", rules.outcome(trial))
                if outcome.winner == state.to_move:
                    score += 2
                elif outcome.winner is None:
                    score += 1
            # 昇順で最初に得た同率候補を残し、最小Squareを選ぶ。
            if score > best_score:
                best_move, best_score = candidate, score
        return best_move
