"""選択肢を軽量に公開し、準備時だけ方式providerを読み込む。"""

from dataclasses import dataclass

from .contracts import CpuRequest, PreparedCpu


@dataclass(frozen=True, slots=True, kw_only=True)
class CpuChoice:
    """選択画面で使う方式名と表示名。探索の内部情報を含まない。"""

    kind: str
    display_name: str


_CHOICES = (
    CpuChoice(kind="monte-carlo", display_name="単純モンテカルロ"),
    CpuChoice(kind="mcts", display_name="MCTS"),
    CpuChoice(kind="td", display_name="TD"),
)


def list_choices() -> tuple[CpuChoice, ...]:
    """方式本体や資源を読み込まず、選択情報を返す。"""
    return _CHOICES


def prepare(request: CpuRequest) -> PreparedCpu:
    """方式識別名に対応する準備処理を呼び出す。

    探索実装のimportは方式を選んだ後に行う。

    Args:
        request: CPU方式、設定項目、資源参照をまとめた準備要求。

    Returns:
        有効設定を持ち、対局用CPUを生成できる準備結果。

    Raises:
        ValueError: 方式名が未対応、または方式側の設定検証に失敗した。
    """
    if request.kind == "monte-carlo":
        from .players.monte_carlo.provider import prepare as prepare_mc  # noqa: PLC0415

        return prepare_mc(request)
    if request.kind == "mcts":
        from .players.mcts.provider import prepare as prepare_mcts  # noqa: PLC0415

        return prepare_mcts(request)
    if request.kind == "td":
        from .players.td.provider import prepare as prepare_td  # noqa: PLC0415

        return prepare_td(request)
    raise ValueError(f"未対応のCPU方式です: {request.kind}")
