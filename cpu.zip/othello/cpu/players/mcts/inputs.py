"""MCTSの軽量な入力入口。探索や資源を読み込まない。"""

from othello.cpu.contracts import CpuOption, CpuRequest, FloatOption, IntOption

from .config import MctsConfig


def build_request(*, seconds: float = 3.0) -> CpuRequest:
    """名前付き設定を検証し、共通の準備入力へ変換する。"""
    config = MctsConfig(seconds=seconds)
    return CpuRequest(
        kind="mcts",
        options=(
            CpuOption(name="seconds", value=FloatOption(value=float(config.seconds))),
        ),
    )


def parse_request(request: CpuRequest) -> MctsConfig:
    """未知項目・重複・型・値域を検証し、計算用Configへ移す。"""
    if request.kind != "mcts" or request.resources:
        raise ValueError("このCPU方式に指定できない方式名または資源です")
    seen: set[str] = set()
    seconds = 3.0
    for option in request.options:
        if option.name in seen:
            raise ValueError(f"CPU設定が重複しています: {option.name}")
        seen.add(option.name)
        match option:
            case CpuOption(name="seconds", value=FloatOption(value=value)):
                seconds = value
            case CpuOption(name="seconds", value=IntOption(value=value)):
                if type(value) is not int:
                    raise ValueError("思考秒数は数値が必要です")
                try:
                    seconds = float(value)
                except OverflowError as error:
                    raise ValueError("思考秒数が大きすぎます") from error
            case _:
                raise ValueError(f"CPU設定の項目または値型が不正です: {option.name}")
    return MctsConfig(seconds=seconds)
