"""MCTSの検証済み追加思考時間とUCT定数。"""

from dataclasses import dataclass
from math import sqrt

UCT_C = sqrt(2)


@dataclass(frozen=True, slots=True)
class MctsConfig:
    """有限で正の追加秒数。木の保持数を制限する設定はない。"""

    seconds: float = 3.0

    def __post_init__(self) -> None:
        if type(self.seconds) not in (int, float) or not 0 < self.seconds < float(
            "inf"
        ):
            raise ValueError("思考秒数は有限の正数が必要です")
