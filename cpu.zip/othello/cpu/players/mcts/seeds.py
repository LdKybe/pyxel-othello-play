"""MCTSの乱数seedの検証と対局単位の派生。"""

from hashlib import sha256


def validate_seed(seed: int) -> None:
    """CPUに渡す乱数シードの型と範囲を検査する。

    Args:
        seed: 1局・1CPUに割り当てる、0以上の整数。

    Raises:
        ValueError: 整数でない、boolである、または範囲外。
    """
    if type(seed) is not int or seed < 0:
        raise ValueError("seedは0以上の整数が必要です")


def derive_mcts_seed(base_seed: int, game_index: int, player_id: str) -> int:
    """対局とプレイヤーから、MCTS用のシードを決定的に派生する。

    同じ入力なら同じ値になる。着手やパスのたびに派生し直さず、
    1局を通じて使う。時間制御の探索では棋譜の一致までは保証しない。

    Args:
        base_seed: 連戦の基準シード。0以上。
        game_index: 0始まりの対局番号。
        player_id: 担当色に依存しない空でない識別子。

    Returns:
        方式ごとの名前空間を含めてSHA-256から求めた、256ビット以内の整数。

    Raises:
        ValueError: 整数引数の型・範囲またはプレイヤーIDが不正。
    """
    for name, value in (("base_seed", base_seed), ("game_index", game_index)):
        if type(value) is not int or value < 0:
            raise ValueError(f"{name}は0以上の整数が必要です")
    if not player_id:
        raise ValueError("プレイヤーIDは空にできません")
    payload = f"othello-mcts-v1:{base_seed}:{game_index}:{player_id}"
    return int.from_bytes(sha256(payload.encode("utf-8")).digest(), "big")
