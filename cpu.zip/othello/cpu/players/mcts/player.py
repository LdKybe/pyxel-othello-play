"""モンテカルロ木探索の段階的な試行。"""

from collections import deque
from collections.abc import Callable
from dataclasses import dataclass, field
from math import log, sqrt
from random import Random
from time import monotonic
from typing import Literal, assert_never

from othello.core import (
    Color,
    FinishedPosition,
    PlayingPosition,
    Position,
    Rules,
    Square,
)
from othello.cpu.contracts import (
    AwaitObservation,
    ContinueWork,
    CpuDecision,
    CpuObservation,
    CpuThinkRequest,
)
from othello.match.identity import Revision

from .config import UCT_C, MctsConfig
from .models import CandidateEvaluation
from .seeds import validate_seed


@dataclass(slots=True)
class _Node:
    """探索木の1局面と、そこからの着手・完了試行数を保持する。

    childrenは着手先から子局面への対応で、未展開の手は含まない。
    visits・wins・drawsは終局まで完了した試行だけを数え、勝数の基準は
    ノードの手番ではなくCPUの担当色に固定する。
    """

    state: Position
    moves: tuple[Square, ...]
    children: dict[Square, "_Node"] = field(default_factory=dict)
    visits: int = 0
    wins: int = 0
    draws: int = 0


@dataclass(frozen=True, slots=True)
class _Selecting:
    """既存の木で次の手を選択する段階。"""


@dataclass(frozen=True, slots=True)
class _Expanding:
    """選択した着手先を必須にして、次の計算単位で展開する。"""

    square: Square


@dataclass(frozen=True, slots=True)
class _RollingOut:
    """木を増やさずランダム対局を進める段階。"""


@dataclass(slots=True)
class _Trial:
    """途中局面・集計経路・再開する段階を保持する。"""

    state: Position
    path: list[_Node]
    stage: _Selecting | _Expanding | _RollingOut = field(default_factory=_Selecting)


class MctsSearch:
    """1局・1CPUの乱数と探索状態を保持し、小刻みに計算を進める。

    探索木と途中の1試行を保持する。最終手は訪問数、勝率、
    マス番号の小ささの順で選ぶ。
    木と統計は方式内専用であり、利用側はMctsPlayerを使う。
    request_move()で自手番の追加思考の期限を設定する。
    相手番には期限を設けず、run_slice()が呼ばれた分だけ先読みする。

    Args:
        state: Rulesでパス・終局を判定済みの実局面。合法手が必要。
        color: 1局を通じて勝敗集計の基準となるCPU担当色。
        seed: 0以上の乱数シード。局面更新後も乱数列を引き継ぐ。
        config: 自手番の追加思考時間など、方式の検証済み設定。
        clock: 秒単位の単調増加する時刻を返す関数。通常はmonotonic。

    Raises:
        ValueError: シードの型または範囲が不正。
    """

    def __init__(
        self,
        state: PlayingPosition,
        *,
        color: Color,
        seed: int,
        config: MctsConfig,
        clock: Callable[[], float] = monotonic,
    ) -> None:
        validate_seed(seed)
        self._rules = Rules()
        self._color: Color = color
        self._config = config
        self._clock = clock
        self._rng = Random(seed)  # noqa: S311 - 対局単位の明示seed。
        self._root: _Node | None = self._node(state)
        self._trial: _Trial | None = None
        self._completed_trials = 0
        self._inherited: dict[Square, int] = {}
        self._decision: Square | None = None
        self._deadline: float | None = None

    def _node(self, state: Position) -> _Node:
        match state:
            case PlayingPosition():
                return _Node(state, state.legal_moves)
            case FinishedPosition():
                return _Node(state, ())
            case _:
                assert_never(state)

    def _select(self, node: _Node) -> Square:
        match node.state:
            case PlayingPosition(to_move=to_move):
                pass
            case FinishedPosition():
                raise ValueError("終局ノードには選択する手がありません")
            case _:
                assert_never(node.state)
        for square in node.moves:
            child = node.children.get(square)
            if child is None or child.visits == 0:
                return square

        def score(square: Square) -> float:
            child = node.children[square]
            q = (child.wins + 0.5 * child.draws) / child.visits
            exploitation = q if to_move == self._color else 1 - q
            return exploitation + UCT_C * sqrt(log(node.visits) / child.visits)

        # movesは昇順なので、maxの同率は最小Squareになる。
        return max(node.moves, key=score)

    def _advance(self) -> bool:
        """一選択または一着手を進め、終局に達したかを返す。"""
        if self._trial is None:
            root = self._require_root()
            self._trial = _Trial(root.state, [root])
        trial = self._trial
        match trial.state:
            case FinishedPosition():
                return True
            case PlayingPosition() as position:
                pass
            case _:
                assert_never(trial.state)
        self._advance_playing(trial, position)
        match trial.state:
            case FinishedPosition():
                return True
            case PlayingPosition():
                return False
            case _:
                assert_never(trial.state)

    def _advance_playing(self, trial: _Trial, position: PlayingPosition) -> None:
        """現在の段階に対応する選択または一着手だけを進める。"""
        match trial.stage:
            case _Selecting():
                node = trial.path[-1]
                square = self._select(node)
                child = node.children.get(square)
                if child is None:
                    trial.stage = _Expanding(square)
                else:
                    trial.path.append(child)
                    trial.state = child.state
                    if child.visits == 0:
                        trial.stage = _RollingOut()
            case _Expanding(square=square):
                state = self._rules.play(position, square).position
                child = self._node(state)
                trial.path[-1].children[square] = child
                trial.path.append(child)
                trial.state = state
                trial.stage = _RollingOut()
            case _RollingOut():
                square = self._rng.choice(position.legal_moves)
                trial.state = self._rules.play(position, square).position
            case _:
                assert_never(trial.stage)

    @property
    def completed_trials(self) -> int:
        """生成後に集計した完了試行数を返す。局面更新では維持し、close()で0に戻す。"""
        return self._completed_trials

    def _backup(self) -> None:
        trial = self._trial
        if trial is None:
            return
        match trial.state:
            case FinishedPosition(outcome=outcome):
                pass
            case PlayingPosition():
                return
            case _:
                assert_never(trial.state)
        for node in trial.path:
            node.visits += 1
            node.wins += outcome.winner == self._color
            node.draws += outcome.winner is None
        self._completed_trials += 1
        self._trial = None

    def _snapshot(self) -> tuple[CandidateEvaluation, ...]:
        candidates = []
        root = self._require_root()
        for square in root.moves:
            child = root.children.get(square)
            visits = child.visits if child is not None else 0
            wins = child.wins if child is not None else 0
            draws = child.draws if child is not None else 0
            inherited = self._inherited.get(square, 0)
            candidates.append(
                CandidateEvaluation(
                    square,
                    visits,
                    wins,
                    draws,
                    inherited,
                    visits - inherited,
                    (wins + 0.5 * draws) / visits if visits else None,
                )
            )
        return tuple(candidates)

    def _decision_snapshot(self) -> Square:
        candidates = self._snapshot()
        best = candidates[0]
        for row in candidates[1:]:
            if row.visits > best.visits or (
                row.visits == best.visits
                and (2 * row.wins + row.draws) * best.visits
                > (2 * best.wins + best.draws) * row.visits
            ):
                best = row
        return best.square

    @property
    def phase(self) -> Literal["PONDERING", "THINKING", "READY", "CLOSED"]:
        """探索の進行状態を返す。

        PONDERINGは相手番の先読み、THINKINGは自手番の追加思考、
        READYは結果確定後の待機、CLOSEDは終了を表す。
        """
        if self._root is None:
            return "CLOSED"
        if self._decision is not None:
            return "READY"
        return "THINKING" if self._deadline is not None else "PONDERING"

    def _expired(self) -> bool:
        return self._deadline is not None and self._clock() >= self._deadline

    def _adopt_root(self, root: _Node) -> None:
        if root.state == self._require_root().state:
            return
        self._trial = None
        self._decision = None
        self._root = root
        self._inherited = {
            square: child.visits for square, child in root.children.items()
        }
        self._deadline = None

    def request_move(self) -> None:
        """現在の自手番について、受信時点から追加予算を設定する。"""
        match self._require_root().state:
            case PlayingPosition(to_move=to_move) if to_move == self._color:
                if self._deadline is not None:
                    raise ValueError("この局面の着手は要求済みです")
                self._deadline = self._clock() + self._config.seconds
            case _:
                raise ValueError("この局面ではMCTSへ着手を要求できません")

    def run_slice(self, max_seconds: float = 0.01) -> Square | None:
        """途中の試行を再開し、時間を区切って呼び出し側へ戻る。

        時計は計算の区切りで確認するため、指定秒数は厳密な終了時刻ではない。
        自手番の期限を超えた試行は統計へ加えず破棄する。

        Args:
            max_seconds: 1回の呼び出しに割り当てる秒数。有限の正数。

        Returns:
            自手番の期限に達したら確定結果、それまではNone。確定後は同じ結果を返す。

        Raises:
            RuntimeError: 探索が終了済み。
            ValueError: max_secondsが有限の正数でない。boolも拒否する。
        """
        self._require_root()
        if type(max_seconds) not in (int, float) or not 0 < max_seconds < float("inf"):
            raise ValueError("max_seconds must be a finite positive number")
        if self._decision is not None:
            return self._decision
        end = self._clock() + max_seconds
        while not self._expired() and self._clock() < end:
            terminal = self._advance()
            if self._expired():
                break
            if terminal:
                self._backup()
        if self._expired():
            self._trial = None
            self._decision = self._decision_snapshot()
        return self._decision

    def _require_root(self) -> _Node:
        if self._root is None:
            raise RuntimeError("Search is closed")
        return self._root

    def _find_root(self, state: Position) -> _Node | None:
        root = self._require_root()
        queue = deque(root.children[square] for square in sorted(root.children))
        while queue:
            node = queue.popleft()
            if node.state == state:
                return node
            queue.extend(node.children[square] for square in sorted(node.children))
        return None

    def update(self, state: PlayingPosition) -> None:
        """実際の局面へ探索の起点を移し、乱数列を引き継ぐ。

        一致する部分木があれば採用し、なければ新しい起点を作る。
        局面が変われば途中試行と確定結果を破棄する。同じ局面なら何も変えない。
        期限を解除し、次のrequest_move()を待つ。

        Args:
            state: Rulesでパス・終局を判定済みの実局面。

        Raises:
            RuntimeError: 探索が終了済み。
        """
        if state == self._require_root().state:
            return
        retained = self._find_root(state)
        # 検索キューを解放し、採用する部分木以外の旧参照を外す。
        self._adopt_root(retained if retained is not None else self._node(state))

    def close(self) -> None:
        """探索の途中試行・集計・確定結果を解放し、終了状態にする。繰り返し呼べる。"""
        self._trial = None
        self._root = None
        self._decision = None
        self._inherited.clear()
        self._deadline = None
        self._completed_trials = 0


class MctsPlayer:
    """一局のMCTS探索を所有し、着手だけを一度返す。"""

    def __init__(self, search: MctsSearch, revision: Revision) -> None:
        self._search = search
        self._revision = revision
        self._delivered = False
        self._closed = False

    def observe(self, observation: CpuObservation) -> None:
        """実行側で順序検証済みの実局面へ起点を移す。"""
        self._revision = observation.revision
        self._delivered = False
        match observation.position:
            case PlayingPosition() as position:
                self._search.update(position)
            case FinishedPosition():
                self.close()
            case _:
                assert_never(observation.position)

    def request_move(self, request: CpuThinkRequest) -> None:
        """現局面への追加思考を始める。予算はMCTSのConfigが所有する。"""
        if self._closed or request.revision != self._revision:
            raise ValueError("着手要求の局面が現在のMCTS局面と一致しません")
        self._search.request_move()

    def step(self) -> ContinueWork | AwaitObservation | CpuDecision:
        """内部の短い時間単位を計算し、公開結果だけを返す。"""
        if self._closed or self._delivered:
            return AwaitObservation()
        square = self._search.run_slice()
        if square is None:
            return ContinueWork()
        self._delivered = True
        return CpuDecision(square=square)

    def close(self) -> None:
        """試行・統計・乱数への探索経路を終了する。繰り返し呼べる。"""
        self._closed = True
        self._search.close()


class MctsStrategy:
    """同期用の一時探索。渡されたseedをそのまま使用する。"""

    def __init__(self, *, seconds: float = 3.0) -> None:
        self._config = MctsConfig(seconds=seconds)

    def choose_move(self, position: PlayingPosition, seed: int) -> Square:
        """時間内に選び、成功・例外を問わず一時探索を終了する。"""
        search = MctsSearch(
            position,
            color=position.to_move,
            seed=seed,
            config=self._config,
        )
        try:
            search.request_move()
            while True:
                square = search.run_slice()
                if square is not None:
                    return square
        finally:
            search.close()
