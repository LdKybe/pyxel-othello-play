"""MCTS内部だけで扱う候補集計と判断。"""

from dataclasses import dataclass

from othello.core import Square


@dataclass(frozen=True, slots=True)
class CandidateEvaluation:
    """候補手を選んだ試行の集計を切り出した、変更不可の評価値。

    勝敗はCPUの担当色を基準に数える。実対局の対戦成績ではなく、
    探索中に終局まで完了した試行の成績を表す。

    Attributes:
        square: 候補手のマス番号（a1=0〜h8=63）。
        visits: この候補に集計した完了試行数。
        wins: 完了試行のうち、CPUの担当色が勝った回数。
        draws: 完了試行のうち引き分けになった回数。
        inherited_visits: 現在の実局面へ探索の起点を移した時点で引き継いだ試行数。
        added_visits: 起点を移した後の追加試行数。visitsとの差はinherited_visits。
        win_rate: (wins + draws / 2) / visits。0〜1の割合で、未試行ならNone。
    """

    square: Square
    visits: int
    wins: int
    draws: int
    inherited_visits: int
    added_visits: int
    win_rate: float | None
