"""MCが計算に使用する検証済み設定。"""

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class MonteCarloConfig:
    """追加思考秒数と、各試行の先頭から記憶する着手数。"""

    seconds: float = 3.0
    retention_depth: int = 6

    def __post_init__(self) -> None:
        if type(self.seconds) not in (int, float) or not 0 < self.seconds < float(
            "inf"
        ):
            raise ValueError("思考秒数は有限の正数が必要です")
        if type(self.retention_depth) is not int or self.retention_depth <= 0:
            raise ValueError("保持深さは正の整数が必要です")
