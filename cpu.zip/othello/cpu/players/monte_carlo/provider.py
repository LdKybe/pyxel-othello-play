"""MCの準備資源・確定設定と一局の探索生成。"""

import platform
from dataclasses import dataclass
from typing import assert_never

from othello.core import FinishedPosition, PlayingPosition
from othello.cpu.contracts import (
    CpuContext,
    CpuInfo,
    CpuRequest,
    Reproducibility,
)

from .config import MonteCarloConfig
from .inputs import build_request, parse_request
from .player import MonteCarloPlayer, MonteCarloSearch
from .seeds import derive_monte_carlo_seed


@dataclass(frozen=True, slots=True)
class MonteCarloPrepared:
    """検証済みConfigを所有する。MCには外部資源がない。"""

    config: MonteCarloConfig
    info: CpuInfo

    def start(self, context: CpuContext) -> MonteCarloPlayer:
        """局ごとのseedと独立した探索状態を生成する。"""
        seed = derive_monte_carlo_seed(
            context.base_seed,
            context.game_index,
            context.player_id,
        )
        match context.initial_observation.position:
            case PlayingPosition() as position:
                search = MonteCarloSearch(
                    position,
                    color=context.color,
                    seed=seed,
                    config=self.config,
                )
                return MonteCarloPlayer(search, context.initial_observation.revision)
            case FinishedPosition():
                raise ValueError("終局した局面ではMCを開始できません")
            case _:
                assert_never(context.initial_observation.position)

    def close(self) -> None:
        """解放する外部資源はない。繰り返し呼べる。"""


def prepare(request: CpuRequest) -> MonteCarloPrepared:
    """入力を検証し、方式内Configと正規化済みの設定情報を確定する。"""
    config = parse_request(request)
    normalized = build_request(
        seconds=config.seconds, retention_depth=config.retention_depth
    )
    info = CpuInfo(
        kind="monte-carlo",
        implementation_version="monte-carlo-continuous-v3",
        effective_options=normalized.options,
        resources=(),
        evaluation_unit="win-rate",
        reproducibility=Reproducibility(
            seed_policy_id="othello-mc-v2",
            random_source_id="python-random-v1",
            runtime_id=(
                f"{platform.python_implementation()} {platform.python_version()}"
            ),
            realtime_nondeterministic=True,
        ),
    )
    return MonteCarloPrepared(config=config, info=info)
