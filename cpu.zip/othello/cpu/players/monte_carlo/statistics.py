"""単純モンテカルロ専用の、担当色を固定した完了試行の集計。"""

from collections import OrderedDict
from dataclasses import dataclass

from othello.core import Color, Outcome, PlayingPosition

from .models import CandidateEvaluation, PositionMoveKey

STATISTICS_LIMIT = 20_000


@dataclass(slots=True)
class _Counts:
    visits: int = 0
    wins: int = 0
    draws: int = 0
    updated_at: int = 0


class StatisticsStore:
    """MCの完了試行を蓄積し、現在局面の候補を優先して保持する。

    現在局面の全候補は削除から保護する。それ以外は最後に成績を更新した順に
    管理し、上限を超えたら古い組から除く。実局面の切替はpromote()で通知する。

    Args:
        color: 勝敗を数える基準となるCPUの担当色。
        limit: 保持する局面・候補手の組の上限。現在局面の候補も件数に含む。

    Raises:
        ValueError: limitが正整数でない。
    """

    def __init__(self, *, color: Color, limit: int = STATISTICS_LIMIT) -> None:
        if type(limit) is not int or limit <= 0:
            raise ValueError("limit must be a positive integer")
        self._color = color
        self._limit = limit
        self._sequence = 0
        self._entries: OrderedDict[PositionMoveKey, _Counts] = OrderedDict()
        self._protected: dict[PositionMoveKey, _Counts] = {}
        self._baseline: dict[PositionMoveKey, int] = {}

    def __len__(self) -> int:
        return len(self._entries) + len(self._protected)

    def clear(self) -> None:
        """全統計と引継ぎ時点の試行数を消し、更新順も初期化する。"""
        self._entries.clear()
        self._protected.clear()
        self._baseline.clear()
        self._sequence = 0

    @staticmethod
    def _keys(state: PlayingPosition) -> tuple[PositionMoveKey, ...]:
        return tuple(
            PositionMoveKey(
                state.board.black,
                state.board.white,
                state.to_move,
                square,
            )
            for square in state.legal_moves
        )

    def _trim(self) -> None:
        while len(self) > self._limit:
            self._entries.popitem(last=False)

    def promote(self, state: PlayingPosition) -> tuple[CandidateEvaluation, ...]:
        """実局面の候補を保護し、引継ぎ時点の試行数を固定する。

        新しい候補を先に確保してから、旧候補の保護を解除する。

        Args:
            state: 実際に受理した局面。Rulesでパス・終局を判定済みの値。

        Returns:
            新しい起点の全候補評価。added_visitsは0から始まる。

        Raises:
            ValueError: 全合法候補を保持するための件数がlimitを超える。
        """
        keys = self._keys(state)
        if len(keys) > self._limit:
            raise ValueError("limit cannot hold current legal candidates")
        promoted = {}
        for key in keys:
            counts = self._protected.pop(key, None)
            if counts is None:
                counts = self._entries.pop(key, _Counts())
            promoted[key] = counts
        # 先に新候補を取り出し、旧候補の退避による上限整理から守る。
        self._entries.update(self._protected)
        # 保護中の更新も含む順序へ戻す。退避そのものを更新とは扱わない。
        self._entries = OrderedDict(
            sorted(self._entries.items(), key=lambda pair: pair[1].updated_at)
        )
        self._protected = promoted
        self._baseline = {key: counts.visits for key, counts in promoted.items()}
        self._trim()
        return self.snapshot(state)

    def record(self, trace: tuple[PositionMoveKey, ...], outcome: Outcome) -> None:
        """終局まで完了した1試行の成績を、記録対象の各手へ加算する。

        未完了の試行を渡さない責任は呼び出し側が持つ。
        各組の成績を更新するたびに、保持件数の上限を適用する。

        Args:
            trace: 試行中に残した着手前局面と候補手の組。
                同じ組が重複しても1回だけ加算する。
            outcome: 完了試行の終局結果。勝数は生成時のcolorを基準に数える。
        """
        for key in dict.fromkeys(trace):
            counts = self._protected.get(key)
            if counts is None:
                counts = self._entries.setdefault(key, _Counts())
                self._entries.move_to_end(key)
            self._sequence += 1
            counts.updated_at = self._sequence
            counts.visits += 1
            counts.wins += int(outcome.winner == self._color)
            counts.draws += int(outcome.winner is None)
            self._trim()

    def snapshot(self, state: PlayingPosition) -> tuple[CandidateEvaluation, ...]:
        """指定局面の全合法候補について、現在の集計を返す。

        統計を変更しない。引継ぎ数は最後のpromote()で固定した値を使い、
        そのときの候補に含まれない組では0とする。

        Args:
            state: Rulesでパス・終局を判定済みの局面。

        Returns:
            マス番号順の変更不可の評価列。未試行の勝率はNone、終局なら空。
        """
        result = []
        for key in self._keys(state):
            counts = self._protected.get(key)
            if counts is None:
                counts = self._entries.get(key, _Counts())
            inherited = self._baseline.get(key, 0)
            result.append(
                CandidateEvaluation(
                    key.square,
                    counts.visits,
                    counts.wins,
                    counts.draws,
                    inherited,
                    counts.visits - inherited,
                    (counts.wins + counts.draws / 2) / counts.visits
                    if counts.visits
                    else None,
                )
            )
        return tuple(result)
