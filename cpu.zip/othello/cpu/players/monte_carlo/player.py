"""MC内部の継続探索と共通操作への接続。"""

from collections.abc import Callable
from dataclasses import dataclass, field
from random import Random
from time import monotonic
from typing import Literal, assert_never

from othello.core import Color, FinishedPosition, PlayingPosition, Rules, Square
from othello.cpu.contracts import (
    AwaitObservation,
    ContinueWork,
    CpuDecision,
    CpuObservation,
    CpuThinkRequest,
)
from othello.match.identity import Revision

from .config import MonteCarloConfig
from .models import PositionMoveKey
from .seeds import validate_seed
from .statistics import StatisticsStore


@dataclass(slots=True)
class _Trial:
    """中断可能な試行。終局を確認したときだけtraceを集計する。"""

    state: PlayingPosition
    first: Square | None = None
    trace: list[PositionMoveKey] = field(default_factory=list)


class MonteCarloSearch:
    """1局・1CPUの乱数と探索状態を保持し、小刻みに計算を進める。

    局面・候補手ごとの統計と、候補ごとの途中試行を保持する。
    最終手は試行済み候補の勝率で選び、同率なら小さいマス番号を選ぶ。
    この探索型と統計は方式内専用であり、利用側はMonteCarloPlayerを使う。
    request_move()で自手番の追加思考の期限を設定する。
    相手番には期限を設けず、run_slice()が呼ばれた分だけ先読みする。

    Args:
        state: Rulesでパス・終局を判定済みの実局面。合法手が必要。
        color: 1局を通じて勝敗集計の基準となるCPU担当色。
        seed: 0以上の乱数シード。局面更新後も乱数列を引き継ぐ。
        config: 自手番の追加思考時間など、方式の検証済み設定。
        clock: 秒単位の単調増加する時刻を返す関数。通常はmonotonic。

    Raises:
        ValueError: シードの型または範囲が不正。
    """

    def __init__(
        self,
        state: PlayingPosition,
        *,
        color: Color,
        seed: int,
        config: MonteCarloConfig,
        clock: Callable[[], float] = monotonic,
    ) -> None:
        validate_seed(seed)
        self._rules = Rules()
        self._root = state
        self._color: Color = color
        self._config = config
        self._clock = clock
        self._rng = Random(seed)  # noqa: S311 - 対局内の明示シードによる試行。
        self._statistics = StatisticsStore(color=color)
        self._statistics.promote(state)
        self._trials: dict[Square | None, _Trial] = {}
        self._candidates = state.legal_moves
        self._cursor = 0
        self._deadline: float | None = None
        self._ready = False
        self._decision: Square | None = None
        self._closed = False
        self._completed_trials = 0

    @property
    def phase(self) -> Literal["PONDERING", "THINKING", "READY", "CLOSED"]:
        """探索の進行状態を返す。

        PONDERINGは相手番の先読み、THINKINGは自手番の追加思考、
        READYは結果確定後の待機、CLOSEDは終了を表す。
        """
        if self._closed:
            return "CLOSED"
        if self._ready:
            return "READY"
        return "THINKING" if self._deadline is not None else "PONDERING"

    @property
    def completed_trials(self) -> int:
        """生成後に集計した完了試行数を返す。局面更新では維持し、close()で0に戻す。"""
        return self._completed_trials

    def _advance(self, trial: _Trial) -> bool:
        state = trial.state
        moves = state.legal_moves
        square = trial.first if trial.first is not None else self._rng.choice(moves)
        trial.first = None
        if len(trial.trace) < self._config.retention_depth:
            trial.trace.append(
                PositionMoveKey(
                    state.board.black,
                    state.board.white,
                    state.to_move,
                    square,
                )
            )
        position = self._rules.play(state, square).position
        if self._expired():
            return False
        match position:
            case FinishedPosition(outcome=outcome):
                self._statistics.record(tuple(trial.trace), outcome)
                self._completed_trials += 1
                return True
            case PlayingPosition():
                trial.state = position
                return False
            case _:
                assert_never(position)

    def request_move(self) -> None:
        """現在の自手番について、受信時点から追加予算を設定する。"""
        if self._closed or self._root.to_move != self._color:
            raise ValueError("この局面ではMCへ着手を要求できません")
        if self._deadline is not None:
            raise ValueError("この局面の着手は要求済みです")
        self._deadline = self._clock() + self._config.seconds

    def run_slice(self, max_seconds: float = 0.01) -> Square | None:
        """途中の試行を再開し、時間を区切って呼び出し側へ戻る。

        時計は計算の区切りで確認するため、指定秒数は厳密な終了時刻ではない。
        自手番の期限を超えた試行は統計へ加えず破棄する。

        Args:
            max_seconds: 1回の呼び出しに割り当てる秒数。有限の正数。

        Returns:
            自手番の期限に達したら確定結果、それまではNone。確定後は同じ結果を返す。

        Raises:
            RuntimeError: 探索が終了済み。
            ValueError: max_secondsが有限の正数でない。boolも拒否する。
        """
        if self._closed:
            raise RuntimeError("Search is closed")
        if type(max_seconds) not in (int, float) or not 0 < max_seconds < float("inf"):
            raise ValueError("max_seconds must be a finite positive number")
        end = self._clock() + max_seconds
        while not self._ready and not self._expired() and self._clock() < end:
            key = self._candidates[self._cursor] if self._deadline is not None else None
            trial = self._trials.get(key)
            if trial is None:
                trial = _Trial(self._root, first=key)
                self._trials[key] = trial
            if self._advance(trial):
                del self._trials[key]
            self._cursor = (self._cursor + 1) % len(self._candidates)
        if self._expired():
            self._ready = True
            self._trials.clear()
        if self._ready and self._decision is None:
            self._decision = self._select()
        return self._decision

    def _select(self) -> Square:
        candidates = self._statistics.snapshot(self._root)
        rated = [row for row in candidates if row.visits]
        square = candidates[0].square
        if rated:
            best = rated[0]
            for row in rated[1:]:
                # 異なる分母を丸めず比較し、同率なら先の小さい位置を残す。
                if (2 * row.wins + row.draws) * best.visits > (
                    2 * best.wins + best.draws
                ) * row.visits:
                    best = row
            square = best.square
        return square

    def _expired(self) -> bool:
        return self._deadline is not None and self._clock() >= self._deadline

    def update(self, state: PlayingPosition) -> None:
        """実際の局面へ探索の起点を移し、乱数列を引き継ぐ。

        保持中の完了統計を使い、新しい局面の候補を削除から保護する。
        局面が変われば途中試行と確定結果を破棄する。同じ局面なら何も変えない。
        期限は解除し、次のrequest_move()を待つ。

        Args:
            state: Rulesでパス・終局を判定済みの実局面。

        Raises:
            RuntimeError: 探索が終了済み。
        """
        if self._closed:
            raise RuntimeError("Search is closed")
        if state == self._root:
            return
        candidates = state.legal_moves
        self._statistics.promote(state)
        self._root = state
        self._candidates = candidates
        self._trials.clear()
        self._cursor = 0
        self._ready = False
        self._decision = None
        self._deadline = None

    def close(self) -> None:
        """探索の途中試行・集計・確定結果を解放し、終了状態にする。繰り返し呼べる。"""
        self._closed = True
        self._trials.clear()
        self._statistics.clear()
        self._decision = None
        self._completed_trials = 0


class MonteCarloPlayer:
    """一局のMC探索を所有し、着手だけを一度返す。"""

    def __init__(self, search: MonteCarloSearch, revision: Revision) -> None:
        self._search = search
        self._revision = revision
        self._delivered = False
        self._closed = False

    def observe(self, observation: CpuObservation) -> None:
        """実行側で順序検証済みの実局面へ起点を移す。"""
        self._revision = observation.revision
        self._delivered = False
        match observation.position:
            case PlayingPosition() as position:
                self._search.update(position)
            case FinishedPosition():
                self.close()
            case _:
                assert_never(observation.position)

    def request_move(self, request: CpuThinkRequest) -> None:
        """現局面への追加思考を始める。予算はMCのConfigが所有する。"""
        if self._closed or request.revision != self._revision:
            raise ValueError("着手要求の局面が現在のMC局面と一致しません")
        self._search.request_move()

    def step(self) -> ContinueWork | AwaitObservation | CpuDecision:
        """内部の短い時間単位を計算し、公開結果だけを返す。"""
        if self._closed or self._delivered:
            return AwaitObservation()
        square = self._search.run_slice()
        if square is None:
            return ContinueWork()
        self._delivered = True
        return CpuDecision(square=square)

    def close(self) -> None:
        """試行・統計・乱数への探索経路を終了する。繰り返し呼べる。"""
        self._closed = True
        self._search.close()


class MonteCarloStrategy:
    """同期用の一時探索。渡されたseedをそのまま使用する。"""

    def __init__(self, *, seconds: float = 3.0, retention_depth: int = 6) -> None:
        self._config = MonteCarloConfig(
            seconds=seconds, retention_depth=retention_depth
        )

    def choose_move(self, position: PlayingPosition, seed: int) -> Square:
        """時間内に選び、成功・例外を問わず一時探索を終了する。"""
        search = MonteCarloSearch(
            position,
            color=position.to_move,
            seed=seed,
            config=self._config,
        )
        try:
            search.request_move()
            while True:
                square = search.run_slice()
                if square is not None:
                    return square
        finally:
            search.close()
