"""TD方式の軽量な型付き要求入口。"""

from othello.cpu.contracts import (
    CpuOption,
    CpuRequest,
    CpuResource,
    FileResource,
    FloatOption,
    IntOption,
    PackageResource,
)

from .config import TdConfig


def build_request(
    *, seconds: float = 3.0, model: FileResource | PackageResource | None = None
) -> CpuRequest:
    """指定した設定と資源の参照を共通の準備要求へ変換する。"""
    config = TdConfig(seconds=seconds)
    resources = () if model is None else (CpuResource(role="model", source=model),)
    return CpuRequest(
        kind="td",
        options=(CpuOption(name="seconds", value=FloatOption(value=config.seconds)),),
        resources=resources,
    )


def parse_request(request: CpuRequest) -> TdConfig:
    """方式名、設定名、値型と重複を検証する。"""
    if request.kind != "td":
        raise ValueError("TD方式のCPU設定ではありません")
    seconds: float | int = 3.0
    seen: set[str] = set()
    for option in request.options:
        if option.name in seen:
            raise ValueError(f"CPU設定が重複しています: {option.name}")
        seen.add(option.name)
        match option:
            case CpuOption(name="seconds", value=FloatOption(value=value)):
                if type(value) is not float:
                    raise ValueError("思考秒数は数値が必要です")
                seconds = value
            case CpuOption(name="seconds", value=IntOption(value=value)):
                if type(value) is not int:
                    raise ValueError("思考秒数は数値が必要です")
                seconds = value
            case _:
                raise ValueError(f"CPU設定の項目または値型が不正です: {option.name}")
    return TdConfig(seconds=seconds)
