"""製品の対局出力から独立した、固定深さ探索の開発用比較。"""

from __future__ import annotations

from dataclasses import dataclass
from math import inf
from statistics import median
from time import perf_counter
from typing import TYPE_CHECKING, Literal

from othello.core import FinishedPosition, PlayingPosition, Rules
from othello.cpu.players.td.search import PvsSearch, SearchResult
from othello.cpu.players.td.table import TranspositionTable

if TYPE_CHECKING:
    from othello.core import Color, Position, Square
    from othello.cpu.players.td.search import ValueModel
    from othello.cpu.players.td.table import PositionKey, TableProbe, TranspositionEntry

Method = Literal["full", "alpha_beta", "pvs", "pvs_tt"]
METHODS: tuple[Method, ...] = ("full", "alpha_beta", "pvs", "pvs_tt")


@dataclass(frozen=True, slots=True)
class Measurement:
    """一条件で繰り返し測った探索結果。計数は各反復で同一。"""

    value: float
    move: Square
    completed_depth: int
    nodes: int
    evaluations: int
    tt_hits: int
    researches: int
    max_tt_entries: int
    median_seconds: float


@dataclass(frozen=True, slots=True)
class Comparison:
    """同じモデル・局面・深さの4方式を一組として保持する。"""

    depth: int
    repeats: int
    methods: dict[Method, Measurement]


@dataclass(slots=True)
class _Counts:
    nodes: int = 0
    evaluations: int = 0


class _MeasuredTable(TranspositionTable):
    """PVSが実際に再利用した同深さの値と表の最大件数を記録する。"""

    def __init__(self) -> None:
        super().__init__()
        self.hits = 0
        self.max_entries = 0

    def probe(
        self, key: PositionKey, *, depth: int, alpha: float, beta: float
    ) -> TableProbe:
        result = super().probe(key, depth=depth, alpha=alpha, beta=beta)
        if result.cutoff:
            self.hits += 1
        return result

    def store(self, key: PositionKey, entry: TranspositionEntry) -> None:
        super().store(key, entry)
        self.max_entries = max(self.max_entries, len(self))


def _terminal_value(position: FinishedPosition, perspective: Color) -> float:
    difference = position.outcome.black_count - position.outcome.white_count
    return float(difference if perspective == "black" else -difference)


def _baseline_value(  # noqa: PLR0913, PLR0917 - 窓と計数を再帰へ明示的に渡す。
    position: Position,
    model: ValueModel,
    depth: int,
    alpha: float,
    beta: float,
    counts: _Counts,
    *,
    pruning: bool,
    perspective: Color,
) -> float:
    """ノード入口を一度数え、手番変化時だけ窓と符号を反転する。"""
    counts.nodes += 1
    if isinstance(position, FinishedPosition):
        return _terminal_value(position, perspective)
    if depth == 0:
        counts.evaluations += 1
        return model.evaluate(position, position.to_move)

    best = -inf
    for move in sorted(position.legal_moves):
        child = Rules.play(position, move).position
        if isinstance(child, FinishedPosition):
            candidate = _baseline_value(
                child,
                model,
                depth - 1,
                -inf,
                inf,
                counts,
                pruning=pruning,
                perspective=position.to_move,
            )
        elif child.to_move == position.to_move:
            candidate = _baseline_value(
                child,
                model,
                depth - 1,
                alpha,
                beta,
                counts,
                pruning=pruning,
                perspective=child.to_move,
            )
        else:
            candidate = -_baseline_value(
                child,
                model,
                depth - 1,
                -beta,
                -alpha,
                counts,
                pruning=pruning,
                perspective=child.to_move,
            )
        best = max(best, candidate)
        if pruning:
            alpha = max(alpha, best)
            if alpha >= beta:
                break
    return best


def _baseline(
    position: PlayingPosition, model: ValueModel, depth: int, *, pruning: bool
) -> tuple[SearchResult, _Counts]:
    counts = _Counts(nodes=1)  # rootの入口
    best = -inf
    best_move: Square | None = None
    alpha = -inf
    for move in sorted(position.legal_moves):
        child = Rules.play(position, move).position
        if isinstance(child, FinishedPosition):
            value = _baseline_value(
                child,
                model,
                depth - 1,
                -inf,
                inf,
                counts,
                pruning=pruning,
                perspective=position.to_move,
            )
        elif child.to_move == position.to_move:
            value = _baseline_value(
                child,
                model,
                depth - 1,
                alpha,
                inf,
                counts,
                pruning=pruning,
                perspective=child.to_move,
            )
        else:
            value = -_baseline_value(
                child,
                model,
                depth - 1,
                -inf,
                -alpha,
                counts,
                pruning=pruning,
                perspective=child.to_move,
            )
        if value > best:
            best, best_move = value, move
        if pruning:
            alpha = max(alpha, best)
    if best_move is None:
        raise AssertionError("playing position requires legal moves")
    return SearchResult(best, best_move), counts


def _run_once(
    method: Method,
    position: PlayingPosition,
    model: ValueModel,
    depth: int,
    max_operations: int,
) -> tuple[SearchResult, tuple[int, int, int, int, int]]:
    if method in ("full", "alpha_beta"):
        result, counts = _baseline(
            position, model, depth, pruning=method == "alpha_beta"
        )
        return result, (counts.nodes, counts.evaluations, 0, 0, 0)

    table = _MeasuredTable() if method == "pvs_tt" else None
    search = PvsSearch(position, model, depth, table=table)
    while True:
        completed = search.step(max_operations=max_operations)
        if completed is not None:
            break
    return completed, (
        search.nodes_visited,
        search.evaluations,
        table.hits if table is not None else 0,
        search.researches + search.tie_researches,
        table.max_entries if table is not None else 0,
    )


def compare_fixed_depth(
    position: PlayingPosition,
    model: ValueModel,
    depth: int,
    *,
    repeats: int = 3,
    max_operations: int = 128,
) -> Comparison:
    """4方式を同条件で測り、値・最良手の不一致を失敗として返す。"""
    if depth < 1 or repeats < 1 or max_operations < 1:
        raise ValueError("depth, repeats and max_operations must be positive")
    methods: dict[Method, Measurement] = {}
    expected: SearchResult | None = None
    for method in METHODS:
        timings: list[float] = []
        first: tuple[SearchResult, tuple[int, int, int, int, int]] | None = None
        for _ in range(repeats):
            start = perf_counter()
            result, counters = _run_once(method, position, model, depth, max_operations)
            timings.append(perf_counter() - start)
            if first is None:
                first = result, counters
            elif (result, counters) != first:
                raise AssertionError(f"{method}: repeated measurement changed")
        if first is None:
            raise AssertionError("positive repeats must produce a measurement")
        result, (nodes, evaluations, hits, researches, max_entries) = first
        if expected is None:
            expected = result
        elif result != expected:
            raise AssertionError(f"{method}: result differs from full search")
        if result.move is None:
            raise AssertionError("fixed-depth playing search requires a move")
        methods[method] = Measurement(
            result.value,
            result.move,
            depth,
            nodes,
            evaluations,
            hits,
            researches,
            max_entries,
            median(timings),
        )
    return Comparison(depth, repeats, methods)


__all__ = ["METHODS", "Comparison", "Measurement", "compare_fixed_depth"]
