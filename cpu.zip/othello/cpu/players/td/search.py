"""実着手数を深さとする、再開可能な Negamax PVS 探索。"""

from __future__ import annotations

from dataclasses import dataclass, field
from math import inf, nextafter
from typing import TYPE_CHECKING, Literal, Protocol, TypeAlias

from othello.core import FinishedPosition, PlayingPosition, Rules
from othello.cpu.players.td.table import (
    TranspositionEntry,
    TranspositionTable,
    key_for,
)

if TYPE_CHECKING:
    from collections.abc import Callable

    from othello.core import Color, Position, Square


class ValueModel(Protocol):
    """探索で読み取る、色視点の石数差予測。"""

    def evaluate(self, state: Position, perspective: Color) -> float:
        """不変モデルの有限な評価値を返す。"""
        ...


@dataclass(frozen=True, slots=True)
class SearchResult:
    """完了した固定深さ探索の値と最良着手。"""

    value: float
    move: Square | None


@dataclass(frozen=True, slots=True)
class SearchSnapshot:
    """必要な再探索まで完了した一つの反復の、私有の確定結果。"""

    depth: int
    move: Square | None
    value: float
    solved_to_terminal: bool


@dataclass(frozen=True, slots=True)
class _Candidate:
    """順序付け済みの一手。適用結果を再利用して二重適用しない。"""

    move: Square
    child: Position
    direct_value: float


@dataclass(slots=True)
class _Node:
    """合法手を持つ局面の窓と、完了済み候補の集計。"""

    position: PlayingPosition
    depth: int
    alpha: float
    beta: float
    entry_alpha: float = field(init=False)
    entry_beta: float = field(init=False)
    is_root: bool = False
    moves: tuple[_Candidate, ...] = ()
    ordered: list[_Candidate] | None = None
    order_cursor: int = 0
    preferred_move: Square | None = None
    cached_value: float | None = None
    cursor: int = 0
    best: float = -inf
    best_move: Square | None = None
    best_proven: bool = False
    all_proven: bool = True

    def __post_init__(self) -> None:
        self.entry_alpha = self.alpha
        self.entry_beta = self.beta


@dataclass(frozen=True, slots=True)
class _Enter:
    node: _Node


@dataclass(frozen=True, slots=True)
class _Evaluate:
    node: _Node


@dataclass(frozen=True, slots=True)
class _Order:
    node: _Node


@dataclass(frozen=True, slots=True)
class _OrderApply:
    node: _Node
    move: Square


@dataclass(frozen=True, slots=True)
class _OrderEvaluate:
    node: _Node
    move: Square
    child: Position


@dataclass(frozen=True, slots=True)
class _Select:
    node: _Node


@dataclass(frozen=True, slots=True)
class _Apply:
    node: _Node
    candidate: _Candidate
    alpha: float
    beta: float
    mode: Literal["normal", "probe", "improve", "tie"]


@dataclass(frozen=True, slots=True)
class _Descend:
    node: _Node
    candidate: _Candidate
    alpha: float
    beta: float
    mode: Literal["normal", "probe", "improve", "tie"]


@dataclass(frozen=True, slots=True)
class _Await:
    node: _Node
    candidate: _Candidate
    sign: int
    mode: Literal["normal", "probe", "improve", "tie"]


@dataclass(frozen=True, slots=True)
class _Terminal:
    position: FinishedPosition
    perspective: Color


_Work: TypeAlias = (
    _Enter
    | _Evaluate
    | _Order
    | _OrderApply
    | _OrderEvaluate
    | _Select
    | _Apply
    | _Descend
    | _Await
    | _Terminal
)


class PvsSearch:
    """反復深化中の探索スタックを保持し、有限個の原子的操作で進める。

    rootを含むPVSを行い、候補順序・狭窓・再探索も段階として保持する。
    置換表は呼出し側がモデルとplayerごとに所有し、完了ノードだけ共有する。
    depthを指定した場合は、その深さだけ探索する。省略時は深さ1から進める。
    """

    def __init__(  # noqa: PLR0913 - 探索窓外の設定は明示的なオプションに保つ
        self,
        position: Position,
        model: ValueModel,
        depth: int | None = None,
        *,
        perspective: Color | None = None,
        preferred_move_for: Callable[[PlayingPosition], Square | None] | None = None,
        table: TranspositionTable | None = None,
    ) -> None:
        if depth is not None and depth < 0:
            raise ValueError("depth must be a nonnegative integer")
        self._iterative = depth is None
        self._position = position
        if isinstance(position, FinishedPosition):
            self._max_depth = 0 if depth is None else depth
            self._current_depth = 0
        else:
            self._max_depth = (
                64 - (position.board.black | position.board.white).bit_count()
                if depth is None
                else depth
            )
            self._current_depth = 1 if depth is None else depth
        if isinstance(position, FinishedPosition):
            if perspective not in ("black", "white"):
                raise ValueError("perspective is required for a terminal root")
            root: _Work = _Terminal(position, perspective)
        else:
            root = _Enter(_Node(position, self._current_depth, -inf, inf, is_root=True))
        self._model = model
        self._table = table
        self._preferred_move_for = preferred_move_for
        self._stack: list[_Work] = [root]
        self._result: SearchResult | None = None
        self._snapshot: SearchSnapshot | None = None
        self._nodes_visited = 0
        self._evaluations = 0
        self._researches = 0
        self._tie_researches = 0

    @property
    def result(self) -> SearchResult | None:
        """探索が完了した場合だけ確定結果を返す。"""
        return self._result

    @property
    def snapshot(self) -> SearchSnapshot | None:
        """最後に完了した反復だけを返し、中断中の値は公開しない。"""
        return self._snapshot

    @property
    def nodes_visited(self) -> int:
        """各ノードの入口処理回数。再開だけでは増加しない。"""
        return self._nodes_visited

    @property
    def evaluations(self) -> int:
        """葉と候補順序付けでモデルを呼んだ回数。"""
        return self._evaluations

    @property
    def researches(self) -> int:
        """狭窓のfail-high後に広い窓で再探索した回数。"""
        return self._researches

    @property
    def tie_researches(self) -> int:
        """rootで小さい座標の同点上界を再検証した回数。"""
        return self._tie_researches

    def step(
        self,
        *,
        max_operations: int = 128,
        should_yield: Callable[[], bool] | None = None,
    ) -> SearchResult | None:
        """最大 ``max_operations`` 段階だけ進め、未完了なら ``None`` を返す。

        ``should_yield`` は各原子的操作の前後で確認する。期限や取消は
        呼出し側が所有し、その判定を受けた探索はスタックを保持する。
        """
        if max_operations <= 0:
            raise ValueError("max_operations must be a positive integer")
        for _ in range(max_operations):
            if self._result is not None:
                return self._result
            if should_yield is not None and should_yield():
                return None
            self._advance()
            if should_yield is not None and should_yield():
                return self._result
        return self._result

    def _advance(self) -> None:
        work = self._stack[-1]
        if isinstance(work, (_Enter, _Evaluate)):
            self._advance_entry(work)
        elif isinstance(work, (_Order, _OrderApply, _OrderEvaluate)):
            self._advance_order(work)
        else:
            self._advance_search(work)

    def _advance_entry(self, work: _Enter | _Evaluate) -> None:
        if isinstance(work, _Enter):
            self._nodes_visited += 1
            node = work.node
            if self._reuse_table_entry(node):
                return
            if node.depth == 0:
                self._stack[-1] = _Evaluate(node)
            else:
                node.ordered = []
                if node.preferred_move is None and self._preferred_move_for is not None:
                    node.preferred_move = self._preferred_move_for(node.position)
                self._stack[-1] = _Order(node)
        elif isinstance(work, _Evaluate):
            node = work.node
            if node.cached_value is None:
                value = self._model.evaluate(node.position, node.position.to_move)
                self._evaluations += 1
            else:
                value = node.cached_value
            self._finish(value, None, terminal_proven=False)

    def _reuse_table_entry(self, node: _Node) -> bool:
        table = self._table
        if table is None:
            return False
        key = key_for(node.position)
        if node.is_root:
            entry = table.get(key)
            if entry is not None:
                node.preferred_move = entry.best_move
            return False
        probe = table.probe(key, depth=node.depth, alpha=node.alpha, beta=node.beta)
        node.preferred_move = probe.best_move
        if not probe.cutoff:
            return False
        if probe.value is None:
            raise AssertionError("table cutoff requires a value")
        self._finish(
            probe.value, probe.best_move, terminal_proven=probe.terminal_proven
        )
        return True

    def _advance_order(self, work: _Order | _OrderApply | _OrderEvaluate) -> None:
        if isinstance(work, _Order):
            node = work.node
            if node.order_cursor == len(node.position.legal_moves):
                self._finish_order(node)
            else:
                self._stack[-1] = _OrderApply(
                    node, node.position.legal_moves[node.order_cursor]
                )
        elif isinstance(work, _OrderApply):
            child = Rules.play(work.node.position, work.move).position
            self._stack[-1] = _OrderEvaluate(work.node, work.move, child)
        elif isinstance(work, _OrderEvaluate):
            node = work.node
            if isinstance(work.child, FinishedPosition):
                value = self._terminal_value(work.child, node.position.to_move)
            else:
                value = self._model.evaluate(work.child, node.position.to_move)
                self._evaluations += 1
            if node.ordered is None:
                raise AssertionError("candidate ordering was not initialized")
            node.ordered.append(_Candidate(work.move, work.child, value))
            node.order_cursor += 1
            self._stack[-1] = _Order(node)

    def _finish_order(self, node: _Node) -> None:
        if node.ordered is None:
            raise AssertionError("candidate ordering was not initialized")
        node.moves = tuple(
            sorted(node.ordered, key=lambda item: self._order_key(node, item))
        )
        node.ordered = None
        self._stack[-1] = _Select(node)

    def _advance_search(self, work: _Work) -> None:
        if isinstance(work, _Select):
            node = work.node
            if node.cursor == len(node.moves) or node.alpha >= node.beta:
                terminal_proven = (
                    node.best_proven if node.alpha >= node.beta else node.all_proven
                )
                self._finish(node.best, node.best_move, terminal_proven=terminal_proven)
            else:
                alpha, beta, mode = self._candidate_window(node)
                self._stack[-1] = _Apply(
                    node, node.moves[node.cursor], alpha, beta, mode
                )
        elif isinstance(work, _Apply):
            self._stack[-1] = _Descend(
                work.node, work.candidate, work.alpha, work.beta, work.mode
            )
        elif isinstance(work, _Descend):
            self._descend(work)
        elif isinstance(work, _Terminal):
            self._nodes_visited += 1
            value = self._terminal_value(work.position, work.perspective)
            self._finish(value, None, terminal_proven=True)
        else:
            raise TypeError("search stack cannot advance an awaiting parent")

    @staticmethod
    def _terminal_value(position: FinishedPosition, perspective: Color) -> float:
        difference = position.outcome.black_count - position.outcome.white_count
        return float(difference if perspective == "black" else -difference)

    @staticmethod
    def _order_key(node: _Node, candidate: _Candidate) -> tuple[int, int, float, int]:
        return (
            0 if candidate.move == node.preferred_move else 1,
            0 if candidate.move in (0, 7, 56, 63) else 1,
            -candidate.direct_value,
            candidate.move,
        )

    @staticmethod
    def _candidate_window(
        node: _Node,
    ) -> tuple[float, float, Literal["normal", "probe"]]:
        if node.cursor == 0 or node.alpha == -inf:
            return node.alpha, node.beta, "normal"
        return node.alpha, min(nextafter(node.alpha, inf), node.beta), "probe"

    def _descend(self, work: _Descend) -> None:
        node = work.node
        parent_color = node.position.to_move
        child = work.candidate.child
        if isinstance(child, FinishedPosition):
            sign = 1
            child_work: _Work = _Terminal(child, parent_color)
        else:
            child_color = child.to_move
            sign = 1 if child_color == parent_color else -1
            alpha, beta = (
                (work.alpha, work.beta) if sign == 1 else (-work.beta, -work.alpha)
            )
            child_work = _Enter(
                _Node(
                    child,
                    node.depth - 1,
                    alpha,
                    beta,
                    cached_value=(
                        sign * work.candidate.direct_value if node.depth == 1 else None
                    ),
                )
            )
        self._stack[-1] = _Await(node, work.candidate, sign, work.mode)
        self._stack.append(child_work)

    def _finish(
        self, value: float, move: Square | None, *, terminal_proven: bool
    ) -> None:
        work = self._stack[-1]
        if self._table is not None and isinstance(work, (_Select, _Evaluate)):
            node = work.node
            self._table.store(
                key_for(node.position),
                TranspositionEntry(
                    depth=node.depth,
                    value=value,
                    bound=self._table.classify_bound(
                        value, node.entry_alpha, node.entry_beta
                    ),
                    best_move=move,
                    generation=self._table.generation,
                    terminal_proven=terminal_proven,
                ),
            )
        self._stack.pop()
        if not self._stack:
            self._snapshot = SearchSnapshot(
                self._current_depth, move, value, terminal_proven
            )
            if (
                self._iterative
                and not terminal_proven
                and self._current_depth < self._max_depth
                and isinstance(self._position, PlayingPosition)
            ):
                self._current_depth += 1
                self._stack = [
                    _Enter(
                        _Node(
                            self._position,
                            self._current_depth,
                            -inf,
                            inf,
                            is_root=True,
                        )
                    )
                ]
            else:
                self._result = SearchResult(value, move)
            return
        parent = self._stack[-1]
        if not isinstance(parent, _Await):
            raise TypeError("completed node requires an awaiting parent")
        node = parent.node
        candidate = value * parent.sign
        if parent.mode == "probe" and candidate > node.alpha and candidate < node.beta:
            self._researches += 1
            self._stack[-1] = _Descend(
                node, parent.candidate, node.alpha, node.beta, "improve"
            )
            return
        if (
            parent.mode == "probe"
            and node.is_root
            and candidate == node.alpha
            and node.best_move is not None
            and parent.candidate.move < node.best_move
        ):
            self._tie_researches += 1
            self._stack[-1] = _Descend(node, parent.candidate, -inf, inf, "tie")
            return
        if candidate > node.best or (
            candidate == node.best
            and (node.best_move is None or parent.candidate.move < node.best_move)
        ):
            node.best = candidate
            node.best_move = parent.candidate.move
            node.best_proven = terminal_proven
        node.all_proven = node.all_proven and terminal_proven
        node.alpha = max(node.alpha, candidate)
        node.cursor += 1
        self._stack[-1] = _Select(node)
