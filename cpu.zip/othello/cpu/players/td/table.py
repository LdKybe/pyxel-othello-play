"""TD探索が所有する、有限な置換表（transposition table）。

このモジュールは探索そのものを実行しない。探索側が完了したノードだけを
``store``へ渡し、``probe``が同じ深さの値を安全に再利用できるかを判定する。
異なる深さのentryは値を返さず、着手順序用の``best_move``だけを提供する。
"""

from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass
from enum import StrEnum
from math import isfinite, isnan
from typing import TYPE_CHECKING, Final

if TYPE_CHECKING:
    from othello.core import Color, PlayingPosition, Square

TABLE_CAPACITY: Final = 65_536
"""一つのplayerが所有できる置換表entryの最大数。"""


class Bound(StrEnum):
    """探索窓に対するentryの境界分類。"""

    EXACT = "EXACT"
    LOWER = "LOWER"
    UPPER = "UPPER"


@dataclass(frozen=True, slots=True)
class PositionKey:
    """盤面の黒白ビットボードと、探索する手番を完全に識別するキー。"""

    black: int
    white: int
    to_move: Color


def key_for(position: PlayingPosition) -> PositionKey:
    """``PlayingPosition``から、手番を含む完全キーを作る。"""
    return PositionKey(position.board.black, position.board.white, position.to_move)


@dataclass(frozen=True, slots=True)
class TranspositionEntry:
    """完了した探索ノードの値と、再利用に必要なメタデータ。"""

    depth: int
    value: float
    bound: Bound
    best_move: Square | None
    generation: int
    terminal_proven: bool

    def __post_init__(self) -> None:
        if self.depth < 0:
            raise ValueError("depth must be a nonnegative integer")
        if not isfinite(self.value):
            raise ValueError("value must be a finite number")
        if self.generation < 0:
            raise ValueError("generation must be a nonnegative integer")


@dataclass(frozen=True, slots=True)
class TableProbe:
    """置換表の照会結果。

    ``entry``は着手順序のためにも返すが、``value``が返るのは同深さで
    ``cutoff``が成立した場合だけである。``terminal_proven``も異深さでは
    falseにして、終局証明を深さ違いから誤って引き継がない。
    """

    entry: TranspositionEntry | None
    same_depth: bool
    cutoff: bool
    value: float | None
    best_move: Square | None
    terminal_proven: bool

    @property
    def reusable(self) -> bool:
        """値を現在の窓へそのまま返せるかを表す別名。"""
        return self.cutoff


class TranspositionTable:
    """playerごとに一つ所有する、世代付きOrderedDict LRU置換表。

    ``observe``は新しい実局面を知らせる世代カウンターだけを進める。
    世代変更時に表を走査・消去しないため、完了済み子ノードは後続の探索で
    再利用できる。容量を超えたときは最も古く参照されたentryを追い出す。
    """

    __slots__ = ("_capacity", "_entries", "_generation")

    def __init__(self, capacity: int = TABLE_CAPACITY) -> None:
        if capacity <= 0:
            raise ValueError("capacity must be a positive integer")
        self._capacity = capacity
        self._entries: OrderedDict[PositionKey, TranspositionEntry] = OrderedDict()
        self._generation = 0

    @property
    def capacity(self) -> int:
        """entryの最大件数。"""
        return self._capacity

    @property
    def generation(self) -> int:
        """現在の実局面世代。"""
        return self._generation

    def __len__(self) -> int:
        return len(self._entries)

    def __contains__(self, key: PositionKey) -> bool:
        return key in self._entries

    def clear(self) -> None:
        """表を空にし、世代カウンターを初期値へ戻す。"""
        self._entries.clear()
        self._generation = 0

    def observe(self) -> int:
        """新しい観測世代を開始し、その番号を返す。

        古いentryは削除しない。世代は同一キーの置換優先順位に使われる。
        """
        self._generation += 1
        return self._generation

    def get(self, key: PositionKey) -> TranspositionEntry | None:
        """キーのentryを取得し、参照したentryをLRU末尾へ移す。"""
        entry = self._entries.get(key)
        if entry is not None:
            self._entries.move_to_end(key)
        return entry

    @staticmethod
    def classify_bound(value: float, alpha: float, beta: float) -> Bound:
        """入口窓と返却値から、保存する境界分類を決める。"""
        _validate_window(alpha, beta)
        if not isfinite(value):
            raise ValueError("value must be a finite number")
        if value <= alpha:
            return Bound.UPPER
        if value >= beta:
            return Bound.LOWER
        return Bound.EXACT

    def probe(
        self,
        key: PositionKey,
        *,
        depth: int,
        alpha: float,
        beta: float,
    ) -> TableProbe:
        """entryを照会し、現在の深さと窓で値をカットできるか判定する。

        異深さのentryは``entry``と``best_move``に残るが、``value``と
        ``terminal_proven``は返さない。これにより手順序だけの再利用を
        探索側が明示的に扱える。
        """
        _validate_depth(depth)
        _validate_window(alpha, beta)
        entry = self.get(key)
        if entry is None:
            return TableProbe(
                entry=None,
                same_depth=False,
                cutoff=False,
                value=None,
                best_move=None,
                terminal_proven=False,
            )

        same_depth = entry.depth == depth
        if not same_depth:
            return TableProbe(
                entry=entry,
                same_depth=False,
                cutoff=False,
                value=None,
                best_move=entry.best_move,
                terminal_proven=False,
            )

        cutoff = (
            entry.bound is Bound.EXACT
            or (entry.bound is Bound.LOWER and entry.value >= beta)
            or (entry.bound is Bound.UPPER and entry.value <= alpha)
        )
        return TableProbe(
            entry=entry,
            same_depth=True,
            cutoff=cutoff,
            value=entry.value if cutoff else None,
            best_move=entry.best_move,
            terminal_proven=entry.terminal_proven,
        )

    def store(self, key: PositionKey, entry: TranspositionEntry) -> None:
        """完了entryを保存する。

        中断ノードを保存するかどうかは呼び出し側の探索が決め、このAPIは
        渡されたentryを完了済みとして扱う。
        """
        previous = self._entries.get(key)
        if previous is None or _should_replace(previous, entry):
            self._entries[key] = entry
            self._entries.move_to_end(key)
            while len(self._entries) > self._capacity:
                self._entries.popitem(last=False)


def _validate_depth(depth: int) -> None:
    if depth < 0:
        raise ValueError("depth must be a nonnegative integer")


def _validate_window(alpha: float, beta: float) -> None:
    if isnan(alpha) or isnan(beta) or alpha >= beta:
        raise ValueError("alpha must be less than beta")


def _should_replace(
    previous: TranspositionEntry, candidate: TranspositionEntry
) -> bool:
    """設計の世代・深さ・EXACT優先規則を比較する。"""
    if candidate.generation != previous.generation:
        return candidate.generation > previous.generation
    if candidate.depth != previous.depth:
        return candidate.depth > previous.depth
    if candidate.bound is Bound.EXACT:
        return True
    # 同深さ・同世代の非EXACT同士は最新の探索結果を採用する。
    return previous.bound is not Bound.EXACT


__all__ = [
    "TABLE_CAPACITY",
    "Bound",
    "PositionKey",
    "TableProbe",
    "TranspositionEntry",
    "TranspositionTable",
    "key_for",
]
