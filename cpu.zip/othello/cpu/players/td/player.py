"""TD探索の局専用CPU player。"""

from __future__ import annotations

from math import isfinite
from time import monotonic
from typing import TYPE_CHECKING

from othello.core import FinishedPosition, PlayingPosition, Square
from othello.cpu.contracts import (
    AwaitObservation,
    ContinueWork,
    CpuDecision,
    CpuObservation,
    CpuThinkRequest,
)

from .search import PvsSearch
from .table import TranspositionTable

if TYPE_CHECKING:
    from collections.abc import Callable

    from othello.cpu.contracts import CpuContext

    from .config import TdConfig
    from .search import ValueModel


class TdPlayer:
    """一局の実局面、探索、追加思考の時計を保持する。"""

    def __init__(  # noqa: PLR0913 - 計算区間と時計は方式内部へ明示注入する
        self,
        context: CpuContext,
        model: ValueModel,
        config: TdConfig,
        *,
        clock: Callable[[], float] = monotonic,
        slice_seconds: float = 0.01,
        max_operations: int = 128,
    ) -> None:
        if not isfinite(slice_seconds) or slice_seconds <= 0:
            raise ValueError("計算区間は有限の正数が必要です")
        if max_operations <= 0:
            raise ValueError("計算区間の最大操作数は正数が必要です")
        self._color = context.color
        self._config = config
        self._model: ValueModel | None = model
        self._clock = clock
        self._slice_seconds = slice_seconds
        self._max_operations = max_operations
        self._table = TranspositionTable()
        self._revision = context.initial_observation.revision
        self._position = context.initial_observation.position
        self._search: PvsSearch | None = None
        self._deadline: float | None = None
        self._delivered = False
        self._closed = False
        self._reset_search()
        if isinstance(self._position, FinishedPosition):
            self.close()

    def _reset_search(self) -> None:
        """現在の実局面から探索を開始し、旧スタックとsnapshotを外す。"""
        position = self._position
        model = self._model
        if model is None:
            raise RuntimeError("TD playerは解放済みです")
        if isinstance(position, PlayingPosition):
            self._search = PvsSearch(position, model, table=self._table)
        else:
            self._search = None

    def observe(self, observation: CpuObservation) -> None:
        """新しい実局面で探索をやり直し、同じ置換表の世代を進める。"""
        if self._closed:
            raise RuntimeError("TD playerは解放済みです")
        self._revision = observation.revision
        self._position = observation.position
        self._deadline = None
        self._delivered = False
        if isinstance(observation.position, FinishedPosition):
            self.close()
            return
        self._table.observe()
        self._reset_search()

    def request_move(self, request: CpuThinkRequest) -> None:
        """現revisionの自手番について、受信時刻から追加予算を始める。"""
        if self._closed or request.revision != self._revision:
            raise ValueError("着手要求の局面が現在のTD局面と一致しません")
        position = self._position
        if not isinstance(position, PlayingPosition) or position.to_move != self._color:
            raise ValueError("この局面ではTDへ着手を要求できません")
        if self._deadline is not None or self._delivered:
            raise ValueError("この局面の着手は要求済みです")
        self._deadline = self._clock() + self._config.seconds

    def step(self) -> ContinueWork | AwaitObservation | CpuDecision:
        """有限個の探索操作だけ進め、確定後は観測を待つ。"""
        if self._closed or self._delivered:
            return AwaitObservation()
        search = self._search
        if search is None:
            return AwaitObservation()
        return self._step_with_deadline(search)

    def _step_with_deadline(
        self, search: PvsSearch
    ) -> ContinueWork | AwaitObservation | CpuDecision:
        deadline = self._deadline
        if deadline is not None and self._clock() >= deadline:
            return self._deadline_decision(search)
        slice_deadline = self._clock() + self._slice_seconds

        def should_yield() -> bool:
            now = self._clock()
            return now >= slice_deadline or (deadline is not None and now >= deadline)

        result = search.step(
            max_operations=self._max_operations,
            should_yield=should_yield,
        )
        if deadline is None:
            return AwaitObservation() if result is not None else ContinueWork()
        if self._clock() >= deadline:
            return self._deadline_decision(search)
        snapshot = search.snapshot
        if result is not None and snapshot is not None and snapshot.solved_to_terminal:
            return self._decision(snapshot.move)
        return ContinueWork()

    def _deadline_decision(self, search: PvsSearch) -> CpuDecision:
        snapshot = search.snapshot
        if snapshot is not None:
            return self._decision(snapshot.move)
        position = self._position
        if not isinstance(position, PlayingPosition):
            raise TypeError("非終局の局面に合法手が必要です")
        return self._decision(min(position.legal_moves))

    def _decision(self, move: Square | None) -> CpuDecision:
        if move is None:
            raise AssertionError("非終局の探索結果には合法手が必要です")
        self._delivered = True
        return CpuDecision(square=move)

    def close(self) -> None:
        """探索と局専用の置換表を解放する。"""
        if self._closed:
            return
        self._closed = True
        self._search = None
        self._model = None
        self._deadline = None
        self._table.clear()
