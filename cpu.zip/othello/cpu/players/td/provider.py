"""TD方式のモデル準備と正規化済み設定情報。"""

from __future__ import annotations

import platform
from dataclasses import dataclass
from importlib import resources
from pathlib import Path, PurePosixPath, PureWindowsPath
from typing import TYPE_CHECKING

from othello.cpu.contracts import (
    CpuContext,
    CpuInfo,
    CpuRequest,
    CpuResource,
    FileResource,
    PackageResource,
    Reproducibility,
    ResourceIdentity,
)
from othello.learning.inference import (
    FrozenValueModel,
    ModelFormatError,
    load_model,
    load_model_bytes,
)

from .inputs import build_request, parse_request
from .player import TdPlayer

if TYPE_CHECKING:
    from .config import TdConfig

_MAX_MODEL_BYTES = 80 * 1024 * 1024
_DEFAULT_MODEL = PackageResource(
    package="othello.cpu.players.td.resources", name="default-model.json"
)


@dataclass(slots=True)
class PreparedTd:
    """検証済みの不変モデルを保持し、局ごとの探索を開始する。"""

    config: TdConfig
    info: CpuInfo
    _model: FrozenValueModel | None

    @property
    def model(self) -> FrozenValueModel:
        """解放前の検証済みモデルを返す。"""
        if self._model is None:
            raise RuntimeError("TD準備済みモデルは解放済みです")
        return self._model

    def start(self, context: CpuContext) -> TdPlayer:
        """同じ不変モデルから独立した一局の探索状態を作る。"""
        return TdPlayer(context, self.model, self.config)

    def close(self) -> None:
        """保持しているモデル参照を解放する。"""
        self._model = None


def _validated_model_source(request: CpuRequest) -> FileResource | PackageResource:
    if not request.resources:
        return _DEFAULT_MODEL
    if len(request.resources) != 1:
        raise ValueError("モデル資源が重複しています")
    resource: CpuResource = request.resources[0]
    if resource.role != "model":
        raise ValueError(f"未知のモデル資源roleです: {resource.role}")
    source = resource.source
    if isinstance(source, FileResource):
        if not Path(source.path).is_absolute():
            raise ValueError("モデル資源のファイルパスは絶対パスが必要です")
    else:
        name = source.name.replace("\\", "/")
        posix = PurePosixPath(name)
        windows = PureWindowsPath(source.name)
        if (
            not name
            or posix.is_absolute()
            or windows.is_absolute()
            or windows.drive
            or ".." in posix.parts
        ):
            raise ValueError("モデル資源のパッケージ名が安全ではありません")
    return source


def _load_model(source: FileResource | PackageResource) -> FrozenValueModel:
    if isinstance(source, FileResource):
        try:
            return load_model(Path(source.path))
        except OSError as error:
            raise ValueError(f"モデル資源を読み込めません: {error}") from error
        except ModelFormatError as error:
            raise ValueError(f"モデル資源が不正です: {error}") from error
        except ValueError as error:
            raise ValueError(f"モデル資源を読み込めません: {error}") from error
    try:
        with resources.files(source.package).joinpath(source.name).open("rb") as stream:
            data = stream.read(_MAX_MODEL_BYTES + 1)
    except (OSError, ImportError, TypeError, ValueError) as error:
        raise ValueError(f"モデル資源を読み込めません: {error}") from error
    try:
        return load_model_bytes(data)
    except ModelFormatError as error:
        raise ValueError(f"モデル資源が不正です: {error}") from error


def prepare(request: CpuRequest) -> PreparedTd:
    """要求を検証し、不変モデルと保存可能なCPU情報を確定する。"""
    config = parse_request(request)
    source = _validated_model_source(request)
    model = _load_model(source)
    info = CpuInfo(
        kind="td",
        implementation_version="othello-td-pvs-v1",
        effective_options=build_request(seconds=config.seconds).options,
        resources=(
            ResourceIdentity(role="model", content_id=model.model_id, format_version=2),
        ),
        reproducibility=Reproducibility(
            seed_policy_id="unused-deterministic-order",
            random_source_id="none",
            runtime_id=(
                f"{platform.python_implementation()} {platform.python_version()}"
            ),
            realtime_nondeterministic=True,
        ),
        evaluation_unit="discs",
    )
    return PreparedTd(config=config, info=info, _model=model)
