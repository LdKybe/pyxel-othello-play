"""TD方式の検証済み設定。"""

from dataclasses import dataclass
from math import isfinite


@dataclass(frozen=True, slots=True)
class TdConfig:
    """一回の着手要求で追加する秒数。"""

    seconds: float = 3.0

    def __post_init__(self) -> None:
        if type(self.seconds) not in (int, float):
            raise ValueError("思考秒数は数値が必要です")
        try:
            value = float(self.seconds)
        except OverflowError as error:
            raise ValueError("思考秒数が大きすぎます") from error
        if not isfinite(value) or value <= 0:
            raise ValueError("思考秒数は有限の正数が必要です")
        object.__setattr__(self, "seconds", value)
