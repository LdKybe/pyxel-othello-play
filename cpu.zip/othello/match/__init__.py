"""実対局の値を所有する。

識別子はidentity、記録はrecords、対局はaggregateを公開入口とする。
Workerがidentityだけを必要とするため、ここから他モジュールを読み込まない。
"""
