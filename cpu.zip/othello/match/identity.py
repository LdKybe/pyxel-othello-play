"""ゲーム上の識別子を区別する。実行環境やCPU方式を参照しない。"""

from typing import NewType

PlayerId = NewType("PlayerId", str)
GameId = NewType("GameId", int)
Revision = NewType("Revision", int)
MoveIndex = NewType("MoveIndex", int)
