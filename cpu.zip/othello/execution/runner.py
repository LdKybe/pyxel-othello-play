"""子側の単一実行ループで、CPU資源と操作順序を所有する。"""

from collections.abc import Callable
from dataclasses import dataclass, replace
from typing import assert_never

from othello.core import IllegalMoveError, PlayingPosition, Rules
from othello.cpu.catalog import prepare
from othello.cpu.contracts import (
    Accepted,
    AwaitObservation,
    ContinueWork,
    CpuContext,
    CpuDecision,
    CpuObservation,
    CpuPlayer,
    CpuRequest,
    CpuThinkRequest,
    Initial,
    PreparedCpu,
)
from othello.execution.contracts import (
    Close,
    Command,
    CommandEnvelope,
    Decision,
    DecisionId,
    Failed,
    MoveRequest,
    Notice,
    NoticeEnvelope,
    Observe,
    Observed,
    Prepare,
    Ready,
    RequestId,
    RequestMove,
    SessionId,
    Start,
    Started,
)
from othello.execution.contracts import (
    Closed as ClosedNotice,
)


class _ExecutionRejectedError(ValueError):
    """設定入力または外部からの要求順序を受理できない。"""


@dataclass(frozen=True, slots=True)
class Empty:
    """準備前。CPU資源をまだ所有しない。"""


@dataclass(frozen=True, slots=True, kw_only=True)
class PreparedRun:
    """準備済み資源だけを所有し、局開始を待つ。"""

    prepared: PreparedCpu
    request_id: RequestId


@dataclass(frozen=True, slots=True)
class NoRequest:
    """現在局面に対する判断要求はない。"""


@dataclass(frozen=True, slots=True, kw_only=True)
class WaitingDecision:
    """判断に付す要求IDを保持する。"""

    decision_id: DecisionId


@dataclass(frozen=True, slots=True, kw_only=True)
class DeliveredDecision:
    """現在局面の判断をすでに通知した。"""

    decision_id: DecisionId


@dataclass(frozen=True, slots=True, kw_only=True)
class RunningRun:
    """一局のCPU・準備資源・検証済み局面を一緒に所有する。"""

    prepared: PreparedCpu
    player: CpuPlayer
    context: CpuContext
    observation: CpuObservation
    last_request_id: RequestId
    pending: NoRequest | WaitingDecision | DeliveredDecision
    work: ContinueWork | AwaitObservation


@dataclass(frozen=True, slots=True)
class Closed:
    """CPU資源を所有せず、終了通知の生成有無だけを保持する。"""

    terminal_notice_created: bool = False


RunnerState = Empty | PreparedRun | RunningRun | Closed


class ExecutionRunner:
    """FIFOで届く要求を適用し、CPUを短い計算単位で進める。

    呼出しは子側の単一ループが直列化する。配送や待ち時間の期限は扱わず、
    handleの間にstepを呼んで相手手番にも計算を継続する。
    """

    def __init__(
        self,
        *,
        session_id: SessionId,
        prepare_cpu: Callable[[CpuRequest], PreparedCpu] = prepare,
    ) -> None:
        if session_id <= 0:
            raise ValueError("接続IDは正の整数が必要です")
        self._session_id = session_id
        self._received_sequence = 0
        self._sent_sequence = 0
        self._prepare_cpu = prepare_cpu
        self._state: RunnerState = Empty()
        self._notices: list[Notice] = []

    def handle(self, envelope: CommandEnvelope) -> None:
        """拒否は通知し、予期しない不具合は解放後に元の例外で返す。"""
        match self._state:
            case Closed():
                return
            case Empty() | PreparedRun() | RunningRun():
                pass
            case other:
                assert_never(other)
        try:
            if not self._accept_envelope(envelope):
                return
            self._dispatch(envelope.payload)
        except _ExecutionRejectedError as error:
            self._reject(error)
        except Exception as error:
            self._release_after_error(error)
            raise

    def _dispatch(self, command: Command) -> None:
        match command:
            case Prepare(request_id=request_id, request=request):
                self._prepare(request_id, request)
            case Start(context=context):
                self._start(context)
            case Observe(observation=observation):
                self._observe(observation)
            case RequestMove(request=request):
                self._request_move(request)
            case Close():
                self.close()
            case other_command:
                assert_never(other_command)

    def _accept_envelope(self, envelope: CommandEnvelope) -> bool:
        if envelope.session_id < self._session_id:
            return False
        if envelope.session_id != self._session_id:
            raise _ExecutionRejectedError("接続IDが一致しません")
        if envelope.sequence <= self._received_sequence:
            return False
        if envelope.sequence != self._received_sequence + 1:
            raise _ExecutionRejectedError("要求の連番が欠落しています")
        self._received_sequence = envelope.sequence
        return True

    def _prepare(self, request_id: RequestId, request: CpuRequest) -> None:
        match self._state:
            case Empty():
                try:
                    prepared = self._prepare_cpu(request)
                except (ValueError, OSError) as error:
                    raise _ExecutionRejectedError(
                        f"CPU準備に失敗しました: {error}"
                    ) from error
                self._state = PreparedRun(prepared=prepared, request_id=request_id)
                self._notices.append(
                    Ready(tag="ready", request_id=request_id, info=prepared.info)
                )
            case _:
                raise _ExecutionRejectedError("CPUの準備は実行開始時に一度だけ可能です")

    def _start(self, context: CpuContext) -> None:
        match self._state:
            case PreparedRun() as state:
                observation = context.initial_observation
                if (
                    observation.game_id != context.game_id
                    or observation.revision != 0
                    or observation.cause != Initial()
                    or observation.position != Rules.initial()
                ):
                    raise _ExecutionRejectedError(
                        "初期観測は同じ対局のrevision 0と標準初期局面が必要です"
                    )
                player = state.prepared.start(context)
                self._state = RunningRun(
                    prepared=state.prepared,
                    player=player,
                    context=context,
                    observation=observation,
                    last_request_id=state.request_id,
                    pending=NoRequest(),
                    work=ContinueWork(),
                )
                self._notices.append(Started(tag="started", game_id=context.game_id))
            case _:
                raise _ExecutionRejectedError("局開始にはCPUの準備完了が必要です")

    def _running(self) -> RunningRun:
        match self._state:
            case RunningRun() as state:
                return state
            case _:
                raise _ExecutionRejectedError("この操作にはCPUの局開始が必要です")

    def _observe(self, observation: CpuObservation) -> None:
        state = self._running()
        current = state.observation
        if (
            observation.game_id != current.game_id
            or observation.revision != current.revision + 1
        ):
            raise _ExecutionRejectedError(
                "観測は同じ対局の次revisionである必要があります"
            )
        match current.position, observation.cause:
            case PlayingPosition() as position, Accepted(square=square):
                try:
                    expected = Rules.play(position, square).position
                except IllegalMoveError as error:
                    raise _ExecutionRejectedError(
                        "通知された受理手が非合法です"
                    ) from error
                if expected != observation.position:
                    raise _ExecutionRejectedError("受理した着手と次局面が一致しません")
            case _:
                raise _ExecutionRejectedError(
                    "進行中の局面に受理済み着手を通知してください"
                )
        state.player.observe(observation)
        self._state = replace(
            state, observation=observation, pending=NoRequest(), work=ContinueWork()
        )
        self._notices.append(
            Observed(
                tag="observed",
                game_id=observation.game_id,
                revision=observation.revision,
            )
        )

    def _request_move(self, request: MoveRequest) -> None:
        state = self._running()
        identity = request.decision_id
        if (
            identity.request_id <= state.last_request_id
            or identity.game_id != state.context.game_id
            or identity.revision != state.observation.revision
            or identity.player_id != state.context.player_id
        ):
            raise _ExecutionRejectedError(
                "判断要求の識別情報が現在の局面と一致しません"
            )
        match state.pending:
            case NoRequest():
                pass
            case WaitingDecision() | DeliveredDecision():
                raise _ExecutionRejectedError("現在の局面の判断はすでに要求済みです")
            case other:
                assert_never(other)
        match state.observation.position:
            case PlayingPosition(to_move=color) if color == state.context.color:
                pass
            case _:
                raise _ExecutionRejectedError(
                    "担当手番の進行中局面だけで判断を要求できます"
                )
        state.player.request_move(CpuThinkRequest(revision=identity.revision))
        self._state = replace(
            state,
            last_request_id=identity.request_id,
            pending=WaitingDecision(decision_id=identity),
            work=ContinueWork(),
        )

    def step(self) -> bool:
        """短い計算を一回行い、観測なしに続けられる場合はTrueを返す。"""
        match self._state:
            case RunningRun() as state:
                pass
            case Empty() | PreparedRun() | Closed():
                return False
            case other:
                assert_never(other)
        match state.work:
            case AwaitObservation():
                return False
            case ContinueWork():
                pass
            case other_work:
                assert_never(other_work)
        try:
            result = state.player.step()
            match result:
                case ContinueWork():
                    return True
                case AwaitObservation():
                    self._state = replace(state, work=result)
                    return False
                case CpuDecision():
                    self._deliver(state, result)
                    return False
                case other_result:
                    assert_never(other_result)
        except _ExecutionRejectedError as error:
            self._reject(error)
            return False
        except Exception as error:
            self._release_after_error(error)
            raise

    def _deliver(self, state: RunningRun, result: CpuDecision) -> None:
        match state.pending, state.observation.position:
            case WaitingDecision(decision_id=identity), PlayingPosition() as position:
                if result.square not in position.legal_moves:
                    raise _ExecutionRejectedError("CPUが非合法手を返しました")
                self._notices.append(
                    Decision(tag="decision", decision_id=identity, decision=result)
                )
                self._state = replace(
                    state,
                    pending=DeliveredDecision(decision_id=identity),
                    work=AwaitObservation(),
                )
            case _:
                raise _ExecutionRejectedError(
                    "判断要求のない局面でCPUが判断を返しました"
                )

    def poll(self) -> tuple[NoticeEnvelope, ...]:
        """蓄積した通知を発生順に一度だけ取り出す。"""
        notices = tuple(
            NoticeEnvelope(
                protocol="othello-execution-v3",
                session_id=self._session_id,
                sequence=self._sent_sequence + offset,
                payload=notice,
            )
            for offset, notice in enumerate(self._notices, start=1)
        )
        self._sent_sequence += len(notices)
        self._notices.clear()
        return notices

    def close(self) -> None:
        """player、preparedの順で解放し、失敗はExceptionGroupで返す。"""
        match self._state:
            case Closed():
                return
            case Empty() | PreparedRun() | RunningRun():
                pass
            case other:
                assert_never(other)
        self._notices.clear()
        errors = self._release()
        if errors:
            raise ExceptionGroup("CPU資源の解放に失敗しました", errors)
        self._notices.append(ClosedNotice(tag="closed"))
        self._state = Closed(terminal_notice_created=True)

    def fail(self, message: str) -> None:
        """配送側が検出した契約違反を通知し、CPU資源を解放する。"""
        self._reject(_ExecutionRejectedError(message))

    def _reject(self, error: _ExecutionRejectedError) -> None:
        match self._state:
            case Closed(terminal_notice_created=created):
                if not created:
                    self._notices.append(Failed(tag="failed", message=str(error)))
                    self._state = Closed(terminal_notice_created=True)
                return
            case Empty() | PreparedRun() | RunningRun():
                pass
            case other:
                assert_never(other)
        self._notices.clear()
        errors = self._release()
        if errors:
            raise ExceptionGroup(
                "CPU実行の拒否と資源解放の失敗", [error, *errors]
            ) from None
        self._notices.append(Failed(tag="failed", message=str(error)))
        self._state = Closed(terminal_notice_created=True)

    def _release_after_error(self, error: Exception) -> None:
        # 最外周が致命的失敗として扱えるよう、型と発生箇所を失わず戻す。
        self._notices.clear()
        errors = self._release()
        if errors:
            raise ExceptionGroup("CPU実行と資源解放の失敗", [error, *errors]) from None

    def _release(self) -> tuple[Exception, ...]:
        state, self._state = self._state, Closed()
        resources: tuple[CpuPlayer | PreparedCpu, ...]
        match state:
            case RunningRun(player=player, prepared=prepared):
                resources = (player, prepared)
            case PreparedRun(prepared=prepared):
                resources = (prepared,)
            case Empty() | Closed():
                resources = ()
            case other:
                assert_never(other)
        errors = []
        for resource in resources:
            try:
                resource.close()
            except Exception as error:  # noqa: BLE001 - 一方の失敗でも残りの解放を試みる。
                errors.append(error)
        return tuple(errors)
