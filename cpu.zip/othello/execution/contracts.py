"""実行環境を知らない、要求・通知・資源解放の型付き契約。"""

from dataclasses import dataclass
from typing import Literal, NewType, Protocol

from othello.cpu.contracts import (
    CpuContext,
    CpuDecision,
    CpuInfo,
    CpuObservation,
    CpuRequest,
)
from othello.match.identity import GameId, PlayerId, Revision

RequestId = NewType("RequestId", int)
SessionId = NewType("SessionId", int)


@dataclass(frozen=True, slots=True, kw_only=True)
class DecisionId:
    """一回の着手要求と、その対象局面を識別する。"""

    request_id: RequestId
    game_id: GameId
    revision: Revision
    player_id: PlayerId


@dataclass(frozen=True, slots=True, kw_only=True)
class MoveRequest:
    """対象局面について追加思考を開始する要求。"""

    decision_id: DecisionId


@dataclass(frozen=True, slots=True, kw_only=True)
class Prepare:
    """準備要求。"""

    tag: Literal["prepare"]
    request_id: RequestId
    request: CpuRequest


@dataclass(frozen=True, slots=True, kw_only=True)
class Start:
    """局開始要求。"""

    tag: Literal["start"]
    context: CpuContext


@dataclass(frozen=True, slots=True, kw_only=True)
class Observe:
    """確定局面の通知要求。"""

    tag: Literal["observe"]
    observation: CpuObservation


@dataclass(frozen=True, slots=True, kw_only=True)
class RequestMove:
    """着手判断要求。"""

    tag: Literal["request_move"]
    request: MoveRequest


@dataclass(frozen=True, slots=True, kw_only=True)
class Close:
    """実行終了要求。"""

    tag: Literal["close"]


@dataclass(frozen=True, slots=True, kw_only=True)
class Ready:
    """準備完了通知。"""

    tag: Literal["ready"]
    request_id: RequestId
    info: CpuInfo


@dataclass(frozen=True, slots=True, kw_only=True)
class Started:
    """局開始完了通知。"""

    tag: Literal["started"]
    game_id: GameId


@dataclass(frozen=True, slots=True, kw_only=True)
class Observed:
    """観測受理通知。"""

    tag: Literal["observed"]
    game_id: GameId
    revision: Revision


@dataclass(frozen=True, slots=True, kw_only=True)
class Decision:
    """要求に対応する判断通知。"""

    tag: Literal["decision"]
    decision_id: DecisionId
    decision: CpuDecision


@dataclass(frozen=True, slots=True, kw_only=True)
class Failed:
    """実行失敗通知。"""

    tag: Literal["failed"]
    message: str


@dataclass(frozen=True, slots=True, kw_only=True)
class Closed:
    """子側の終了完了通知。"""

    tag: Literal["closed"]


Command = Prepare | Start | Observe | RequestMove | Close
Notice = Ready | Started | Observed | Decision | Failed | Closed


@dataclass(frozen=True, slots=True, kw_only=True)
class CommandEnvelope:
    """親から子への、版・接続・順序を持つ要求。"""

    protocol: Literal["othello-execution-v3"]
    session_id: SessionId
    sequence: int
    payload: Command


@dataclass(frozen=True, slots=True, kw_only=True)
class NoticeEnvelope:
    """子から親への、版・接続・順序を持つ通知。"""

    protocol: Literal["othello-execution-v3"]
    session_id: SessionId
    sequence: int
    payload: Notice


@dataclass(frozen=True, slots=True)
class Pending:
    """資源の回収がまだ完了していない。"""


@dataclass(frozen=True, slots=True)
class Released:
    """すべての実行資源を回収した。"""


@dataclass(frozen=True, slots=True, kw_only=True)
class ReleaseFailed:
    """実行資源の回収が失敗した。"""

    message: str


CloseReport = Pending | Released | ReleaseFailed


class CpuBackend(Protocol):
    """一局の準備・観測・判断要求と通知を接続する。"""

    def prepare(self, request: CpuRequest) -> RequestId:
        """準備を開始して、その要求の識別子を返す。"""
        ...

    def start(self, context: CpuContext) -> None:
        """準備済みCPUの局を開始する。"""
        ...

    def observe(self, observation: CpuObservation) -> None:
        """受理済みの局面を順に通知する。"""
        ...

    def request_move(self, revision: Revision) -> DecisionId:
        """現行局面の判断を要求し、発行した識別子を返す。"""
        ...

    def set_decision_delivery(self, enabled: bool) -> None:  # noqa: FBT001 - 配送の有効・保留を表す公開操作。
        """判断の配送だけを有効／保留にする。"""
        ...

    def poll(self) -> tuple[Notice, ...]:
        """今届いている通知を順に取り出す。"""
        ...

    def close(self) -> CloseReport:
        """ブロックせず資源解放を進める。"""
        ...


class Transport(Protocol):
    """実行環境の配送とハンドルの寿命を所有する。"""

    def send(self, command: CommandEnvelope) -> None:
        """要求を送信順に配送する。"""
        ...

    def poll(self) -> tuple[NoticeEnvelope, ...]:
        """受信した通知を順に返す。"""
        ...

    def close(self) -> CloseReport:
        """ハンドルの解放を進める。"""
        ...
