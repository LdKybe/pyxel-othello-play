"""型付きの実行契約と外部表現を、方向別に変換する。"""

from dataclasses import dataclass
from typing import Literal, TypeVar, assert_never

from othello.core import (
    Board,
    Color,
    FinishedPosition,
    InvalidBoardError,
    Outcome,
    PlayingPosition,
    Position,
    Rules,
)
from othello.cpu.contracts import Accepted, CpuObservation, Initial
from othello.cpu.contracts.input import (
    BoolOption,
    FloatOption,
    IntOption,
    NoneOption,
    OptionValue,
    TextOption,
)
from othello.encoding.builder import CodecBuilder
from othello.encoding.converter import CodecError, RecordCodec
from othello.serialization.cpu_options import (
    OptionImage,
    option_from_image,
    option_to_image,
)

from .contracts import (
    Close,
    Closed,
    CommandEnvelope,
    Decision,
    DecisionId,
    Failed,
    NoticeEnvelope,
    Observe,
    Observed,
    Prepare,
    Ready,
    RequestMove,
    SessionId,
    Start,
    Started,
)

T = TypeVar("T")
_MAX_OPTIONS = 64
_BOARD_SIZE = 64


@dataclass(frozen=True, slots=True, kw_only=True)
class PlayingImage:
    """進行中の局面の手番。合法手はRulesで導出する。"""

    tag: Literal["playing"]
    to_move: Color


@dataclass(frozen=True, slots=True, kw_only=True)
class FinishedImage:
    """終局を表す結果。復元時に盤面から照合する。"""

    tag: Literal["finished"]
    outcome: Outcome


@dataclass(frozen=True, slots=True, kw_only=True)
class PositionImage:
    """盤面の整数対と、進行中または終局の情報。"""

    board: Board
    state: PlayingImage | FinishedImage


def position_to_image(position: Position) -> PositionImage:
    """coreの公開局面から、必要な差分だけを外部表現へ移す。"""
    try:
        board = Board(black=position.board.black, white=position.board.white)
    except InvalidBoardError as exc:
        raise CodecError("盤面は重複のない64ビット整数対が必要です @ .board") from exc
    match position:
        case PlayingPosition():
            return PositionImage(
                board=board,
                state=PlayingImage(tag="playing", to_move=position.to_move),
            )
        case FinishedPosition():
            return PositionImage(
                board=board,
                state=FinishedImage(tag="finished", outcome=position.outcome),
            )
        case _:
            assert_never(position)


def position_from_image(image: PositionImage) -> Position:
    """Rulesを通して復元し、送信された状態との一致を確認する。"""
    match image.state:
        case PlayingImage(to_move=color):
            restored = Rules.restore(image.board, color)
            match restored:
                case PlayingPosition() if restored.to_move == color:
                    return restored
                case _:
                    raise CodecError("局面の手番が盤面と一致しません @ .state.to_move")
        case FinishedImage(outcome=outcome):
            restored = Rules.restore(image.board, "black")
            match restored:
                case FinishedPosition() if restored.outcome == outcome:
                    return restored
                case _:
                    raise CodecError("終局結果が盤面と一致しません @ .state.outcome")
        case other:
            assert_never(other)


def _codec(record_type: type[T]) -> RecordCodec[T]:
    builder = CodecBuilder()
    option_types: tuple[type[OptionValue], ...] = (
        BoolOption,
        IntOption,
        FloatOption,
        TextOption,
        NoneOption,
    )
    position_types: tuple[type[Position], ...] = (PlayingPosition, FinishedPosition)
    builder.register_union(
        option_types, OptionImage, option_to_image, option_from_image
    )
    builder.register_union(
        position_types, PositionImage, position_to_image, position_from_image
    )
    return builder.build(record_type)


_COMMAND_CODEC = _codec(CommandEnvelope)
_NOTICE_CODEC = _codec(NoticeEnvelope)


def _integer_at_least(value: int, minimum: int, path: str) -> None:
    if type(value) is not int or value < minimum:
        raise CodecError(f"{minimum}以上の整数が必要です @ {path}")


def _square(square: int, path: str) -> None:
    _integer_at_least(square, 0, path)
    if square >= _BOARD_SIZE:
        raise CodecError(f"マスは0から63の範囲です @ {path}")


def _decision_id(value: DecisionId) -> None:
    _integer_at_least(value.request_id, 1, "$.payload.decision_id.request_id")
    _integer_at_least(value.game_id, 1, "$.payload.decision_id.game_id")
    _integer_at_least(value.revision, 0, "$.payload.decision_id.revision")
    if not value.player_id:
        raise CodecError(
            "プレイヤーIDは空にできません @ $.payload.decision_id.player_id"
        )


def _observation(value: CpuObservation) -> None:
    _integer_at_least(value.game_id, 1, "$.payload.observation.game_id")
    _integer_at_least(value.revision, 0, "$.payload.observation.revision")
    match value.cause:
        case Initial():
            pass
        case Accepted(square=square):
            _square(square, "$.payload.observation.cause.square")
        case other:
            assert_never(other)


def _envelope(session_id: SessionId, sequence: int) -> None:
    _integer_at_least(session_id, 1, "$.session_id")
    _integer_at_least(sequence, 1, "$.sequence")


def _validate_command(value: CommandEnvelope) -> None:
    _envelope(value.session_id, value.sequence)
    match value.payload:
        case Prepare(request_id=request_id, request=request):
            _integer_at_least(request_id, 1, "$.payload.request_id")
            if len(request.options) > _MAX_OPTIONS:
                raise CodecError("設定は64件以内です @ $.payload.request.options")
        case Start(context=context):
            _integer_at_least(context.base_seed, 0, "$.payload.context.base_seed")
            _integer_at_least(context.game_index, 0, "$.payload.context.game_index")
            _integer_at_least(context.game_id, 1, "$.payload.context.game_id")
            if not context.player_id:
                raise CodecError(
                    "プレイヤーIDは空にできません @ $.payload.context.player_id"
                )
            _observation(context.initial_observation)
        case Observe(observation=observation):
            _observation(observation)
        case RequestMove(request=request):
            _decision_id(request.decision_id)
        case Close():
            pass
        case other:
            assert_never(other)


def _validate_notice(value: NoticeEnvelope) -> None:
    _envelope(value.session_id, value.sequence)
    match value.payload:
        case Ready(request_id=request_id, info=info):
            _integer_at_least(request_id, 1, "$.payload.request_id")
            if len(info.effective_options) > _MAX_OPTIONS:
                raise CodecError(
                    "設定は64件以内です @ $.payload.info.effective_options"
                )
        case Started(game_id=game_id):
            _integer_at_least(game_id, 1, "$.payload.game_id")
        case Observed(game_id=game_id, revision=revision):
            _integer_at_least(game_id, 1, "$.payload.game_id")
            _integer_at_least(revision, 0, "$.payload.revision")
        case Decision(decision_id=decision_id, decision=decision):
            _decision_id(decision_id)
            _square(decision.square, "$.payload.decision.square")
        case Failed() | Closed():
            pass
        case other:
            assert_never(other)


def encode_command(value: CommandEnvelope) -> bytes:
    """要求方向の型と共通上限を検証して外部表現を作る。"""
    _validate_command(value)
    return _COMMAND_CODEC.encode(value)


def decode_command(value: bytes) -> CommandEnvelope:
    """要求方向の型へ復元し、適用前に共通上限を検証する。"""
    restored = _COMMAND_CODEC.decode(value)
    _validate_command(restored)
    return restored


def encode_notice(value: NoticeEnvelope) -> bytes:
    """通知方向の型と共通上限を検証して外部表現を作る。"""
    _validate_notice(value)
    return _NOTICE_CODEC.encode(value)


def decode_notice(value: bytes) -> NoticeEnvelope:
    """通知方向の型へ復元し、適用前に共通上限を検証する。"""
    restored = _NOTICE_CODEC.decode(value)
    _validate_notice(restored)
    return restored
