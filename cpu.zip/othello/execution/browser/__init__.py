"""ブラウザ実行。親のtransport/ffiと子のworkerを明示して読み込む。"""
