"""Workerの単一ループを共通runnerへ接続する。"""

from collections import deque

from othello.encoding.converter import CodecError
from othello.execution.codec import decode_command, encode_notice
from othello.execution.contracts import Closed, Failed, NoticeEnvelope, SessionId
from othello.execution.runner import ExecutionRunner


class WorkerSession:
    """文字列境界と未配送通知を所有し、CPU状態はrunnerへ委ねる。"""

    def __init__(self, *, session_id: SessionId) -> None:
        self._runner = ExecutionRunner(session_id=session_id)
        self._pending: deque[NoticeEnvelope] = deque()
        self._closed = False

    @property
    def closed(self) -> bool:
        """Worker側のタイマーを停止してよいか返す。"""
        return self._closed

    def accept(self, raw: str) -> None:
        """復元した要求をそのままrunnerへ渡す。"""
        if self._closed:
            return
        try:
            command = decode_command(raw.encode("utf-8"))
        except (CodecError, UnicodeError) as error:
            self._runner.fail(f"CPU要求の形式が不正です: {error}")
            return
        try:
            self._runner.handle(command)
        except Exception as error:
            self._runner.fail(f"CPUの子実行に失敗しました: {error}")
            raise

    def tick(self) -> bool:
        """一単位の計算を進め、次の計算予約が必要か返す。"""
        if self._closed:
            return False
        try:
            return self._runner.step()
        except Exception as error:
            self._runner.fail(f"CPUの子実行に失敗しました: {error}")
            raise

    def poll(self) -> str:
        """通知をFIFOで一件返し、終端通知も一度だけ配送する。"""
        if self._closed:
            return ""
        if not self._pending:
            self._pending.extend(self._runner.poll())
        if not self._pending:
            return ""
        notice = self._pending[0]
        raw = encode_notice(notice).decode("utf-8")
        self._pending.popleft()
        match notice.payload:
            case Closed() | Failed():
                self._closed = True
            case _:
                pass
        return raw

    def close(self) -> None:
        """外側からの終了では未配送通知を破棄して資源を解放する。"""
        self._closed = True
        self._pending.clear()
        self._runner.close()
