"""型付きの変換を事前登録し、一つの固定codecを生成する。"""

from collections.abc import Callable
from functools import reduce
from operator import or_
from typing import TypeVar

from .converter import RecordCodec, _configure, _PreparedRecordCodec

D = TypeVar("D")
W = TypeVar("W")
T = TypeVar("T")
_MIN_UNION_MEMBERS = 2


class CodecBuilder:
    """登録の所有権をbuild時にcodecへ移す。"""

    def __init__(self) -> None:
        self._converter = _configure()
        self._registered: set[frozenset[type]] = set()
        self._built = False

    def register_union(
        self,
        domain_types: tuple[type[D], ...],
        image_type: type[W],
        to_image: Callable[[D], W],
        from_image: Callable[[W], D],
    ) -> None:
        """個々の型を変えず、指定したunion全体だけを変換する。"""
        self._ensure_open()
        members = frozenset(domain_types)
        if len(members) < _MIN_UNION_MEMBERS or len(members) != len(domain_types):
            raise ValueError("unionには二つ以上の異なる型が必要です")
        if members in self._registered:
            raise ValueError("このunionは登録済みです")
        union = reduce(or_, domain_types)
        converter = self._converter

        def structure(value: object, _: object) -> D:
            return from_image(converter.structure(value, image_type))

        def unstructure(value: D) -> object:
            return converter.unstructure(to_image(value), image_type)

        converter.register_structure_hook_func(lambda kind: kind == union, structure)
        converter.register_unstructure_hook_func(
            lambda kind: kind == union, unstructure
        )
        self._registered.add(members)

    def build(self, record_type: type[T]) -> RecordCodec[T]:
        """全登録を固定し、レコードの変換を生成する。"""
        self._ensure_open()
        codec = _PreparedRecordCodec(record_type, self._converter)
        self._built = True
        return codec

    def _ensure_open(self) -> None:
        if self._built:
            raise ValueError("codecは生成済みです")
