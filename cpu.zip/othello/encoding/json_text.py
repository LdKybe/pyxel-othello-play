"""JSONの文字・サイズ・重複キーを外部境界で検証する。"""

import json
import math

MAX_MESSAGE_BYTES = 1024 * 1024
MAX_TEXT_LENGTH = 64 * 1024


class CodecError(ValueError):
    """外部表現を変換できない理由と項目位置。"""


def validate_text(value: str) -> str:
    """長さとUTF-8で表現できる文字列を検証する。"""
    if len(value) > MAX_TEXT_LENGTH:
        raise CodecError("文字列は65536文字以内で指定してください")
    try:
        value.encode("utf-8")
    except UnicodeEncodeError as exc:
        raise CodecError("不正なUnicode文字です") from exc
    return value


def _pairs(pairs: list[tuple[str, object]]) -> dict[str, object]:
    result: dict[str, object] = {}
    for key, value in pairs:
        if key in result:
            raise CodecError(f"重複したJSONキーです: $.{key}")
        result[key] = value
    return result


def _constant(value: str) -> object:
    raise CodecError(f"非有限値は使用できません: {value} @ $")


def _validate(value: object, path: str = "$") -> None:
    if isinstance(value, str):
        try:
            validate_text(value)
        except CodecError as exc:
            raise CodecError(f"{exc} @ {path}") from exc
    elif isinstance(value, float) and not math.isfinite(value):
        raise CodecError(f"非有限値は使用できません @ {path}")
    elif isinstance(value, dict):
        for key, child in value.items():
            _validate(key, path)
            _validate(child, f"{path}.{key}")
    elif isinstance(value, (list, tuple)):
        for index, child in enumerate(value):
            _validate(child, f"{path}[{index}]")


def decode_json(value: bytes) -> object:
    """外部JSONを復元する。型付きレコードの復元は呼出し側が行う。"""
    if len(value) > MAX_MESSAGE_BYTES:
        raise CodecError("メッセージは1 MiB以内で指定してください @ $")
    try:
        result: object = json.loads(
            value.decode("utf-8"), object_pairs_hook=_pairs, parse_constant=_constant
        )
        _validate(result)
    except CodecError:
        raise
    except (UnicodeError, ValueError, RecursionError) as exc:
        raise CodecError("JSONまたはUTF-8の形式が不正です @ $") from exc
    return result


def encode_json(value: object) -> bytes:
    """検証したJSON表現をUTF-8 bytesへ変換する。"""
    try:
        _validate(value)
        result = json.dumps(
            value, ensure_ascii=False, allow_nan=False, separators=(",", ":")
        ).encode("utf-8")
    except (TypeError, ValueError, UnicodeError, RecursionError) as exc:
        raise CodecError(f"JSONへ変換できません: {exc} @ $") from exc
    if len(result) > MAX_MESSAGE_BYTES:
        raise CodecError("メッセージは1 MiB以内で指定してください @ $")
    return result
