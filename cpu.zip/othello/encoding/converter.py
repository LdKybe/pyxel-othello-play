"""dataclassを正本に、厳密な外部表現を生成・復元する。"""

import math
import re
from collections.abc import Callable
from dataclasses import fields, is_dataclass
from typing import Generic, Literal, TypeVar, get_args, get_origin, get_type_hints

from cattrs import Converter
from cattrs.cols import homogenous_tuple_structure_factory
from cattrs.errors import BaseValidationError, ForbiddenExtraKeysError
from cattrs.gen import make_dict_structure_fn, make_dict_unstructure_fn, override
from cattrs.v import transform_error

from .json_text import CodecError, decode_json, encode_json, validate_text

__all__ = ["CodecError", "RecordCodec"]

T = TypeVar("T")
_MAX_INTEGER_DIGITS = 1024
_DECIMAL = re.compile(r"(?:0|-[1-9][0-9]*|[1-9][0-9]*)\Z", re.ASCII)


def _integer(value: object) -> str:
    if type(value) is not int:
        raise CodecError("整数が必要です（真偽値は不可）")
    if abs(value) >= 10**_MAX_INTEGER_DIGITS:
        raise CodecError("整数は1024桁以内で指定してください")
    result = str(value)
    if len(result.removeprefix("-")) > _MAX_INTEGER_DIGITS:
        raise CodecError("整数は1024桁以内で指定してください")
    return result


def _decimal(value: object, _: object) -> int:
    if not isinstance(value, str) or not _DECIMAL.fullmatch(value):
        raise CodecError("整数は正規のASCII十進文字列で指定してください")
    if len(value.removeprefix("-")) > _MAX_INTEGER_DIGITS:
        raise CodecError("整数は1024桁以内で指定してください")
    return int(value)


def _boolean(value: object) -> bool:
    if type(value) is not bool:
        raise CodecError("真偽値が必要です")
    return value


def _float(value: object) -> float:
    if type(value) is not float or not math.isfinite(value):
        raise CodecError("有限の小数が必要です")
    return value


def _text(value: object) -> str:
    if not isinstance(value, str):
        raise CodecError("文字列が必要です")
    return validate_text(value)


def _null(value: object) -> None:
    if value is not None:
        raise CodecError("nullが必要です")


def _unsupported(_: object) -> object:
    raise CodecError("bytesフィールドは使用できません")


def _at_field(
    name: str, hook: Callable[[object], object]
) -> Callable[[object], object]:
    def convert(value: object) -> object:
        try:
            return hook(value)
        except (ValueError, TypeError, AttributeError) as exc:
            raise CodecError(f"{exc} @ .{name}") from exc

    return convert


def _literal_hook(kind: object, converter: Converter) -> Callable[[object], object]:
    choices = get_args(kind)

    def convert(value: object) -> object:
        if not any(
            type(value) is type(choice) and value == choice for choice in choices
        ):
            raise CodecError("Literalの値が一致しません")
        return converter.unstructure(value)

    return convert


def _structure_literal(
    kind: object, converter: Converter
) -> Callable[[object, object], object]:
    choices = get_args(kind)

    def convert(value: object, _: object) -> object:
        for choice in choices:
            try:
                restored: object = converter.structure(value, type(choice))
            except (ValueError, TypeError):
                continue
            if type(restored) is type(choice) and restored == choice:
                return restored
        raise CodecError("Literalの型または値が一致しません")

    return convert


def _is_literal(kind: object) -> bool:
    return get_origin(kind) is Literal


def _structure_record(
    kind: type[T], converter: Converter
) -> Callable[[object, object], T]:
    required = tuple(
        name
        for name, hint in get_type_hints(kind).items()
        if get_origin(hint) is Literal
    )
    generated = make_dict_structure_fn(kind, converter)

    def convert(value: object, _: object) -> T:
        if not isinstance(value, dict):
            raise CodecError("レコードはJSON objectで指定してください")
        for name in required:
            if name not in value:
                raise CodecError(f"必須項目がありません @ .{name}")
        return generated(value, kind)

    return convert


def _unstructure_record(kind: type[T], converter: Converter) -> Callable[[T], object]:
    if not is_dataclass(kind):
        raise TypeError("dataclassが必要です")
    hints = get_type_hints(kind)
    overrides = {
        field.name: override(
            unstruct_hook=_at_field(
                field.name, converter.get_unstructure_hook(hints[field.name])
            )
        )
        for field in fields(kind)
    }
    return make_dict_unstructure_fn(
        kind,
        converter,
        _cattrs_omit_if_default=False,
        _cattrs_use_linecache=True,
        _cattrs_use_alias="from_converter",
        _cattrs_include_init_false=False,
        **overrides,
    )


def _is_homogeneous_tuple(kind: object) -> bool:
    args = get_args(kind)
    return get_origin(kind) is tuple and args[-1:] == (Ellipsis,)


def _tuple_hook(kind: type, converter: Converter) -> Callable[[object, object], object]:
    generated = homogenous_tuple_structure_factory(kind, converter)

    def convert(value: object, target: object) -> object:
        if not isinstance(value, list):
            raise CodecError("配列が必要です")
        return generated(value, target)

    return convert


def _configure() -> Converter:
    converter = Converter(forbid_extra_keys=True, detailed_validation=True)
    for kind, hook in (
        (bool, _boolean),
        (float, _float),
        (str, _text),
        (type(None), _null),
        (bytes, _unsupported),
    ):
        converter.register_unstructure_hook(kind, hook)
        converter.register_structure_hook(kind, lambda value, _, hook=hook: hook(value))
    converter.register_structure_hook(int, _decimal)
    converter.register_unstructure_hook(int, _integer)
    converter.register_structure_hook_func(
        lambda kind: kind is None, lambda value, _: _null(value)
    )
    converter.register_unstructure_hook_func(lambda kind: kind is None, _null)

    converter.register_unstructure_hook_factory(_is_literal, _literal_hook)
    converter.register_structure_hook_factory(_is_literal, _structure_literal)
    converter.register_structure_hook_factory(_is_homogeneous_tuple, _tuple_hook)
    converter.register_structure_hook_factory(is_dataclass, _structure_record)
    converter.register_unstructure_hook_factory(is_dataclass, _unstructure_record)
    return converter


def _reason(exc: BaseException, _: type | None) -> str:
    if isinstance(exc, CodecError):
        return str(exc)
    if isinstance(exc, ForbiddenExtraKeysError):
        return "未知の項目があります: " + ", ".join(sorted(exc.extra_fields))
    if isinstance(exc, KeyError):
        return f"必須項目がありません: {exc}"
    return "型または値が不正です"


class RecordCodec(Generic[T]):
    """閉じたdataclassと外部JSONの間を型定義から変換する。"""

    def __init__(self, record_type: type[T]) -> None:
        """変換設定を固定してからレコード用の変換器を生成する。"""
        self._initialize(record_type, _configure())

    def _initialize(self, record_type: type[T], converter: Converter) -> None:
        if not is_dataclass(record_type):
            raise TypeError("最上位にはdataclassの型を指定してください")
        self._record_type = record_type
        self._converter = converter
        self._converter.get_structure_hook(record_type)
        self._converter.get_unstructure_hook(record_type)

    def encode(self, value: T) -> bytes:
        """レコードを外部表現へ変換する。decodeによる再検証はしない。"""
        try:
            raw: object = self._converter.unstructure(value, self._record_type)
            return encode_json(raw)
        except (ValueError, TypeError, AttributeError, RecursionError) as exc:
            raise CodecError(f"外部表現へ変換できません: {exc} @ $") from exc

    def decode(self, value: bytes) -> T:
        """不正な表現を項目位置付きのCodecErrorで拒否する。"""
        raw = decode_json(value)
        try:
            return self._converter.structure(raw, self._record_type)
        except (
            BaseValidationError,
            ValueError,
            TypeError,
            AttributeError,
            KeyError,
            RecursionError,
        ) as exc:
            reasons = transform_error(exc, format_exception=_reason)
            raise CodecError("; ".join(reasons)) from exc


class _PreparedRecordCodec(RecordCodec[T]):
    def __init__(self, record_type: type[T], converter: Converter) -> None:
        self._initialize(record_type, converter)
