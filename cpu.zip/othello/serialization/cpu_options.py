"""CPU設定の意味を解釈せず、値の型を外部表現に保持する。"""

from dataclasses import dataclass
from typing import Literal, assert_never

from othello.cpu.contracts.input import (
    BoolOption,
    FloatOption,
    IntOption,
    NoneOption,
    OptionValue,
    TextOption,
)


@dataclass(frozen=True, slots=True, kw_only=True)
class BoolImage:
    """真偽値の外部表現。"""

    tag: Literal["bool"]
    value: bool


@dataclass(frozen=True, slots=True, kw_only=True)
class IntImage:
    """整数の外部表現。"""

    tag: Literal["int"]
    value: int


@dataclass(frozen=True, slots=True, kw_only=True)
class FloatImage:
    """小数の外部表現。"""

    tag: Literal["float"]
    value: float


@dataclass(frozen=True, slots=True, kw_only=True)
class TextImage:
    """文字列の外部表現。"""

    tag: Literal["text"]
    value: str


@dataclass(frozen=True, slots=True, kw_only=True)
class NoneImage:
    """値なしの外部表現。"""

    tag: Literal["none"]
    value: None


@dataclass(frozen=True, slots=True, kw_only=True)
class OptionImage:
    """設定値の種類を必須tagで区別する。"""

    value: BoolImage | IntImage | FloatImage | TextImage | NoneImage


def option_to_image(value: OptionValue) -> OptionImage:
    """元の設定値を、型を保持した外部表現へ移す。"""
    match value:
        case BoolOption(value=item):
            return OptionImage(value=BoolImage(tag="bool", value=item))
        case IntOption(value=item):
            return OptionImage(value=IntImage(tag="int", value=item))
        case FloatOption(value=item):
            return OptionImage(value=FloatImage(tag="float", value=item))
        case TextOption(value=item):
            return OptionImage(value=TextImage(tag="text", value=item))
        case NoneOption(value=item):
            return OptionImage(value=NoneImage(tag="none", value=item))
        case _:
            assert_never(value)


def option_from_image(image: OptionImage) -> OptionValue:
    """検証済みの外部表現から元の設定値を復元する。"""
    match image.value:
        case BoolImage(value=item):
            return BoolOption(value=item)
        case IntImage(value=item):
            return IntOption(value=item)
        case FloatImage(value=item):
            return FloatOption(value=item)
        case TextImage(value=item):
            return TextOption(value=item)
        case NoneImage():
            return NoneOption()
        case other:
            assert_never(other)
